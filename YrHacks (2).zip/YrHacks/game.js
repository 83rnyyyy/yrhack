'use strict';

// ---INDEXEDDB SETUP---
// ---SAVING CHARACTERS ---




// Mushroom Class
class Mushroom{

    // constructor for the mushroom enemy
    constructor(difficultyScale){

        // name of the enemy
        this.name = 'Mushroom';

        // difficulty scaling
        this.difficultyScale = difficultyScale;

        // stats
        this.maxHealth = Math.floor(ENEMY_HPS[1]*difficultyScale);
        this.health = Math.floor(ENEMY_HPS[1]*difficultyScale);
        this.defense = Math.floor(ENEMY_DEFS[1]*difficultyScale);

        // check if the support character is tank and apply his passive
        if (party[1].name == supportCharacters[1] && supportDead != true){
            this.attack = Math.floor((ENEMY_ATKS[1]*difficultyScale*SUPPORT_SPECIAL[1])*(1 - (party[0].defense / (party[0].defense + 100 + party[0].defense**0.5))));
        }else{
            this.attack = Math.floor((ENEMY_ATKS[1]*difficultyScale)*(1 - (party[0].defense / (party[0].defense + 100 + party[0].defense**0.5))));
        }
        this.exp = Math.floor(ENEMY_EXP[1]*difficultyScale);
        this.coin = ENEMY_COINS[1];


        // status effects
        this.burn = 0;
        this.poison = 0;
        this.block = 0
        
        this.effects = [this.block, this.burn, this.poison];

        // next move
        this.nextMove = 0;
        this.nextMoveType = '';
        this.targeting = '';

        // end turn
        this.endTurn = false;
    }
    // updates status effects
    updateEffects(){
        this.effects = [this.block, this.burn, this.poison];
    }
    // burn damage
    burnDamage(){
        if (this.burn > 0){
            // subtract the burn from the health
            this.health -= this.burn;

            // if the health is less than 0, set the health to 0 and return death
            if (this.health <= 0){
                this.health = 0;
                return 'Death';
            }
            // else return hurt
            else{
                return 'Hurt';
            }
        }
        else{
            return 'Idle';
        }
        
    }
    // poison damage
    poisonDamage(){
        if (this.poison > 0){
            // subtract the poison from the health
            this.health -= this.poison;

            // if the health is less than 0, set the health to 0 and return death
            if (this.health <= 0){
                this.health = 0;
                return 'Death';
            }
            else{
                return 'Hurt';
            }
        }
        else{
            return 'Idle';
        }
    }
    // use the move
    useMove(){

        // check which move type it is
       if (this.nextMoveType == 'Attack'){
            // check the targeting
            if (this.targeting == 'First'){
                // check if the first party member has a block
                if (party[0].block > 0){

                    // subtract the block from the attack
                    party[0].block -= this.nextMove;
                    

                    // if the block is less than 0, subtract the block from the health
                    if (party[0].block < 0){

                        party[0].health += party[0].block;
                        party[0].block = 0; 
                    }
                    if (party[0].health < 0){
                        party[0].health = 0;
                    }
                }
                
                else{
                    party[0].health -= this.nextMove;
                    if (party[0].health < 0){
                        party[0].health = 0;
                    }
                }
                if (party[0].health <= 0){
                    playerState = 'Death';
                    party[0].health = 0;
                }
                else{
                    playerState = 'Hurt';
                }
                animationGameFrame = 0;
            }
            else{
                // check if the first party member has a block
                if (party[1].block > 0){

                    // subtract the block from the attack
                    party[1].block -= this.nextMove;
                    

                    // if the block is less than 0, subtract the block from the health
                    if (party[1].block < 0){

                        party[1].health += party[0].block;
                        party[1].block = 0; 
                    }
                    if (party[1].health < 0){
                        party[1].health = 0;
                    }
                }
                
                else{
                    party[1].health -= this.nextMove;
                    if (party[1].health < 0){
                        party[1].health = 0;
                    }
                }
                // check if support is dead
                if (party[1].health <= 0){
                    supportDead = true;

                    // hide its elements
                    SUPPORT_HEALTHBAR.style.display = 'none';
                    SUPPORT_HEALTH_TEXT.style.display = 'none';
                }
            }
        }
        // check if the next move is a defense
        else if (this.nextMoveType == 'Defense'){
              this.block = this.nextMove;
        }
         
    }
    // gives currency
    giveCurrency(){
        exp += this.exp;
        currency += this.coin;
    };
    // get the moves for the mushroom
    getMoves(){
        // randomize the move
        let rand = Math.random();

        // randomize the attack
        if (rand < 0.32){
            this.nextMoveType = 'Attack';
            this.nextMove = this.attack;
        }
        else if (rand < 0.64){
            this.nextMoveType = 'Attack';
            this.nextMove = Math.floor(this.attack*1.2);
        }
        else if (rand < 0.96){
            this.nextMoveType = 'Defense';
            this.nextMove = this.defense;
        }
        else{
            this.nextMoveType = 'Attack';
            this.nextMove = this.attack*2;
        }
        
        // randomize the targeting
        if (this.nextMoveType == 'Attack'){
            // check if support is dead
            if (supportDead){
                this.targeting = 'First'; 
            }
            else{
                if (rand < 0.50){
                    this.targeting = 'First';
                }
                else{
                    this.targeting = 'Last';
                }
            }
        }
    }
}

// slime class
class Slime{
    constructor(difficultyScale){

        // name of the enemy
        this.name = 'Slime';
        
        // difficulty scaling
        this.difficultyScale = difficultyScale;

        // stats
        this.maxHealth = Math.floor(ENEMY_HPS[0]*difficultyScale);
        this.health = Math.floor(ENEMY_HPS[0]*difficultyScale);
        this.defense = Math.floor(ENEMY_DEFS[0]*difficultyScale);

        // check if the support character is tank and apply his passive
        if (party[1].name == supportCharacters[1] && supportDead != true){
            this.attack = Math.floor((ENEMY_ATKS[0]*difficultyScale*SUPPORT_SPECIAL[1])*(1 - (party[0].defense / (party[0].defense + 100 + party[0].defense**0.5))));
        }else{
            this.attack = Math.floor((ENEMY_ATKS[0]*difficultyScale)*(1 - (party[0].defense / (party[0].defense + 100 + party[0].defense**0.5))));
        }
        this.exp = Math.floor(ENEMY_EXP[0]*difficultyScale);
        this.coin = ENEMY_COINS[0];



        // status effects
        this.burn = 0;
        this.poison = 0;
        this.block = 0
        this.effects = [this.block, this.burn, this.poison];

        // move
        this.nextMove = 0;
        this.nextMoveType = '';
        this.targeting = '';

        // end turn
        this.endTurn = false;
    }

    // updates status effects
    updateEffects(){
        this.effects = [this.block, this.burn, this.poison];
    }
    // burn damage
    burnDamage(){
        if (this.burn > 0){
            // subtract the burn from the health
            this.health -= this.burn;

            // if the health is less than 0, set the health to 0 and return death
            if (this.health <= 0){
                this.health = 0;
                return 'Death';
            }
            // else return hurt
            else{
                return 'Hurt';
            }
        }
        else{
            return 'Idle';
        }
        
    }
    // poison damage
    poisonDamage(){
        if (this.poison > 0){
            // subtract the poison from the health
            this.health -= this.poison;

            // if the health is less than 0, set the health to 0 and return death
            if (this.health <= 0){
                this.health = 0;
                return 'Death';
            }
            else{
                return 'Hurt';
            }
        }
        else{
            return 'Idle';
        }
    }

    // use the move
    useMove(){

        // check which move type it is
       if (this.nextMoveType == 'Attack'){
            // check the targeting
            if (this.targeting == 'First'){
                // check if the first party member has a block
                if (party[0].block > 0){
                    // subtract the block from the attack
                    party[0].block -= this.nextMove;

                    // if the block is less than 0, subtract the block from the health
                    if (party[0].block < 0){

                        party[0].health += party[0].block;
                        party[0].block = 0; 
                    }
                    if (party[0].health < 0){
                        party[0].health = 0;
                    }
                }
                
                else{
                    party[0].health -= this.nextMove;
                    if (party[0].health < 0){
                        party[0].health = 0;
                    }
                }
                if (party[0].health <= 0){
                    playerState = 'Death';
                    party[0].health = 0;
                }
                else{
                    playerState = 'Hurt';
                }
                animationGameFrame = 0;
            }
            else{
                // check if the first party member has a block
                if (party[1].block > 0){

                    // subtract the block from the attack
                    party[1].block -= this.nextMove;
                    

                    // if the block is less than 0, subtract the block from the health
                    if (party[1].block < 0){

                        party[1].health += party[0].block;
                        party[1].block = 0; 
                    }
                    if (party[1].health < 0){
                        party[1].health = 0;
                    }
                }
                
                else{
                    party[1].health -= this.nextMove;
                    if (party[1].health < 0){
                        party[1].health = 0;
                    }
                }
                // check if support is dead
                if (party[1].health <= 0){
                    supportDead = true;

                    // hide its elements
                    SUPPORT_HEALTHBAR.style.display = 'none';
                    SUPPORT_HEALTH_TEXT.style.display = 'none';
                }
            }
       }
       // check if the next move is a defense
       else if (this.nextMoveType == 'Defense'){
        this.block = this.nextMove;
        }
    }

    // give currency
    giveCurrency(){
        exp += this.exp;
        currency += this.coin;
    };
    // get the moves for the slime
    getMoves(){
        let rand = Math.random();

        // randomize the attack
        if (rand < 0.32){
            this.nextMoveType = 'Attack';
            this.nextMove = this.attack;
        }
        else if (rand < 0.64){
            this.nextMoveType = 'Attack';
            this.nextMove = Math.floor(this.attack*1.2);
        }
        else if (rand < 0.96){
            this.nextMoveType = 'Defense';
            this.nextMove = this.defense;
        }
        else{
            this.nextMoveType = 'Attack';
            this.nextMove = this.attack*2;
        }
        
        // randomize the targeting
        if (this.nextMoveType == 'Attack'){
            // check if support is dead
            if (supportDead){
                this.targeting = 'First'; 
            }
            else{
                if (rand < 0.50){
                    this.targeting = 'First';
                }
                else{
                    this.targeting = 'Last';
                }
            }
        }
    }
}

// Goblin enemy
class Goblin{

    // constructor for the goblin enemy
    constructor(difficultyScale){

        // name of the enemy
        this.name = 'Goblin';

        // difficulty scaling
        this.difficultyScale = difficultyScale;

        // stats
        this.maxHealth = Math.floor(ENEMY_HPS[2]*difficultyScale);
        this.health = Math.floor(ENEMY_HPS[2]*difficultyScale);
        this.defense = Math.floor(ENEMY_DEFS[2]*difficultyScale);

        // check if the support character is tank and apply his passive
        if (party[1].name == supportCharacters[1] && supportDead != true){
            this.attack = Math.floor((ENEMY_ATKS[2]*difficultyScale*SUPPORT_SPECIAL[1])*(1 - (party[0].defense / (party[0].defense + 100 + party[0].defense**0.5))));
        }else{
            this.attack = Math.floor((ENEMY_ATKS[2]*difficultyScale)*(1 - (party[0].defense / (party[0].defense + 100 + party[0].defense**0.5))));
        }
        this.exp = Math.floor(ENEMY_EXP[2]*difficultyScale);
        this.coin = ENEMY_COINS[2];

        // status effects
        this.burn = 0;
        this.poison = 0;
        this.block = 0

        this.effects = [this.block, this.burn, this.poison];

        // next move
        this.nextMove = 0;
        this.nextMoveType = '';
        this.targeting = '';

        // end turn
        this.endTurn = false;
    }

    // updates status effects
    updateEffects(){
        this.effects = [this.block, this.burn, this.poison];
    }

    // burn damage
    burnDamage(){
        if (this.burn > 0){
            // subtract the burn from the health
            this.health -= this.burn;

            // if the health is less than 0, set the health to 0 and return death
            if (this.health <= 0){
                this.health = 0;
                return 'Death';
            }
            // else return hurt
            else{
                return 'Hurt';
            }
        }
        else{
            return 'Idle';
        }
        
    }
    // poison damage
    poisonDamage(){
        if (this.poison > 0){
            // subtract the poison from the health
            this.health -= this.poison;

            // if the health is less than 0, set the health to 0 and return death
            if (this.health <= 0){
                this.health = 0;
                return 'Death';
            }
            else{
                return 'Hurt';
            }
        }
        else{
            return 'Idle';
        }
    }

    // use the move
    useMove(){

        // check which move type it is
       if (this.nextMoveType == 'Attack'){
            // check the targeting
            if (this.targeting == 'First'){
                // check if the first party member has a block
                if (party[0].block > 0){
                    // subtract the block from the attack
                    party[0].block -= this.nextMove;

                    // if the block is less than 0, subtract the block from the health
                    if (party[0].block < 0){

                        party[0].health += party[0].block;
                        party[0].block = 0; 
                    }
                    if (party[0].health < 0){
                        party[0].health = 0;
                    }
                }
                
                else{
                    party[0].health -= this.nextMove;
                    if (party[0].health < 0){
                        party[0].health = 0;
                    }
                }
                if (party[0].health <= 0){
                    playerState = 'Death';
                    party[0].health = 0;
                }
                else{
                    playerState = 'Hurt';
                }
                animationGameFrame = 0;
            }
            else{
                // check if the first party member has a block
                if (party[1].block > 0){

                    // subtract the block from the attack
                    party[1].block -= this.nextMove;
                    

                    // if the block is less than 0, subtract the block from the health
                    if (party[1].block < 0){

                        party[1].health += party[0].block;
                        party[1].block = 0; 
                    }
                    if (party[1].health < 0){
                        party[1].health = 0;
                    }
                }
                
                else{
                    party[1].health -= this.nextMove;
                    if (party[1].health < 0){
                        party[1].health = 0;
                    }
                }
                // check if support is dead
                if (party[1].health <= 0){
                    supportDead = true;

                    // hide its elements
                    SUPPORT_HEALTHBAR.style.display = 'none';
                    SUPPORT_HEALTH_TEXT.style.display = 'none';
                }
            }
        
       }
       // check if the next move is a defense
       else if (this.nextMoveType == 'Defense'){
        this.block = this.nextMove;
       }
    }

    // give currency
    giveCurrency(){
        exp += this.exp;
        currency += this.coin;
    };

    // get the moves for the goblin
    getMoves(){
        let rand = Math.random();

        // randomize the attack
        if (rand < 0.32){
            this.nextMoveType = 'Attack';
            this.nextMove = this.attack;
        }
        else if (rand < 0.64){
            this.nextMoveType = 'Attack';
            this.nextMove = Math.floor(this.attack*1.2);
        }
        else if (rand < 0.96){
            this.nextMoveType = 'Defense';
            this.nextMove = this.defense;
        }
        else{
            this.nextMoveType = 'Attack';
            this.nextMove = this.attack*2;
        }
        
        // randomize the targeting
        if (this.nextMoveType == 'Attack'){
            // check if support is dead
            if (supportDead){
                this.targeting = 'First'; 
            }
            else{
                if (rand < 0.50){
                    this.targeting = 'First';
                }
                else{
                    this.targeting = 'Last';
                }
            }
        }
    }
}

// Demon enemy
class Demon{
    // constructor for the demon enemy
    constructor(difficultyScale){

        // name of the enemy
        this.name = 'Demon';

        // difficulty scaling
        this.difficultyScale = difficultyScale;

        // stats
        this.maxHealth = Math.floor(ENEMY_HPS[3]*difficultyScale);
        this.health = Math.floor(ENEMY_HPS[3]*difficultyScale);
        this.defense = Math.floor(ENEMY_DEFS[3]*difficultyScale);
        this.exp = Math.floor(ENEMY_EXP[3]*difficultyScale);

        // check if the support character is tank and apply his passive
        if (party[1].name == supportCharacters[1] && supportDead != true){
            this.attack = Math.floor((ENEMY_ATKS[3]*difficultyScale*SUPPORT_SPECIAL[1])*(1 - (party[0].defense / (party[0].defense + 100 + party[0].defense**0.5))));
        }else{
            this.attack = Math.floor((ENEMY_ATKS[3]*difficultyScale)*(1 - (party[0].defense / (party[0].defense + 100 + party[0].defense**0.5))));
        }
        
        this.coin = ENEMY_COINS[3];

        // status effects
        this.burn = 0;
        this.poison = 0;
        this.block = 0
        this.effects = [this.block, this.burn, this.poison];

        this.nextMove = 0;
        this.nextMoveType = '';
        this.targeting = '';

        // end turn
        this.endTurn = false;
    }

    // updates status effects
    updateEffects(){
        this.effects = [this.block, this.burn, this.poison];
    }

    // give currency
    giveCurrency(){
        exp += this.exp;
        currency += this.coin;
    };

    // burn damage
    burnDamage(){
        if (this.burn > 0){
            // subtract the burn from the health
            this.health -= this.burn;

            // if the health is less than 0, set the health to 0 and return death
            if (this.health <= 0){
                this.health = 0;
                return 'Death';
            }
            // else return hurt
            else{
                return 'Hurt';
            }
        }
        else{
            return 'Idle';
        }
        
    }
    // poison damage
    poisonDamage(){
        if (this.poison > 0){
            // subtract the poison from the health
            this.health -= this.poison;

            // if the health is less than 0, set the health to 0 and return death
            if (this.health <= 0){
                this.health = 0;
                return 'Death';
            }
            else{
                return 'Hurt';
            }
        }
        else{
            return 'Idle';
        }
    }

    // use the move
    useMove(){

        // check which move type it is
       if (this.nextMoveType == 'Attack'){
            // check the targeting
            if (this.targeting == 'First'){
                // check if the first party member has a block
                if (party[0].block > 0){
                    // subtract the block from the attack
                    party[0].block -= this.nextMove;

                    // if the block is less than 0, subtract the block from the health
                    if (party[0].block < 0){

                        party[0].health += party[0].block;
                        party[0].block = 0; 
                    }
                    if (party[0].health < 0){
                        party[0].health = 0;
                    }
                }
                
                else{
                    party[0].health -= this.nextMove;
                    if (party[0].health < 0){
                        party[0].health = 0;
                    }
                }
                if (party[0].health <= 0){
                    playerState = 'Death';
                    party[0].health = 0;
                }
                else{
                    playerState = 'Hurt';
                }
                animationGameFrame = 0;
            }
            else{
                // check if the first party member has a block
                if (party[1].block > 0){

                    // subtract the block from the attack
                    party[1].block -= this.nextMove;
                    

                    // if the block is less than 0, subtract the block from the health
                    if (party[1].block < 0){

                        party[1].health += party[0].block;
                        party[1].block = 0; 
                    }
                    if (party[1].health < 0){
                        party[1].health = 0;
                    }
                }
                
                else{
                    party[1].health -= this.nextMove;
                    if (party[1].health < 0){
                        party[1].health = 0;
                    }
                }
                // check if support is dead
                if (party[1].health <= 0){
                    supportDead = true;

                    // hide its elements
                    SUPPORT_HEALTHBAR.style.display = 'none';
                    SUPPORT_HEALTH_TEXT.style.display = 'none';
                }
            }
        
       }
       // check if the next move is a defense
       else if (this.nextMoveType == 'Defense'){
        this.block = this.nextMove;
       }
    }

    // get he moves for the demon
    getMoves(){
        let rand = Math.random();

        // randomize the attack
        if (rand < 0.32){
            this.nextMoveType = 'Attack';
            this.nextMove = this.attack;
        }
        else if (rand < 0.64){
            this.nextMoveType = 'Attack';
            this.nextMove = Math.floor(this.attack*1.2);
        }
        else if (rand < 0.96){
            this.nextMoveType = 'Defense';
            this.nextMove = this.defense;
        }
        else{
            this.nextMoveType = 'Attack';
            this.nextMove = this.attack*2;
        }
        
        // randomize the targeting
        if (this.nextMoveType == 'Attack'){
            // check if support is dead
            if (supportDead){
                this.targeting = 'First'; 
            }
            else{
                if (rand < 0.50){
                    this.targeting = 'First';
                }
                else{
                    this.targeting = 'Last';
                }
            }
           
        }
    }
}
// --- PARTY SETUP ---
class Character{
    // name, health, attack, defense, critRate, critMultiplier
    constructor(name, health, attack, defense, critRate, critMultiplier, exp , currency){
        // name of the character
        this.name = name;
        
        // stats
        this.health = health;
        this.maxHealth = health;
        this.attack = attack;
        this.defense = defense;
        this.critRate = critRate;
        this.critMultiplier = critMultiplier;
        this.energy = 0;
        this.exp = exp;
        this.currency = currency;
        this.maxEnergy = 7;
        

        // status effects
        this.burn = 0;
        this.poison = 0;
        this.block = 0
        this.effects = [this.block, this.burn, this.poison];
    }

    // updates status effects
    updateEffects(){
        this.effects = [this.block, this.burn, this.poison];
    }

    // status effects
    burnDamage(){
        this.health -= this.burn;
    }
    poisonDamage(){
        this.health -= this.poison;
    }
}

// Define the SupportCharacter class
class SupportCharacter {
    constructor(name, health, defense, special) {
        // Initialize character properties: name, health, defense, and special ability
        this.name = name;
        this.health = health;
        this.maxHealth = health; // Set maxHealth to the initial health value
        this.defense = defense;
        this.special = special;

        // Initialize status effects: burn, poison, and block
        this.burn = 0;
        this.poison = 0;
        this.block = 0;
    }

    // Method to apply burn damage to health
    burnDamage() {
        this.health -= this.burn;
    }

    // Method to apply poison damage to health
    poisonDamage() {
        this.health -= this.poison;
    }
}

// Cards
class Card{

    // constructor for the card
    constructor(name, damage, poison, burn, block, energyCost, type, targeting, description , buyCost, upgradeCost,upgradeStatus){
        this.name = name;
        this.damage = damage;
        this.poison = poison;
        this.burn = burn;
        this.block = block; //6
        this.type = type;
        this.targeting = targeting;
        this.description = description;
        this.buyCost = buyCost;
        this.upgradeCost = upgradeCost;
        this.upgradeStatus = upgradeStatus;
    }

    // play the card
    playCard(target){
        let rand = Math.random();
        // Check the targeting mode
        if (this.targeting == 'self') {
            // If targeting self, apply block boost to the first party member
            if (party[0].name == characters[1]) {
                // Special block boost if the character is the second in the characters array
                party[0].block += this.block + 2;
            } else {
                // Standard block boost
                party[0].block += this.block;
            }
        } 
        else if (this.targeting == 'first') {
            // If targeting the first party member, iterate through the types
            for (let type in this.type) {
                // Check if the type is 'defense'
                if (this.type[type] == 'defense') {
                    // Apply block boost based on the character's name
                    if (party[0].name == characters[1]) {
                        party[0].block += this.block + 2;
                    } else {
                        party[0].block += this.block;
                    }    
                }
            }
          
            // get the first enemy
            let enemyPos;
            for (let enemy in enemies ){
                if (enemies[enemy] != null){
                    enemyPos = enemy;
                }
            }

            // check if the enemy has block
            if (enemies[enemyPos].block == 0){
                // Check if random value is less than the party's critical hit rate
                if (rand < party[0].critRate) {
                    // Deal critical damage to the enemy's health
                    enemies[enemyPos].health -= Math.floor((this.damage * (1 + critDmg / 100)));
                } else {
                    // If the critical hit fails, check again and deal normal damage
                    if (rand < party[0].critRate) {
                        enemies[enemyPos].health -= Math.floor((this.damage * (1 + attack / 100)));
                    }
                }

                // Check if the enemy's health has dropped to zero or below
                if (enemies[enemyPos].health <= 0) {
                    // Set enemy's animation to 'Death' and reset animation frames
                    enemyAnimations[enemyPos] = 'Death';
                    enemyGameFrames[enemyPos] = 0;
                    // Award currency to the player upon enemy's death
                    enemies[enemyPos].giveCurrency();
                } else {
                    // If the enemy is still alive, set animation to 'Hurt' and reset frames
                    enemyAnimations[enemyPos] = 'Hurt';
                    enemyGameFrames[enemyPos] = 0;
                }
            }

            // check if the enemy has block
            else{
                // Check if random value is less than the party's critical hit rate
                if (rand < party[0].critRate) {
                    // Reduce the enemy's block with critical damage
                    enemies[enemyPos].block -= Math.floor((this.damage * (1 + critDmg / 100)));
                } else {
                    // If the critical hit fails, check again and reduce block with normal damage
                    if (rand < party[0].critRate) {
                        enemies[enemyPos].block -= Math.floor((this.damage * (1 + attack / 100)));
                    }
                }

                // Check if the enemy's block has been reduced below zero
                if (enemies[enemyPos].block < 0) {
                    // If block is negative, adjust the enemy's health by the overflow amount
                    enemies[enemyPos].health += enemies[enemyPos].block;
                    // Reset the block to zero to prevent negative block values
                    enemies[enemyPos].block = 0;
                }
            }
       
            // check if the enemy is dead
            if (enemies[enemyPos].health <= 0){
                enemyAnimations[enemyPos] = 'Death';
                enemies[enemyPos].giveCurrency()
                enemyGameFrames[enemyPos] = 0;
            }
            else{
                enemyAnimations[enemyPos] = 'Hurt';
                enemyGameFrames[enemyPos] = 0;
            }
               
            // update the status effects
            if (party[0].name == characters[0]){
                enemies[enemyPos].burn += this.burn + 1;
            }
            else{
                enemies[enemyPos].burn += this.burn;
            }
            
            enemies[enemyPos].poison += this.poison;
            enemies[enemyPos].updateEffects();
        }

        // check if the targeting is all
        else if (this.targeting =='all'){

            // check if the card is also a defense card
            for (let type in this.type){
                if (this.type[type] == 'defense'){
                    if (party[0].name == characters[1]){
                        party[0].block += this.block + 2;
                    }
                    else{
                        party[0].block += this.block;
                    }    
                }
            }
            

            // deal damage to all enemies
            for (let enemy in enemies){
                
                // check if enemy is alive
                if (enemies[enemy] != null){
                    
                    // check if the enemy has block
                    if (enemies[enemy].block == 0){
                        
                        // Check if random value is less than the party's critical hit rate
                        if (rand < party[0].critRate) {

                            // Deal critical damage to the enemy's health
                            enemies[enemy].health -= Math.floor((this.damage * (1 + critDmg / 100)));
                        } 
                        else {
                            // If the critical hit fails, check again and deal normal damage
                            if (rand < party[0].critRate) {
                                enemies[enemy].health -= Math.floor((this.damage * (1 + attack / 100)));
                            }
                        }
                        
                        
                    }

                    // check if the enemy has block
                    else{
                        // Check if random value is less than the party's critical hit rate
                        if (rand < party[0].critRate) {
                            // Reduce the enemy's block with critical damage
                            enemies[enemy].block -= Math.floor((this.damage * (1 + critDmg / 100)));
                        } else {
                            // If the critical hit fails, check again and reduce block with normal damage
                            if (rand < party[0].critRate) {
                                enemies[enemy].block -= Math.floor((this.damage * (1 + attack / 100)));
                            }
                        }

                        // Check if the enemy's block has been reduced below zero
                        if (enemies[enemy].block < 0) {
                            // If block is negative, reduce the enemy's health by the remaining amount
                            enemies[enemy].health += enemies[enemy].block;
                            // Reset the block to zero to avoid negative block values
                            enemies[enemy].block = 0;
                        }
                    }
                    
                    // update the status effects
                    if (party[0].name == characters[0]){
                        enemies[enemy].burn += this.burn + 1;
                    }
                    else{
                        enemies[enemy].burn += this.burn;
                    }
                    enemies[enemy].poison += this.poison;
                    enemies[enemy].updateEffects();

                    // Check if the enemy's health has dropped to zero or below
                    if (enemies[enemy].health <= 0) {
                        // Set enemy's animation to 'Death' and reset animation frames
                        enemyAnimations[enemy] = 'Death';
                        enemyGameFrames[enemy] = 0;
                        // Award currency to the player upon enemy's death
                        enemies[enemy].giveCurrency();
                    } else {
                        // If the enemy is still alive, set animation to 'Hurt' and reset frames
                        enemyAnimations[enemy] = 'Hurt';
                        enemyGameFrames[enemy] = 0;
                    }
                }

                
            }
            
        }
        else if (this.targeting == 'any'){

            // check if the card is also a defense card
            for (let type in this.type){
                if (this.type[type] == 'defense'){
                    if (party[0].name == characters[1]){
                        party[0].block += this.block + 2;
                    }
                    else{
                        party[0].block += this.block;
                    }    
                }
            }
            // check if the card is a defense card
            if (this.type == 'defense'){
                if (party[0].name == characters[1]){
                    party[0].block += this.block + 2;
                }
                else{
                    party[0].block += this.block;
                }    
            }

            // Loop through all enemies
            for (let enemy in enemies) {
                // Check if the current enemy is the target
                if (enemies[enemy] == target) {
                    // If the enemy has no block
                    if (enemies[enemy].block == 0) {
                        // Check if random value is less than party's critical rate
                        if (rand < party[0].critRate) {
                            // Deal critical damage to the enemy's health
                            enemies[enemy].health -= Math.floor((this.damage * (1 + critDmg / 100)));
                        } else {
                            // Otherwise, deal normal damage
                            enemies[enemy].health -= Math.floor((this.damage * (1 + attack / 100)));
                        }
                    } else {
                        // If the enemy has block points
                        if (rand < party[0].critRate) {
                            // Reduce block with critical damage
                            enemies[enemy].block -= Math.floor((this.damage * (1 + critDmg / 100)));
                        } else {
                            // Reduce block with normal damage
                            enemies[enemy].block -= Math.floor((this.damage * (1 + attack / 100)));
                        }
                        // Adjust health if block goes negative
                        if (enemies[enemy].block < 0) {
                            enemies[enemy].health += enemies[enemy].block;
                            enemies[enemy].block = 0;
                        }
                    }
                    // Apply burn effect based on character's name
                    if (party[0].name == characters[0]) {
                        enemies[enemy].burn += this.burn + 1;
                    } else {
                        enemies[enemy].burn += this.burn;
                    }
                    // Apply poison effect
                    enemies[enemy].poison += this.poison;
                    // Update enemy status effects
                    enemies[enemy].updateEffects();
                    // Check if enemy's health is depleted
                    if (enemies[enemy].health <= 0) {
                        // Trigger death animation and give currency
                        enemies[enemy].giveCurrency();
                        enemyAnimations[enemy] = 'Death';
                        enemyGameFrames[enemy] = 0;
                    } else {
                        // Trigger hurt animation
                        enemyAnimations[enemy] = 'Hurt';
                        enemyGameFrames[enemy] = 0;
                    }
                }
            }

        }
    }
}

// --- Canvas Setup ---
const CANVA = document.getElementById('Canvas');
const CTX = CANVA.getContext('2d');
const CANVA_WIDTH = CANVA.width = 1024;
const CANVA_HEIGHT = CANVA.height = 576;

// --- ANIMATION STATES ---
// FireWizard
const FIREWIZARD_ANIMATIONS_STATES = [
    { name: 'Death', frames: 6 },
    { name: 'Attack2', frames: 4 },
    { name: 'Fireball', frames: 14 },
    { name: 'Hurt', frames: 3 },
    { name: 'Idle', frames: 7 },
    { name: 'Run', frames: 8 },
];

// Knight
const KNIGHT_ANIIMATION_STATES = [
    { name: 'Attack1', frames: 6 },
    { name: 'Death', frames: 12 },
    { name: 'Block', frames: 6 },
    { name: 'Hurt', frames: 4 },
    { name: 'Idle', frames: 7 },
    { name: 'Run', frames: 8 },
];

// Ninja
const NINJA_ANIMATION_STATES = [
    {name: 'Idle', frames: 8},
    {name: 'Run', frames: 10},
    {name: 'Hurt', frames: 4},
    {name: 'Death', frames: 14}
];

// Fairy 
const FAIRY_ANIMATION_STATES = [
    {name: 'Idle', frames: 4}
];

// Tank
const TANK_ANIMATION_STATES = [
    {name: 'Idle', frames: 8},
    {name: 'Run', frames: 8},
    {name: 'Hurt', frames: 6}
];

// Slime
const SLIME_ANIMATION_STATES = [
    {name: 'Death', frames: 14},
    {name: 'Hurt', frames: 11},
    {name: 'Idle', frames: 7}
];

// Mushroom
const MUSHROOM_ANIMATION_STATES = [
    {name: 'Death', frames: 15},
    {name: 'Hurt', frames: 5},
    {name: 'Idle', frames: 7}
];
// Goblin
const Goblin_ANIMATION_STATES = [
    {name: 'Death', frames: 4},
    {name: 'Hurt', frames: 4},
    {name: 'Idle', frames: 4}
];

// Demon
const DEMON_ANIMATION_STATES = [
    {name: 'Death', frames: 6},
    {name: 'Hurt', frames: 4},
    {name: 'Idle', frames: 4}
];

//--- DESCRITIONS FOR ALL CHARACTERS ---
//--- CHARACTERS ---
const DESCRIPTION = [
    'Passive Ability - Scorched Strike: Every time the Fire Wizard attacks, he inflicts one Burn on the target, dealing damage over time.',//wizard 
    'Passive Ability - Shieldmaster: Whenever the Knight plays a Defense card, gain +1 Defense for the turn.',//knight
    'Passive Ability - Stealthy Turn: Gets a another turn to play, 0.05% starting chance increases every turn, can use only once per match',//ninja
];

//--- SUPPORT CHARACTERS ---
const SUPPORT_DESCRIPTION = [
    'Passive Ability - Healing Touch: Has a 25% percent chance to give health, but also has a chance to do nothing',//fairy
    'Passive Ability - Iron Gaurd: The tank absorbs the a certian amount of the damage while protecting the team.'//tank
];

//--- STATS ---
//--- CHARACTER STATS ---
const CHARACTER_STATS = [
    'HP: 125\nATK: 30\nDEF: 100\nCRIT DMG:125%\nCRIT RATE:10%',//wizard
    'HP: 150\nATK: 20\nDEF: 50\nCRIT DMG:150%\nCRIT RATE:15%',//knight 
    'HP: 110\nATK: 35\nDEF: 30\nCRIT DMG:175%\nCRIT RATE:22.5%',//ninja
];

//--- SUPPORT STATS ---
const SUPPORT_STATS = [
    'HP: 125\nHEAL: 10%\nDEF: 40',//healer
    'HP: 150\nBLOCK: 30% INCOMING DMG\nDEF: 80',//tank
];

//--- WIDTH AND HEIGHTS ---
//--- CHARACTER WIDTHS ---
const CHARACTER_WIDTHS = [
    128, //wizard
    96, //knight
    256, //ninja
];

//--- CHARACTER HEIGHTS ---
const CHARACTER_HEIGHTS = [
    128,//Wizard
    84,//knight
    258,//ninja
];

//--- SUPPORT CHARACTER WIDTHS ---
const SUPPORT_CHARACTER_WIDTHS = [
    128, //fairy
    288 //Tank
];

//--- SUPPORT CHARACTER HEIGHTS ---
const SUPPORT_CHARACTER_HEIGHTS = [
    128,//fairy
    128 // Tank
];

//--- CHARACTER MENU X LOCATION ---
const MENU_CHARACTERX = [
    CANVA_WIDTH/2-100,// wizard x
    CANVA_WIDTH/2-119,// knight x
    CANVA_WIDTH/2-205,// ninja x  
];

//--- CHARACTER MENU Y LOCATION ---
const MENU_CHARACTERY = [
    (CANVA_HEIGHT/2)-((CHARACTER_HEIGHTS[0]*3.5)/2),// wizard y
    (CANVA_HEIGHT/2)-((CHARACTER_HEIGHTS[1]*2.5)/2),// knight y
    (CANVA_HEIGHT/2) - (CHARACTER_HEIGHTS[2]+20),// ninja y
];

// --- CHARACTER BATTLE X LOCATION ---
const BATTLE_CHARACTERX = [
    150, // wizard x
    133, // knight x
    50 // ninja x
];

const BATTLE_CHARACTERY = [
    100, // wizard y
    217, // knight y
    50 // ninja y
];

//--- Main Character Icon Positions ---
const BATTLE_CHARACTERX_ICONS = [
    BATTLE_CHARACTERX[0]+80,
    BATTLE_CHARACTERX[1]+80,
    BATTLE_CHARACTERX[2]+170,

];
const BATTLE_CHARACTERY_ICONS = [
    BATTLE_CHARACTERX[0]+60,
    BATTLE_CHARACTERX[1]+125,
    BATTLE_CHARACTERX[2]+180,

];
//--- Main Character Scale Size ---
const CHARACTER_SCALE_SIZE = [
    2.25,// fire wizard
    2.75,// knight
    1.75// ninja
];

//--- Main Character Hitbox Width ---
const CHARACTER_HITBOX_WIDTH= [
    CHARACTER_WIDTHS[0]*CHARACTER_SCALE_SIZE[0]/2.5,
    CHARACTER_WIDTHS[1]*CHARACTER_SCALE_SIZE[1]/3,
    (CHARACTER_WIDTHS[2]*CHARACTER_SCALE_SIZE[2])/4
];
//--- Main Character Hitbox Height ---
const CHARACTER_HITBOX_HEIGHT= [
    (CHARACTER_HEIGHTS[0]*CHARACTER_SCALE_SIZE[0])/2,
    (CHARACTER_HEIGHTS[1]*CHARACTER_SCALE_SIZE[1])/2,
    (CHARACTER_HEIGHTS[2]*CHARACTER_SCALE_SIZE[2])/3.5
];
//--- Main Character Hitbox X offset ---
const CHARACTER_HITBOX_XOFFSET = [
    200,
    210,
    205
];
//--- Main Character Hitbox Y offset ---
const CHARACTER_HITBOX_YOFFSET = [
    240,
    270,
    255
];

//--- Support Character Scale ---
const SUPPORT_SCALE_SIZE = [
    1.75,// fairy
    3 // tank
]

//--- Support Character Hitbox Width ---
const SUPPORT_HITBOX_WIDTH= [
    SUPPORT_CHARACTER_WIDTHS[0]*SUPPORT_SCALE_SIZE[0]/2.3,
    (SUPPORT_CHARACTER_WIDTHS[1]*SUPPORT_SCALE_SIZE[1])/10
];

//--- Support Character Hitbox Height ---
const SUPPORT_HITBOX_HEIGHT= [
    SUPPORT_CHARACTER_HEIGHTS[0]*SUPPORT_SCALE_SIZE[0]/3.3,
    (SUPPORT_CHARACTER_HEIGHTS[1]*SUPPORT_SCALE_SIZE[1])/5
];

//--- Support Character Hitbox X Offset ---
const SUPPORT_CHARACTER_HITBOX_XOFFSET = [
    50,
    60
];

//--- Support Character Hitbox Y Offset ---
const SUPPORT_CHARACTER_HITBOX_YOFFSET = [
    270,
    310
];

//--- Support Character In Game Scale ---
const SUPPORT_BATTLE_SCALE = [
    1,//fairy y 
    1.75, // tank y
];

// --- Enemy Scale Size --- 
const ENEMY_SCALE_SIZE = [
    1.5, // Slime
    2, // Mushroom
    2.5, // Goblin
    1.25 // Demon
];

//--- Support Character Menu X LOCATION ---
const SUPPORT_MENU_CHARACTERX = [
    CANVA_WIDTH/2-100,// fairy x
    CANVA_WIDTH/2-420// tank x
];
//--- Support Character Menu Y LOCATION ---
const SUPPORT_MENU_CHARACTERY = [
    (CANVA_HEIGHT/2)-((CHARACTER_HEIGHTS[0]*SUPPORT_SCALE_SIZE[0])/2),// fairy y 
    (CANVA_HEIGHT/2)-((CHARACTER_HEIGHTS[1]*SUPPORT_SCALE_SIZE[1])/2)-200// tank y
];

//--- Support Character Battle X LOCATION ---
const SUPPORT_BATTLE_CHARACTERX = [
    40, // fairy x
    -150 // tank x
];

//--- Support Character Battle Y LOCATION ---
const SUPPORT_BATTLE_CHARACTERY = [
    250,//fairy y 
    165, // tank y
]

//--- Support Character Health ---
const SUPPORT_HEALTHS = [
    125,//healer
    150//tank
];

//--- Support Character Defense ---
const SUPPORT_DEFENSE = [
    40,//healer
    80//tank
];

//--- Support Character Special  ---
const SUPPORT_SPECIAL = [
    0.1,//healer
    0.85//tank
];

// --- Enemy Stats ---
// Enemy Names
const ENEMY_NAMES = [
    'Slime',
    'Mushroom',
    'Goblin',
    'Demon'
];
// Enemy Health Points
const ENEMY_HPS = [
    20,
    40,
    60,
    80
];
// Enemy Defence
const ENEMY_DEFS = [
    5,
    10,
    15,
    20
];
// Enemy Attack
const ENEMY_ATKS = [
    10,
    20,
    25,
    35
];
// Enemy Widths
const ENEMY_WIDTHS = [
    96,
    80,
    150,
    81
];
// Enemy Height
const ENEMY_HEIGHTS = [
    34,
    65,
    55,
    71
];
// Hitbox is created to detect who the the user is clicking on
// Enemy Hitbox Width 
const ENEMY_HITBOX_WIDTHS = [
    (ENEMY_WIDTHS[0]*ENEMY_SCALE_SIZE[0])/2,
    (ENEMY_WIDTHS[1]*ENEMY_SCALE_SIZE[1])/2,
    (ENEMY_WIDTHS[2]*ENEMY_SCALE_SIZE[2])/4,
    ENEMY_WIDTHS[3]*ENEMY_SCALE_SIZE[3],
];
// Enemy Hitbox Height
const ENEMY_HITBOX_HEIGHTS = [
    ENEMY_HEIGHTS[0]*ENEMY_SCALE_SIZE[0],
    (ENEMY_WIDTHS[1]*ENEMY_SCALE_SIZE[1])/2,
    (ENEMY_WIDTHS[2]*ENEMY_SCALE_SIZE[2])/4,
    ENEMY_WIDTHS[3]*ENEMY_SCALE_SIZE[3],
];
// Enemy X Pos For Hitbox
const ENEMY_XOFFSET = [
    850,
    840,
    735,
    875
];
// Enemy Y Pos For Hitbox
const ENEMY_YOFFSET = [
    335,
    250,
    255,
    225
];

// Enemy X Effect Icon Offset
const ENEMY_EFFECT_ICON_XOFFSET = [
    ENEMY_XOFFSET[0]+25,
    ENEMY_XOFFSET[1]+45,
    ENEMY_XOFFSET[2]+145,
    ENEMY_XOFFSET[3]+5    
];

// Enemy Y Effect Icon Offset
const ENEMY_EFFECT_ICON_YOFFSET = [
    ENEMY_YOFFSET[0]-20,
    ENEMY_YOFFSET[1]+30,
    ENEMY_YOFFSET[2]+10,
    ENEMY_YOFFSET[3]-20
];

// Enemy X Move Icon Offset
const ENEMY_MOVE_ICON_XOFFSET = [
    ENEMY_XOFFSET[0]+65,
    ENEMY_XOFFSET[1]+75,
    ENEMY_XOFFSET[2]+175,
    ENEMY_XOFFSET[3]+35   
];

// Enemy Y Move Icon Offset
const ENEMY_MOVE_ICON_YOFFSET = [
    ENEMY_YOFFSET[0]-60,
    ENEMY_YOFFSET[1]-10,
    ENEMY_YOFFSET[2]-30,
    ENEMY_YOFFSET[3]-60
];

// Enemy Exp 
const ENEMY_EXP = [
    3,
    5,
    6,
    8
];
// Enemy Coins 
const ENEMY_COINS = [
    4,
    6,
    8,
    10
];

// Enemy Health Bar
// Health Bar X Pos
const ENEMY_HPBAR_XPOS = [
    ENEMY_XOFFSET[0]+43,
    ENEMY_XOFFSET[1]+50,
    ENEMY_XOFFSET[2]+163,
    ENEMY_XOFFSET[3]+15
];
// Health Bar Y Pos
const ENEMY_HPBAR_yPOS = [
    ENEMY_YOFFSET[0]+50,
    ENEMY_YOFFSET[0]+50,
    ENEMY_YOFFSET[0]+50,
    ENEMY_YOFFSET[0]-10
];
// Health Bar Text X Pos
const ENEMY_HPTEXT_XPOS = [
    ENEMY_XOFFSET[0]+38,
    ENEMY_XOFFSET[1]+47,
    ENEMY_XOFFSET[2]+159,
    ENEMY_XOFFSET[3]+11
];
// Health Bar Text Y Pos
const ENEMY_HPTEXT_YPOS = [
    ENEMY_YOFFSET[0]+30,
    ENEMY_YOFFSET[0]+30,
    ENEMY_YOFFSET[0]+30,
    ENEMY_YOFFSET[0]-30
];
// Enemy Hitbox X Offset
const ENEMY_HITBOX_XOFFSET = [
    ENEMY_XOFFSET[0]+32,
    ENEMY_XOFFSET[1]+35,
    ENEMY_XOFFSET[2]+140,
    ENEMY_XOFFSET[3]+10
];

// Enemy Hitbox Y Offset
const ENEMY_HITBOX_YOFFSET = [
    ENEMY_YOFFSET[0],
    ENEMY_YOFFSET[1]+50,
    ENEMY_YOFFSET[2]+30,
    ENEMY_YOFFSET[3]


];


//--- GENERATE ANIMATIONS ---
const KNIGHT_ANIMATIONS = renderAnimation(KNIGHT_ANIIMATION_STATES, CHARACTER_WIDTHS[1], CHARACTER_HEIGHTS[1]);
const FIREWIZARD_ANIMATIONS = renderAnimation(FIREWIZARD_ANIMATIONS_STATES, CHARACTER_WIDTHS[0], CHARACTER_HEIGHTS[0]);
const NINJA_ANIMATIONS = renderAnimation(NINJA_ANIMATION_STATES, CHARACTER_WIDTHS[2], CHARACTER_HEIGHTS[2]);
const FAIRY_ANIMATION = renderAnimation(FAIRY_ANIMATION_STATES, SUPPORT_CHARACTER_WIDTHS[0], SUPPORT_CHARACTER_HEIGHTS[0]);
const TANK_ANIMATION = renderAnimation(TANK_ANIMATION_STATES, SUPPORT_CHARACTER_WIDTHS[1], SUPPORT_CHARACTER_HEIGHTS[1]);
const SLIME_ANIMATION = renderAnimation(SLIME_ANIMATION_STATES, ENEMY_WIDTHS[0],ENEMY_HEIGHTS[0]);
const MUSHROOM_ANIMATION = renderAnimation(MUSHROOM_ANIMATION_STATES, ENEMY_WIDTHS[1], ENEMY_HEIGHTS[1]);
const GOBLIN_ANIMATION = renderAnimation(Goblin_ANIMATION_STATES, ENEMY_WIDTHS[2], ENEMY_HEIGHTS[2]);
const DEMON_ANIMATION = renderAnimation(DEMON_ANIMATION_STATES, ENEMY_WIDTHS[3], ENEMY_HEIGHTS[3])

// all the main character animations
const CHARACTER_ANIMATIONS = [
    FIREWIZARD_ANIMATIONS,
    KNIGHT_ANIMATIONS,
    NINJA_ANIMATIONS
];

// all the support character animations
const SUPPORT_ANIMATIONS = [
    FAIRY_ANIMATION,
    TANK_ANIMATION
]

// all the enemy animations
const ENEMY_ANIMATIONS = [
    SLIME_ANIMATION,
    MUSHROOM_ANIMATION,
    GOBLIN_ANIMATION,
    DEMON_ANIMATION
];


// --- LOADING ALL CHARACTER SPRITESHEETS ---
const CHARACTERS = [
    loadImage('Images/SpriteSheets/Fire Wizard Spritesheet.png'),
    loadImage('Images/SpriteSheets/Knight SpriteSheet.png'),
    loadImage('Images/SpriteSheets/Ninja Spritesheet.png'),
];

const SUPPORT_CHARACTERS = [
    loadImage('Images/SpriteSheets/Fairy Spritesheet.png'),
    loadImage('Images/SpriteSheets/Tank Spritesheet.png')
];

const ENEMIES_SPRITESHEETS = [
    loadImage('Images/SpriteSheets/Slime Spritesheet.png'),
    loadImage('Images/SpriteSheets/Mushroom Spritesheet.png'),
    loadImage('Images/SpriteSheets/Goblin Spritesheet.png'),
    loadImage('Images/SpriteSheets/Demon Spritesheet.png')
];


// --- Html Elements ---

// CONFIRMATION SCREEN
const CUSTOM_CONFIRMATION = document.getElementById('customConfirm');


// --- LOADING ALL BACKGROUND IMAGES  ---
const MENU_BACKGROUND1 = loadImage('Images/Backgrounds/Menubg.png');
const MENU_BACKGROUND2 = loadImage('Images/Backgrounds/Menubg.png');
const BATTLE_BACKGROUND = loadImage('Images/Backgrounds/Battlebg.png');
const CHARACTER_SELECTION_BACKGROUND = loadImage('Images/Others/Box.png');
const TEXTBOX = loadImage('Images/Others/TextBox.png');
const SHOP_BACKGROUND = loadImage('Images/Backgrounds/shop_bg.jpg');
const MAP_IMG = loadImage("Images/Backgrounds/Map.png");



// --- Transition Elements ---
const TRANSITION = document.getElementById('transition');
const TRANSITION_RECT1 = document.getElementById('rectangle1');
const TRANSITION_RECT2 = document.getElementById('rectangle2');
const TRANSITION_RECT3 = document.getElementById('rectangle3');
const TRANSITION_RECT4 = document.getElementById('rectangle4');

// --- Menu Elements ---
const PLAY_BUTTON = document.getElementById('play-button');
const TITLE = document.getElementById('title');
const SELECTION_TITLE = document.getElementById('selection-title');
const CHARACTER_SELECTION_MENU = document.getElementById('character-selection');
const GAME_PAGE = document.getElementById('game');
const SHOP_IMG = document.getElementById('shop-img');
const SHOP_OVERLAY = document.getElementById('shop-overlay');


// ---Character Selection Elements---

const CHARACTER_CYCLE_LEFT = document.getElementById('cycle-left');
const CHARACTER_CYCLE_RIGHT = document.getElementById('cycle-right');

const CHARACTER_ATK_LEFT = document.getElementById('cycle-left-atk');
const CHARACTER_ATK_RIGHT = document.getElementById('cycle-right-atk');

const CHARACTER_DEF_LEFT = document.getElementById('cycle-left-def');
const CHARACTER_DEF_RIGHT = document.getElementById('cycle-right-def');

const CHARACTER_CRIT_DMG_LEFT = document.getElementById('cycle-left-crit-dmg');
const CHARACTER_CRIT_DMG_RIGHT = document.getElementById('cycle-right-crit-dmg');

const CHARACTER_CRIT_CHANCE_LEFT = document.getElementById('cycle-left-crit-chance');
const CHARACTER_CRIT_CHANCE_RIGHT = document.getElementById('cycle-right-crit-chance');

const CHARACTER_INFO = document.getElementById('character-info');
const CHARACTER_BASE_STATS = document.getElementById('character-stat-info');
const CHARACTER_STATS_UPGRADABLE = document.getElementById('character-stat-info-txt');

const CHARACTER_SELECTION_PAGE1 = document.getElementById('page1');
const CHARACTER_STAT_PAGE2 = document.getElementById('page2_buttons');

const CHARACTER_NAME = document.getElementById('character-name');
const NEXT_BUTTON = document.getElementById('character-confirmation');
const BACK_BUTTON = document.getElementById('back-btn');
const INFO_BACK_BUTTON = document.getElementById('info-back-btn');
const INFO_EXIT_BUTTON = document.getElementById('info-exit-btn');
const INFO_NEXT_BUTTON = document.getElementById('info-next-btn');
const DEATH_TXT = document.getElementById('death-txt');


// --- Game Elements ---
const MERCHANT = document.getElementById('merchant');
const MERCHANT_TEXT = document.getElementById('merchant-txt');
const ANVIL = document.getElementById('anvil-img');

const ANVIL_BUTTON = document.getElementById('anvil-btn');
const SHOP_BUTTON = document.getElementById('shop-btn');
const SHOP_BG = document.getElementById('shop-box');
const EXIT_BUTTON = document.getElementById('exit-btn');
const ANVIL_CARDS = document.getElementById('anvil-cards')

const CONFIRM_BUTTON = document.getElementById('confirm-btn');
const X_BUTTON = document.getElementById('x-button');
const END_TURN_BUTTON = document.getElementById('end-turn-btn');
const INFO_BUTTON = document.getElementById('info-btn');
const INFO_IMG = document.getElementById('info-img');
const INFO_IMG1 = document.getElementById('info-img1');
const INFO_IMG2= document.getElementById('info-img2');
const INFO_IMG3 = document.getElementById('info-img3');
const INFO_IMG4 = document.getElementById('info-img4');
const INFO_TXT = document.getElementById('info-txt')
const OVERLAY = document.getElementById('overlay')
const EXIT_INV_BUTTON = document.getElementById('exit-inv-button');
const DOWN_BTN = document.getElementById('down-btn');
const UP_BTN = document.getElementById('up-btn');
const SORT_BTN = document.getElementById('sort-btn');
const SORT_TXT = document.getElementById('sort-txt');
const INV_TXT = document.getElementById('inv-deck')
const INV_OVERLAY = document.getElementById('inv-overlay');
const INV_BG = document.getElementById('inv-bg')

const SELECT_BTN_1 = document.getElementById('select-1');
const SELECT_BTN_2 = document.getElementById('select-2');
const SELECT_BTN_3 = document.getElementById('select-3');
const SELECT_BTN_4 = document.getElementById('select-4');
const SELECT_BTN_5 = document.getElementById('select-5');
const SELECT_BTN_6 = document.getElementById('select-6');

const UPGRADE_BUTTON = document.getElementById("upgrade-btn")
const LEAVE_BUTTON = document.getElementById('leave-btn');
const BUY_BUTTON = document.getElementById('buy-btn');
const COINS_TXT = document.getElementById('coins-txt');
const SHOP_TXT = document.getElementById('shop-txt');
const COST_TXT = document.getElementById('cost-txt');
const COIN_DISPLAY = document.getElementById('coin-display');
const BUY_TXT = document.getElementById('buy-txt');
const MERCHANT_TXT = document.getElementById("merchant-txt");

const ANVIL_BUY_BUTTON = document.getElementById('buy-btn');
const ANVIL_RIGHT_BUTTON = document.getElementById('anvil-right-arrow')
const ANVIL_LEFT_BUTTON = document.getElementById('anvil-left-arrow')
const SHOP_CARDS = document.getElementById('shop-cards')
const REST_OVERLAY = document.getElementById("rest-overlay")
const TURN_TXT = document.getElementById('turn');
const RESTART_BTN = document.getElementById('restart-btn');
const SELECT_BUTTONS = document.getElementById('select-btns');
const CARD_INDEX_TXT = document.getElementById("card-index-txt");
const ANVIL_BUTTONS = document.getElementById("anvil-btns");
const ARROW_IMG = document.getElementById("arrow");
const REST_TXT = document.getElementById("rest-txt");
const REST_IMG = document.getElementById("rest-img");
const REST_BG = document.getElementById("rest-bg");
const ENEMIES_DIV = document.getElementById('enemies');
const PARTY_HITBOXS = document.getElementById('party-hitbox');

// define array for store selection button
const SELECTION_BUTTONS = [
    SELECT_BTN_1,
    SELECT_BTN_2,
    SELECT_BTN_3,
    SELECT_BTN_4,
    SELECT_BTN_5,
    SELECT_BTN_6
];

// All Buttons
const BUTTONS = [
    PLAY_BUTTON, 
    CHARACTER_CYCLE_LEFT, 
    CHARACTER_CYCLE_RIGHT, 
    CHARACTER_ATK_LEFT, 
    CHARACTER_ATK_RIGHT, 
    CHARACTER_DEF_LEFT, 
    CHARACTER_DEF_RIGHT,
    CHARACTER_CRIT_CHANCE_LEFT, 
    CHARACTER_CRIT_CHANCE_RIGHT, 
    CHARACTER_CRIT_DMG_LEFT, 
    CHARACTER_CRIT_DMG_RIGHT,
    NEXT_BUTTON,
    BACK_BUTTON,
    INFO_BACK_BUTTON,
    INFO_NEXT_BUTTON,
    CONFIRM_BUTTON,
    X_BUTTON,
    END_TURN_BUTTON,
    INFO_BUTTON,
    ANVIL_BUTTON,
    SHOP_BUTTON,
    EXIT_BUTTON,
    INFO_EXIT_BUTTON,
    SELECT_BTN_1,
    SELECT_BTN_2,
    SELECT_BTN_3,
    SELECT_BTN_4,
    SELECT_BTN_5,
    SELECT_BTN_6,
    LEAVE_BUTTON,
    BUY_BUTTON,
    ANVIL_BUY_BUTTON,
    ANVIL_RIGHT_BUTTON,
    ANVIL_LEFT_BUTTON,
    EXIT_INV_BUTTON,
    UPGRADE_BUTTON,
    DOWN_BTN,
    UP_BTN,
    SORT_BTN,
    RESTART_BTN

];

// All Pressed Images
const BUTTON_PRESSED_IMAGES = [
    'Images/Others/Play_Pressed.png',
    'Images/Others/Left_ButtonPressed.png',
    'Images/Others/Right_ButtonPressed.png',
    'Images/Others/Left_ButtonPressed.png',
    'Images/Others/Right_ButtonPressed.png',
    'Images/Others/Left_ButtonPressed.png',
    'Images/Others/Right_ButtonPressed.png',
    'Images/Others/Left_ButtonPressed.png',
    'Images/Others/Right_ButtonPressed.png',
    'Images/Others/Left_ButtonPressed.png',
    'Images/Others/Right_ButtonPressed.png',
    'Images/Others/Next_Pressed.png',
    'Images/Others/Back_Pressed.png',
    'Images/Others/Back_Pressed.png',
    'Images/Others/Next_Pressed.png',
    'Images/Others/check_Pressed.png',
    'Images/Others/x_Pressed.png',
    "Images/Others/End_Turn_Pressed.png",
    "Images/Others/Info_Pressed.png",
    "Images/Others/Anvil_Pressed.png",
    "Images/Others/Store_Pressed.png",
    "Images/Others/Exit_Pressed.png",
    "Images/Others/Small_Exit_Pressed.png",
    "Images/Others/Select_Pressed.png",
    "Images/Others/Select_Pressed.png",
    "Images/Others/Select_Pressed.png",
    "Images/Others/Select_Pressed.png",
    "Images/Others/Select_Pressed.png",
    "Images/Others/Select_Pressed.png",
    "Images/Others/Leave_Pressed.png",
    "Images/Others/Buy_Pressed.png",
    "Images/Others/Buy_Pressed.png",
    'Images/Others/Right_ButtonPressed.png',
    'Images/Others/Left_ButtonPressed.png',
    "Images/Others/Exit_Pressed.png",
    "Images/Others/Upgrade_Pressed.png",
    "Images/Others/Down_Pressed.png",
    "Images/Others/Up_Pressed.png",
    "Images/Others/Sort_Pressed.png",
    "Images/Others/Restart_Pressed.png"

];

// all unpressed images
const BUTTON_UNPRESSED_IMAGES = [
    'Images/Others/Play_Unpressed.png',
    'Images/Others/Left_Button.png',
    'Images/Others/Right_Button.png',
    'Images/Others/Left_Button.png',
    'Images/Others/Right_Button.png',
    'Images/Others/Left_Button.png',
    'Images/Others/Right_Button.png',
    'Images/Others/Left_Button.png',
    'Images/Others/Right_Button.png',
    'Images/Others/Left_Button.png',
    'Images/Others/Right_Button.png',
    'Images/Others/Next.png',
    'Images/Others/Back.png',
    'Images/Others/Back.png',
    'Images/Others/Next.png',
    'Images/Others/check.png',
    'Images/Others/x.png',
    "Images/Others/End_Turn.png",
    "Images/Others/Info.png",
    "Images/Others/Anvil_Button.png",
    "Images/Others/Store_Button.png",
    "Images/Others/Exit_Button.png",
    "Images/Others/Small_Exit.png",
    "Images/Others/Select.png",
    "Images/Others/Select.png",
    "Images/Others/Select.png",
    "Images/Others/Select.png",
    "Images/Others/Select.png",
    "Images/Others/Select.png",
    "Images/Others/Leave.png",
    "Images/Others/Buy_Button.png",
    "Images/Others/Buy_Button.png",
    'Images/Others/Right_Button.png',
    'Images/Others/Left_Button.png',
    "Images/Others/Exit_Button.png",
    "Images/Others/Upgrade_Button.png",
    "Images/Others/Down_Button.png",
    "Images/Others/Up_Button.png",
    "Images/Others/Sort_Button.png",
    "Images/Others/Restart_Button.png"
];

// --- FPS ---
const FPS = 60;
const FRAME_INTERVAL = 1000/FPS;
const PLAYERSTAGGERFRAMES = [11, 7, 7]; // Controls Animation Speed
const ENEMYSTAGGERFRAMES = [5, 5, 8, 7];


// --- Game Screens --- 
const MENU_SCREEN = document.getElementById('menu');
const BATTLE_SCREEN = document.getElementById('battle');
const SHOP_SCREEN = document.getElementById('shop');
const REST_SCREEN = document.getElementById('rest');
const GAME_SCREENS = [MAP_SCREEN, BATTLE_SCREEN, SHOP_SCREEN, REST_SCREEN];

// --- MAP ELEMENTS ---
const MAP_PADDING = 50;
const MAP_WIDTH = CANVA_WIDTH-MAP_PADDING*2;
const MAP_HEIGHT = CANVA_HEIGHT-MAP_PADDING*2;

// --- BATTLE ELEMENTS ---
const DECK = document.getElementById('deck');
const DECKS = document.getElementById('decks');
const ENEMY_TXT = document.getElementById('enemies-txt');
const HOVERED_CARDS = document.getElementById('hovered-card');
const CARDS_ELEMENT_DIV = document.getElementById('cards');
const FILLED_ENERGY = loadImage('Images/Others/Filled Energy.png');
const EMPTY_ENERGY = loadImage('Images/Others/Empty Energy.png');
const MAIN_HEALTHBAR = document.getElementById("main-healthbar");
const MAIN_HEALTH_TEXT = document.getElementById("main-hp-text");
const SUPPORT_HEALTHBAR = document.getElementById("support-healthbar");
const SUPPORT_HEALTH_TEXT = document.getElementById("support-hp-text");
const BURN_ICON = loadImage('Images/Others/Burned_Icon.png');
const POISON_ICON = loadImage('Images/Others/Poisoned_Icon.png');
const BLOCK_ICON = loadImage('Images/Others/Block_Icon.png');
const EFFECT_ICONS = [BLOCK_ICON, BURN_ICON, POISON_ICON];
const BLOCKING_ICON = loadImage('Images/Others/Wooden_Shield.png');
const ATTACK_ICON = loadImage('Images/Others/Iron_Sword.png');
const MOVE_IOCNS = [BLOCKING_ICON, ATTACK_ICON];
const MOVES = ['Defense', 'Attack']

// --- NEXT WORLD ELEMENTS ---
const NEXT_WORLD_TXT = document.getElementById('next-world-txt');

// healthbar locations
const MAIN_HEALTHBAR_X = [
    BATTLE_CHARACTERX[0]+65,
    BATTLE_CHARACTERX[1]+85,
    BATTLE_CHARACTERX[2]+170,

];
const MAIN_HEALTHBAR_Y = [
    BATTLE_CHARACTERY[0]+295,
    BATTLE_CHARACTERY[1]+178,
    BATTLE_CHARACTERX[2]+344,
];
const SUPPORT_HEALTHBAR_X = [
    SUPPORT_BATTLE_CHARACTERX[0]+15,
    SUPPORT_BATTLE_CHARACTERX[1]+205
];
const SUPPORT_HEALTHBAR_Y = [
    SUPPORT_BATTLE_CHARACTERY[0]+95,
    SUPPORT_BATTLE_CHARACTERY[1]+230
];

// --- SHOP ELEMENTS ---
const textElement = document.querySelector('.text');

// timing for animation
let deltaTimeMultiplier = 1;
let deltaTime = 0;
let previousTime = performance.now();

let playerAnimation;

// --- CHARACTERS ---
let characters = ['Fire Wizard', 'Knight', 'Ninja']; // CHARACTER 
let character = 0; // Selected Character
let supportCharacters = ['Healer', 'Tank'];// Support Character
let supportCharacter = 0;// Selected Support Character
let characterNameX = (CANVA.width/2)-(CHARACTER_NAME.offsetWidth/2.75)
let characterNameY = 125;

// Character Animation States
let playerState = 'Idle'; // Initial Animation State
let animationGameFrame = 0; // Frame Counter
let staggerFrames = 0;

// --- CHARACTERS STAT ---
// --- Base Stats Are Set To Fire Wizard's ---
let critMultiplier = 1.5;
let statPoints;
let minStatPoints;
let health = 150;
let attack = 20;
let defense = 50;
let critDmg = attack * critMultiplier;
let critRate = 15;

//--- SHOW STATS POINTS IN ANY STATS ---
let minCritMultiplier = 1.5;
let minHealth = 150;
let minAttack = 20;
let minDefense = 50;
let minCritRate = 15;


// --- sessionStorage variables --
let mainCharacter;
let secondaryCharcter;

// all cards in the game
let shield = new Card('Shield', 0, 0, 0, 9, ['defense'],  ['self'], 'Grants 9 block', 10, 15, false);
let shieldBash = new Card('Shield Bash', 15, 0, 0, 7,['defense','attack'], ['first'],  'Deals 15 damage to first & grants 7 block', 20, 30, false);
let strike = new Card('Strike', 4, 0, 0, 0,['attack'], ['first'], 'Deal 4 damage to first.', 5, 5, false);
let beserk = new Card('Beserk', 12, 0, 0, 0,['attack'], ['all'], 'Deals 12 damage to all.', 10, 15, false); 
let furyFist = new Card('Fury Fist', 7, 0, 0, 0, ['attack'], ['any'], 'Deal 7 damage to any.', 10, 20, false);
let lunge = new Card('Lunge', 5, 0, 0, 0,['attack'], ['any'], 'Deal 5 damage to any.', 5, 8, false);
let ironWall = new Card('Iron Wall', 0, 0, 0, 15,['defense'], ['self'], 'Grants 15 block', 12, 25, false); 
let rend = new Card('Rend', 15, 0, 0, 0, ['attack'], ['first'], 'Deal 15 damage to first.', 15, 27, false);
let skinOfSteel = new Card('Skin Of Steel', 0, 0, 0, 25, ['defense'], ['self'], 'Grant 25 block', 25, 55, false);

let fireball = new Card('Fire Ball', 3, 0, 4, 0, ['attack'], ['first'], 'Deal 4 damage & apply 4 burn to first.', 5, 15,false); 
let solarFlare = new Card('Solar Flare', 25 , 0, 6, 0, ['attack'], ['all'], 'Deal 25 damage & apply 6 burn to all.', 30, 45,false); 
let ember = new Card('Ember', 10, 0, 4, 0, ['attack'], ['any'], 'Deal 10 damage & apply 3 burn to any.', 15, 20,false); 
let inferno = new Card('Inferno', 0, 0, 4, 0, ['attack'], ['all'], 'Apply 6 burn to all.', 7, 14,false); 
let pyroShield = new Card('Pyro Shield', 0, 0, 0, 6,['defense'], ['self'], 'Grants 6 block', 10, 20,false);
let ignite = new Card('Ignite', 0, 0, 5, 0,  ['attack'], ['any'], 'Apply 5 burn to any.', 5, 10,false);
let flameWall = new Card('Flame Wall', 7, 0, 0, 4, ['defense','attack'], ['first'],  'Grants 4 block & Deal 7 damage to first', 15, 27,false); 
let firestorm = new Card('Firestorm', 16, 0, 4, 0, ['attack'], ['all'], 'Deal 16 damage & apply 4 burn to all.', 30, 42, false); 

let acidBomb = new Card('Acid Bomb', 0, 6, 0, 0,['attack'], ['all'], 'Apply 6 poison to all', 12, 23, false);
let execute = new Card('Execute', 12, 3, 0, 0, ['attack'], ['first'], 'Deal 12 damage & apply 3 poison to first', 13, 21, false);
let poisonAura = new Card('Poison Aura', 0, 0, 0, 16, ['defense'], ['self'], 'Grants 16 block', 14, 25, false);
let poisonClaw = new Card('Poison Claw', 25, 4, 0, 0, ['attack'], ['any'], 'Deal 25 damage & apply 4 poison to any', 25, 36, false);
let poisonStrike = new Card('Poison Strike', 5, 3, 0, 0,['attack'], ['first'], 'Deal 5 damage & apply 3 poison to first', 10, 16, false);

let upgradedShield = new Card('Shield', 0, 0, 0, 15,['defense'],  ['self'], 'Grants 15 block', 10, null,true);
let upgradedShieldBash = new Card('Shield Bash', 20, 0, 0, 14,['defense','attack'], ['self', 'first'],  'Deals 20 damage first & grants 14 block', 40, null,true);
let upgradedStrike = new Card('Strike', 10, 0, 0, 0,['attack'], ['first'], 'Deal 10 damage to first.', 15, null,true);
let upgradedBeserk = new Card('Beserk', 18, 0, 0, 0,['attack'], ['all'], 'Deals 18 damage to all.', 30, null,true); 
let upgradedFuryFist = new Card('Fury Fist', 22, 0, 0, 0,['attack'], ['any'], 'Deal 22 damage any.', 30, null,true);
let upgradedLunge = new Card('Lunge', 8, 0, 0, 0, ['attack'], ['any'], 'Deal 8 damage to any.', 10, null,true);
let upgradedIronWall = new Card('Iron Wall', 0, 0, 0, 30, ['defense'], ['self'], 'Grants 30 block', 40, null,true); 
let upgradedRend = new Card('Rend', 20, 0, 0, 0, ['attack'], ['any'], 'Deal 20 damage to any.', 25, null,true);
let upgradedSkinOfSteel = new Card('Skin Of Steel', 0, 0, 0, 60, ['defense'], ['self'], 'Grant 60 block.', 75, null,true);

let upgradedFireball = new Card('Fire Ball', 4, 0, 10, 0, ['attack'], ['first'], 'Deal 4 damage & apply 10 burn to first.', 20, null,true); 
let upgradedSolarFlare = new Card('Solar Flare', 30, 0, 10, 0, ['attack'], ['all'], 'Deal 30 damage & apply 10 burn to all.', 75, null,true); 
let upgradedEmber = new Card('Ember', 15, 0, 6, 0, ['attack'], ['any'], 'Deal 15 damage & apply 6 burn to first.', 32, null,true); 
let upgradedInferno = new Card('Inferno', 0, 0, 8, 0, ['attack'], ['all'], 'Apply 8 burn to all.', 22, null,true); 
let upgradedPyroShield = new Card('Pyro Shield', 0, 0, 0, 10, ['defense'], ['self'], 'Grants 10 block', 25, null,true);
let upgradedIgnite = new Card('Ignite', 0, 0, 10, 0,  ['attack'], ['any'], 'Apply 10 burn to any.', 21, null,true);
let upgradedFlameWall = new Card('Flame Wall', 11, 0, 0, 8, ['defense','attack'], ['first'],  'Grants 8 block & Deal 11 damage to first', 36, null,true); 
let upgradedFirestorm = new Card('Firestorm', 23, 0, 8, 0, ['attack'], ['all'], 'Deal 23 damage & apply 8 burn to all.', 58, null, true); 

let upgradedAcidBomb = new Card('Acid Bomb', 0, 9, 0 , 0,  ['attack'], ['all'], 'Apply 8 poison to all', 36, null, true);
let upgradedExecute = new Card('Execute', 15, 5, 0, 0,  ['attack'], ['first'], 'Deal 15 damage & apply 5 poison', 27, null, true);
let upgradedPoisonAura = new Card('Poison Aura', 0, 0, 0, 22, ['defense'], ['self'], 'Grants 22 block', 34, null, true);
let upgradedPoisonClaw = new Card('Poison Claw', 27, 7, 0, 0,  ['attack'], ['any'], 'Deal 27 damage & 7 poison to any', 66, null, true);
let upgradedPoisonStrike = new Card('Poison Strike', 7, 5, 0, 0,  ['attack'], ['first'], 'Deal 7 damage & apply 5 poison to first', 19, null, true);

// all cards in the game
const CARDS = [
    fireball,
    solarFlare,
    ember,
    inferno,
    pyroShield,
    ignite,
    flameWall,
    firestorm,
    shield,
    shieldBash,
    strike,
    beserk,
    furyFist,
    lunge,
    ironWall,
    rend,
    skinOfSteel,
    acidBomb,
    execute,
    poisonAura,
    poisonClaw,
    poisonStrike,
    upgradedFireball,
    upgradedSolarFlare,
    upgradedEmber,
    upgradedInferno,
    upgradedPyroShield,
    upgradedIgnite,
    upgradedFlameWall,
    upgradedFirestorm,
    upgradedShield,
    upgradedShieldBash,
    upgradedStrike,
    upgradedBeserk,
    upgradedFuryFist,
    upgradedLunge,
    upgradedIronWall,
    upgradedRend,
    upgradedSkinOfSteel,
    upgradedAcidBomb,
    upgradedExecute,
    upgradedPoisonAura,
    upgradedPoisonClaw,
    upgradedPoisonStrike

];
const CARD_IMAGES = [
    'Images/Cards/Fire Ball.png',
    'Images/Cards/Solar Flare.png',
    'Images/Cards/Ember.png',
    'Images/Cards/Inferno.png',
    'Images/Cards/Pyro Shield.png',
    'Images/Cards/Ignite.png',
    'Images/Cards/Flame Wall.png',
    'Images/Cards/Fire Storm.png',
    'Images/Cards/Shield.png',
    'Images/Cards/Shield Bash.png',
    'Images/Cards/Strike.png',
    'Images/Cards/Beserk.png',
    'Images/Cards/Fury Fist.png',
    'Images/Cards/Lunge.png',
    'Images/Cards/Iron Wall.png',
    'Images/Cards/Rend.png',
    'Images/Cards/Skin Of Steel.png', 
    'Images/Cards/Acid Bomb.png', 
    'Images/Cards/Execute.png', 
    'Images/Cards/Poison Aura.png', 
    'Images/Cards/Poison Claw.png',
    'Images/Cards/Poison Strike.png',  
    'Images/Cards/Upgraded Fire Ball.png',
    'Images/Cards/Upgraded Solar Flare.png',
    'Images/Cards/Upgraded Ember.png',
    'Images/Cards/Upgraded Inferno.png',
    'Images/Cards/Upgraded Pyro Shield.png',
    'Images/Cards/Upgraded Ignite.png',
    'Images/Cards/Upgraded Flame Wall.png',
    'Images/Cards/Upgraded Fire Storm.png',
    'Images/Cards/Upgraded Shield.png',
    'Images/Cards/Upgraded Shield Bash.png',
    'Images/Cards/Upgraded Strike.png',
    'Images/Cards/Upgraded Beserk.png',
    'Images/Cards/Upgraded Fury Fist.png',
    'Images/Cards/Upgraded Lunge.png',
    'Images/Cards/Upgraded Iron Wall.png',
    'Images/Cards/Upgraded Rend.png',
    'Images/Cards/Upgraded Skin Of Steel.png',
    'Images/Cards/Upgraded Acid Bomb.png', 
    'Images/Cards/Upgraded Execute.png', 
    'Images/Cards/Upgraded Poison Aura.png', 
    'Images/Cards/Upgraded Poison Claw.png',
    'Images/Cards/Upgraded Poison Strike.png'
];

//--- CHARACTER PARTY ---
let party = new Array(2);
party[0] = new Character()
party[1] = new SupportCharacter()
let characterHitBox;
let supportHitBox;
let playerDead = false;
let supportDead = false;

// decks and card elements
let playerDeck = []; 
let drawDeck = [];
let hand = [];
let cardElements = [];
let cardElementsHoveringStatus = [];
let discardPile = [];
let shopCards = [];
let selectedCard;
let boughtCards = [];
let cardElementClickStatus = [];
let cardTitleElements = [];
let cardDescriptionElements = [];
let cardCostElements = [];

// -- inventories
let showInv = false;
let deckCardElements = [];
let deckCardCostElements = [];
let deckCardTitleElements = [];
let deckCardDescrpitionElements = [];
let sortedCards;
let row = 0;
let sortingTypes = [sortCardsByName, sortCardsByType];
let sortingTypesNames = ['Name', 'Type'];
let sortType = 0;

// starter decks
let fireWizardDeck = [fireball,fireball,fireball,solarFlare,ember,flameWall,pyroShield,pyroShield, pyroShield,ignite,ignite];
let knightDeck = [shield, shield, shieldBash, strike, strike, beserk, rend, rend, lunge, skinOfSteel, skinOfSteel];
let ninjaDeck = [execute, acidBomb, acidBomb, execute, poisonAura, poisonAura, poisonClaw, poisonClaw, poisonStrike, beserk, strike];

// Enemies
let enemies;
let enemiesHPBar = [];
let enemiesHPText = [];
let enemyHitBoxes = [];
let enemyAnimations;
let enemyGameFrames;
let enemyBurn = true;
let enemyMove = true;
let enemyPoison = true;

// --- MAP ELEMENTS ---
let mapElements = [];
let eventLocationBoxWidth;
let eventLocationBoxHeight;
let eventMap = [];

// --- Screen States ---
let menu = true;
let shopMenu =false;
let anvilMenu = false;
let characterSelection = false;
let supportSelection = false;
let characterSelectionPage = 1;
let game = false;
let gameStates = ['battle','shop','rest'];
let gamestate;
let playerTurn = true;
let transition = false;
let resting = false;

// --- MENU BACKGROUND SCROLLING ---
let menu1x = 0;
let menu2x = CANVA_WIDTH;

// --- Drawing the animations ---
let characterBgX = 300;
let characterBgStatX = 475;
let characterBgY = 50;

// --- Tracking Amount of stat point ---
let amountOfHpPoints = 0;
let amountOfAtkPoints = 0;
let amountOfDefPoints = 0;
let amountOfCritMultiPoints = 0;
let amountOfCritRatePoints = 0;
let currency = 0;
let exp = 0;
let playerExp = 0;

// --- Animation and Game Loop ---
let lastTime;
let enemyTurnEndTiming;
let enemyTurnInitialTiming;

// Progress of the transition 
let progress = 0; 
let turnCounter = 0 ;

// --- Boolean Values ---
let moveLeft = false;
let moveRight = false;
let printButtons = false;
let findMinStats = true;

let infoPage = false;
let pageOneInfo = false;
let pageTwoInfo = false;
let pageThreeInfo = false;



// --- Shop Elements ---
// text Animations 
let textCounter = 0;
let merchantSpeech = 'Hello Fellow Adventurer.';
let speed = 50;
let changeMerchantTxt = true;
let upgradingStats = false;
let moveBuyTxt = false;

// cards
let costCard;
let shopCardTitleElement;
let shopCardDescriptionElement;
let shopCardCostElement;
let shopCardElement;
let cardSelected = false;
let anvilCardElements;
let anvilCardTitleElements;
let anvilCardCostElements;
let anvilCardDescrpitionElements;
let upgradeAnvilCardElements;
let upgradeAnvilCardTitleElements;
let upgradeAnvilCardCostElements;
let upgradeAnvilCardDescrpitionElements;
let upgradedIndex = 0;


//--- EVENT LISTENER ---
document.addEventListener('mousedown', buttonDownAnimation);
document.addEventListener('mouseup', buttonUpAnimation);
document.addEventListener('click', buttonClick); //  triggers buttonClick function whenever a click event occurs.
document.addEventListener('contextmenu', disableRightClick)
document.addEventListener('mouseover', hoverElement)


// --- Animation Setup --- 
// Character Animation Frames Setup
function renderAnimation(states, spriteWidth, spriteHeight) {
    const animations = {};

    // Loop through each state to calculate frame positions
    states.forEach((state, index) => {
        let frames = { location: new Array(state.frames) };
        for (let i = 0; i < frames.location.length; i++) {
            let positionX = i * spriteWidth;
            let positionY = index * spriteHeight;
            frames.location[i] = ({ x: positionX, y: positionY });
        }
        animations[state.name] = frames;
    });

    return animations;
}

//--- Sets Variable To A Image ---
function loadImage(src) {
    const img = new Image();
    img.src = src;
    return img;
}

//---  animates character ---
function animateMainCharacters(characterName){
    let character;
    let animation;
    let x;
    let y;
    
    // check which character to animate
    for (let i in characters){
        if (characterName === characters[i]){
            character = i;
            animation = CHARACTER_ANIMATIONS[i]
            break
        }
    }
    
    // check if the player is in game and not the menu
    if (!game){
        x = MENU_CHARACTERX[character];
        y = MENU_CHARACTERY[character]; 
    }
    else{
        x = BATTLE_CHARACTERX[character];
        y = BATTLE_CHARACTERY[character];
    }
    let staggerFrames =  PLAYERSTAGGERFRAMES[character];
    
    let playerAnimation = animation;// the animation for the character
    let width = CHARACTER_WIDTHS[character]; // width of each frame of the animation
    let height = CHARACTER_HEIGHTS[character];// height of each frame of the animation
    let scaleWidth = CHARACTER_WIDTHS[character]*CHARACTER_SCALE_SIZE[character]// scaling the character width to be bigger
    let scaleHeight = CHARACTER_HEIGHTS[character]*CHARACTER_SCALE_SIZE[character];// scaling the character height to be bigger
    let drawCharacters = CHARACTERS[character];// which character is being animated (wizard , ninja , or knight)
    
    // Draw Character Animation
    let position = Math.floor(animationGameFrame / staggerFrames) % playerAnimation[playerState].location.length;
    let frameX = width * position;
    let frameY = playerAnimation[playerState].location[position].y;
    CTX.drawImage(drawCharacters, frameX, frameY, width, height,x ,y, scaleWidth, scaleHeight);

    // check if the enemy is hurt and runs the animation
    
    if (playerState == 'Hurt'){
        if (position >= playerAnimation[playerState].location.length - 1){
            playerState = 'Idle';
        }
    }

    // check if the enemy is dead and runs the animation
    else if (playerState == 'Death'){
        
        if (position >= playerAnimation[playerState].location.length - 1){
            playerDead = true;
            transition = "Start";
            startTransition();
        }
    }
}


//--- animates a enemy character ---
function animateEnemy(enemyName, enemyPosition, enemyCount){
    let enemy;
    let animation;
    // check which character to animate
    for (let i in ENEMY_NAMES){
        if (enemyName === ENEMY_NAMES[i]){
            enemy = i;
            animation = ENEMY_ANIMATIONS[i];
            break
        }
    } 
    // get the x location
    let x = ENEMY_XOFFSET[enemy]-100*enemyPosition;
    
    let y = ENEMY_YOFFSET[enemy];
    
    let staggerFrames =  ENEMYSTAGGERFRAMES[enemy];
    let enemyAnimation = animation;// the animation for the enemy
    let width = ENEMY_WIDTHS[enemy]; // width of each frame of the animation
    let height = ENEMY_HEIGHTS[enemy];// height of each frame of the animation
    let scaleWidth = ENEMY_WIDTHS[enemy]*ENEMY_SCALE_SIZE[enemy]// scaling the enemy width to be bigger
    let scaleHeight = ENEMY_HEIGHTS[enemy]*ENEMY_SCALE_SIZE[enemy];// scaling the character height to be bigger
     
    let drawEnemy = ENEMIES_SPRITESHEETS[enemy];// which enemy is being animated
    
    // Draw Character Animation
    
    let position = Math.floor(enemyGameFrames[enemyPosition] / staggerFrames) % enemyAnimation[enemyAnimations[enemyPosition]].location.length;
    let frameX = width * position;
    let frameY = enemyAnimation[enemyAnimations[enemyPosition]].location[position].y;
    CTX.drawImage(drawEnemy, frameX, frameY, width, height, x , y, scaleWidth, scaleHeight);
 
    // check if the enemy is hurt and runs the animation
    if (enemyAnimations[enemyPosition] == 'Hurt'){
        if (position >= enemyAnimation[enemyAnimations[enemyPosition]].location.length - 1){
            enemyAnimations[enemyPosition] = 'Idle';
        }
    }

    // check if the enemy is dead and runs the animation
    else if (enemyAnimations[enemyPosition] == 'Death'){

        if (position >= enemyAnimation[enemyAnimations[enemyPosition]].location.length - 1){
            
            // removes the enemy from the battle
            enemyHitBoxes[enemyPosition].remove();
            enemiesHPText[enemyPosition].remove();
            enemiesHPBar[enemyPosition].remove();
            enemies[enemyPosition] = null;
            enemyAnimations[enemyPosition] = null;
            enemyHitBoxes[enemyPosition] = null;
            enemiesHPText[enemyPosition] = null;
            enemiesHPBar[enemyPosition] = null;
            enemyBurn = true;
            enemyMove = true;
            enemyPoison = true;

            // check if all enemies are dead
            for(let enemy in enemies){
                if (enemies[enemy] != null){
                    return;
                }
            }

            // exit battle if all enemies are dead
            transition = 'Start';
            startTransition();

            // remove all cards from hand
            for (let card = 0; card < hand.length; card++){
                cardElements[card].remove();
                cardTitleElements[card].remove();
                cardCostElements[card].remove();
                cardDescriptionElements[card].remove();
            }
            if (hand != ''){
                cardElements = [];
                cardElementClickStatus = [];
                hand = [];
                cardElementsHoveringStatus = [];
                cardTitleElements = [];
                cardDescriptionElements = [];
                cardCostElements = [];   
            }

            // save game
                
        }
    }
    
}






// Runs 90% of the game here
// Animation Rendering
function animate() {
    // Start by clear screen everytime
    CTX.clearRect(0, 0, CANVA_WIDTH, CANVA_HEIGHT);
    positionElement(INFO_BUTTON, CANVA, 970, 5); 

    //position death elements 
    positionElement(DEATH_TXT, CANVA, CANVA_WIDTH/2 - DEATH_TXT.offsetWidth/2,CANVA_HEIGHT/3- DEATH_TXT.offsetHeight/2);
    positionElement(RESTART_BTN, CANVA, 450,400);

    // position Next World Elements
    positionElement(NEXT_WORLD_TXT, CANVA,CANVA_WIDTH/2 - NEXT_WORLD_TXT.offsetWidth/2,CANVA_HEIGHT/3- NEXT_WORLD_TXT.offsetHeight/2);




    // Menu Screen
    if (menu) {
        // Draw Menu Background
        CTX.drawImage(MENU_BACKGROUND1, menu1x, 0, CANVA_WIDTH, CANVA_HEIGHT);
        CTX.drawImage(MENU_BACKGROUND2, menu2x, 0, CANVA_WIDTH, CANVA_HEIGHT);
        positionElement(PLAY_BUTTON, CANVA, (CANVA.width/2)-(PLAY_BUTTON.width/2), 375); 
        
        TITLE.innerText= "Mentor Quest"; // name of the game
        positionElement(TITLE, CANVA, CANVA.width/2-TITLE.offsetWidth/2, 100);

        

        // Transition to go from menu to character selection
        if (transition == 'Start'){
            startTransition();
        }
    }

   

    // Game Screen
    else if (game){
        COINS_TXT.innerText = currency;
        // check if the game state is the map
        if (gamestate === gameStates[0]){


            // show the amount of currency on map screen 
            COIN_DISPLAY.style.zIndex = 0;
            COINS_TXT.style.zIndex = 0;
            COIN_DISPLAY.style.display = 'block';
            COINS_TXT.style.display = 'block';

            //position the currency elements
            positionElement(COIN_DISPLAY,CANVA, 50,20);
            positionElement(COINS_TXT, CANVA, 80, 15);

            // fill background with black
            CTX.fillStyle = 'black';
            CTX.fillRect(0,0, CANVA_WIDTH,CANVA_HEIGHT);

            // draw map image
            CTX.drawImage(MAP_IMG, 0, 0, MAP_IMG.width, MAP_IMG.height, 0, 0, CANVA_WIDTH, CANVA_HEIGHT);
            // draw connections between events
            connection()

            // adjust all map elements to the canvas position
            for (let stage = 0; stage < mapElements.length; stage++){
                for (let event = 0; event < mapElements[stage].length; event++){
                    positionElement(mapElements[stage][event], CANVA,MAP_PADDING+(eventLocationBoxWidth*stage)+12.5, MAP_PADDING+ (eventLocationBoxHeight*event))
                }
            }
        }

        // check if game is on the battle
        else if (gamestate === gameStates[1]){
            // hide the coins
            COIN_DISPLAY.style.display = 'none';
            COINS_TXT.style.display = 'none';

            // draw the background
            CTX.drawImage(BATTLE_BACKGROUND, 0, 0,BATTLE_BACKGROUND.width,BATTLE_BACKGROUND.height, 0, 0, CANVA_WIDTH, CANVA_HEIGHT)
                
            // Draw Character Animation
            animateMainCharacters(party[0].name);

            if (!supportDead){
                animateSupportCharacters(party[1].name);
            }
            

            //position the overlay to only cover canva 
            //not the whole web page 
            positionElement(INV_OVERLAY,CANVA,0,0)
            
            // if the user wants to check inventory
            // check for showInv
            if (showInv){
                //position Buttons
                positionElement(EXIT_INV_BUTTON, CANVA, 462, 510)
                positionElement(UP_BTN, CANVA, 495, 110);
                positionElement(DOWN_BTN, CANVA, 495, 460);
                positionElement(SORT_BTN, CANVA, 650, 25)
                positionElement(SORT_TXT, CANVA, 750, 10)
                positionElement(INV_TXT, CANVA, 455, -15)
                
                // postion the cards for the inv equal distance apart 
                for (let cardIndex = 0+row*5; cardIndex < 10*(row+1); cardIndex++){
                    if (cardIndex < playerDeck.length){
                        // only 5 cards in one row 
                        if (cardIndex < 5+row*5){ 
                            positionElement(deckCardElements[cardIndex], CANVA, 220+ 120*(cardIndex-(row*5)), 155);
                            positionElement(deckCardTitleElements[cardIndex], CANVA, 230+ 120*(cardIndex-(row*5)), 150);
                            
                            positionElement(deckCardDescrpitionElements[cardIndex], CANVA, 225+120*(cardIndex-(row*5)), 255-deckCardDescrpitionElements[cardIndex].offsetHeight/2);
            
                        }
                        else{
                            positionElement(deckCardElements[cardIndex], CANVA, 220+ 120*((cardIndex-5)-(row*5)), 315);
                            positionElement(deckCardTitleElements[cardIndex], CANVA, 230+ 120*((cardIndex-5)-(row*5)), 310);
                            
                            positionElement(deckCardDescrpitionElements[cardIndex], CANVA, 225+ 120*((cardIndex-5)-(row*5)), 415-deckCardDescrpitionElements[cardIndex].offsetHeight/2);
            
                        }
                    }

                }
                //position the background for the inventory
                positionElement(INV_BG,CANVA,CANVA_WIDTH/2-INV_BG.width/2,0)

            }

            // get the number of alive enemies
            let enemyCount = 0;
            for (let enemy in enemies){
                if (enemies[enemy] != null){
                    enemyCount += 1;
                }
            }
            // update the alive enemy text
            ENEMY_TXT.innerText = "ENEMIES LEFT: "+ enemyCount;
            positionElement(ENEMY_TXT, CANVA, CANVA_WIDTH/2 - 92, -20);

            // Draw Enemy Animation and health
            for (let enemy in enemies){
                // check if enemy is still alive
                if (enemies[enemy] != null){

                    // animate enemies
                    animateEnemy(enemies[enemy].name, enemy, enemyCount)
                }

                // postion enemies hp bar, hitbox, effects, next move 
                // check if enemy is still alive
                if (enemies[enemy] != null){
                    // check which enemy the enemy is
                    for (let enemyName in ENEMY_NAMES){
                        if (enemies[enemy].name === ENEMY_NAMES[enemyName]){
                            // position their healthbars and hit boxes according to the enemy
                            positionElement(enemiesHPBar[enemy], CANVA, ENEMY_HPBAR_XPOS[enemyName]-100*enemy, ENEMY_HPBAR_yPOS[enemyName])
                            positionElement(enemiesHPText[enemy], CANVA, ENEMY_HPTEXT_XPOS[enemyName]+5-100*enemy, ENEMY_HPTEXT_YPOS[enemyName])
                            positionElement(enemyHitBoxes[enemy], CANVA, ENEMY_HITBOX_XOFFSET[enemyName]-100*enemy, ENEMY_HITBOX_YOFFSET[enemyName]);

                            // numEffects = 0 for each enemy at start
                            let numEffects = 0;
                            // position effects
                            for (let effect in EFFECT_ICONS){
                                
                                if (enemies[enemy].effects[effect] > 0){
                                    CTX.fillStyle = "white"; // Fill color
                                    CTX.textAlign = "center"; // Center text horizontally
                                    CTX.drawImage(EFFECT_ICONS[effect], ENEMY_EFFECT_ICON_XOFFSET[enemyName]-100*enemy+25*numEffects,ENEMY_EFFECT_ICON_YOFFSET[enemyName]);
                                    CTX.fillText(enemies[enemy].effects[effect], ENEMY_EFFECT_ICON_XOFFSET[enemyName]+20-100*enemy+25*numEffects, ENEMY_EFFECT_ICON_YOFFSET[enemyName]+25);
                                    
                                    numEffects++;
                                }
                            }
                            // display the type of move the enemy is going to do 
                            for (let move in MOVES){
                                
                                if (enemies[enemy].nextMoveType == MOVES[move]){
                                    
                                    if (enemies[enemy].endTurn != true){
                                        CTX.fillStyle = "white"; // Fill color
                                        CTX.textAlign = "center"; // Center text horizontally
                                        CTX.font = '20px MyCustomFont';
                                        CTX.drawImage(MOVE_IOCNS[move], ENEMY_MOVE_ICON_XOFFSET[enemyName]-100*enemy, ENEMY_MOVE_ICON_YOFFSET[enemyName])
                                        CTX.fillText(enemies[enemy].nextMove, ENEMY_MOVE_ICON_XOFFSET[enemyName]-100*enemy-20, ENEMY_MOVE_ICON_YOFFSET[enemyName]+20)
                                        CTX.font = '10px Arial';
                                    }
                                    
                                }
                            }                            
                        }  
                    }
                    // update the healthbar
                    enemiesHPText[enemy].innerText = enemies[enemy].health+"/"+enemies[enemy].maxHealth;
                    enemiesHPBar[enemy].value = enemies[enemy].health;
                }
                
            }
            
            // position elements
            positionElement(DECK, CANVA, 50, 440);

            // position healthbars
            MAIN_HEALTH_TEXT.innerText = Math.floor(party[0].health)+"/"+party[0].maxHealth;
            SUPPORT_HEALTH_TEXT.innerText = Math.floor(party[1].health)+"/"+ party[1].maxHealth;
            MAIN_HEALTHBAR.value = party[0].health;
            SUPPORT_HEALTHBAR.value = party[1].health;

            // position the character hitboxes, effects, and healthbar
            for (let character in characters){
                
                // check which character the character is
                if (party[0].name == characters[character]){
                    positionElement(characterHitBox, CANVA, CHARACTER_HITBOX_XOFFSET[character], CHARACTER_HITBOX_YOFFSET[character])
                    positionElement(MAIN_HEALTHBAR, CANVA, MAIN_HEALTHBAR_X[character], MAIN_HEALTHBAR_Y[character])
                    positionElement(MAIN_HEALTH_TEXT, CANVA, MAIN_HEALTHBAR_X[character]+MAIN_HEALTH_TEXT.offsetWidth/2, MAIN_HEALTHBAR_Y[character]-20)
                    
                    // draw the effects for the character
                    let numEffects = 0;
                    for (let effect in EFFECT_ICONS){
                        
                        // check effects and draw them 
                        if (party[0].effects[effect] > 0){
                            CTX.fillStyle = "white"; // Fill color
                            CTX.textAlign = "center"; // Center text horizontally
                            CTX.drawImage(EFFECT_ICONS[effect], BATTLE_CHARACTERX_ICONS[character]+25*numEffects, BATTLE_CHARACTERY_ICONS[character]);
                            CTX.fillText(party[0].effects[effect], BATTLE_CHARACTERX_ICONS[character]+25*numEffects+20, BATTLE_CHARACTERY_ICONS[character]+25);
                            numEffects++;
                        }
                    }   
                    break;
                }
            }

            // position the support characters healthbar, hitbox, and effects
            for (let supportCharacter in supportCharacters){
                
                if (party[1].name == supportCharacters[supportCharacter]){
                    positionElement(supportHitBox, CANVA, SUPPORT_CHARACTER_HITBOX_XOFFSET[supportCharacter], SUPPORT_CHARACTER_HITBOX_YOFFSET[supportCharacter])
                    positionElement(SUPPORT_HEALTHBAR, CANVA, SUPPORT_HEALTHBAR_X[supportCharacter], SUPPORT_HEALTHBAR_Y[supportCharacter])
                    positionElement(SUPPORT_HEALTH_TEXT, CANVA, SUPPORT_HEALTHBAR_X[supportCharacter]+SUPPORT_HEALTH_TEXT.offsetWidth/2, SUPPORT_HEALTHBAR_Y[supportCharacter]-20)
                    break
                }
                
            }
            
            // draw the cards
            for (let cardIndex in hand){
                let centerOffset = (hand.length - 1) / 2; // Center of the hand
                let yOffSet = Math.abs(cardIndex-centerOffset)
                let xOffSet = cardIndex-centerOffset
                let rotation = (cardIndex-centerOffset)*9
                
                // check if hovering over a card
                if(cardElementsHoveringStatus[cardIndex] == true){
                    
                    // check if card is clicked
                    if (cardElementClickStatus[cardIndex] === true){
                        if (yOffSet == 0){
                            positionElement(cardElements[cardIndex], CANVA, 450, 350);
                            positionElement(cardTitleElements[cardIndex], CANVA, 460, 317);
                            positionElement(cardCostElements[cardIndex], CANVA, 450, 343-cardTitleElements[cardIndex].offsetHeight/2);
                            positionElement(cardDescriptionElements[cardIndex], CANVA, 450, 472-cardDescriptionElements[cardIndex].offsetHeight/2);
                        }
                        else{
                            positionElement(cardElements[cardIndex], CANVA, 450+75*xOffSet, 340+15*yOffSet);
                            positionElement(cardTitleElements[cardIndex], CANVA, 460+86.5*xOffSet, 307+17*yOffSet);
                            
                            positionElement(cardDescriptionElements[cardIndex], CANVA, 455+65.5*xOffSet, 447+15.3*yOffSet);
                        }
                    }

                    // check if card is not clicked
                    else{
                        if (yOffSet == 0){
                            positionElement(cardElements[cardIndex], CANVA, 450, 380);
                            positionElement(cardTitleElements[cardIndex], CANVA, 460, 347);
                            
                            positionElement(cardDescriptionElements[cardIndex], CANVA, 452, 500-cardDescriptionElements[cardIndex].offsetHeight/2);
                        }
                        else{
                            positionElement(cardElements[cardIndex], CANVA, 450+75*xOffSet, 370+15*yOffSet);
                            positionElement(cardTitleElements[cardIndex], CANVA, 460+86.5*xOffSet, 337+17*yOffSet);
                            
                            positionElement(cardDescriptionElements[cardIndex], CANVA, 455+65.5*xOffSet, 477+15.3*yOffSet);
                        }
                    }
                    // rotate and scale cards
                    cardElements[cardIndex].style.transform = 'rotate(' + String(rotation) + 'deg) scale(1.5)';
                    cardTitleElements[cardIndex].style.transform = 'rotate(' + String(rotation) + 'deg) scale(1.5)';
                    
                    cardDescriptionElements[cardIndex].style.transform = 'rotate(' + String(rotation) + 'deg) scale(1.5)';
                }
                // check if not hovering of card
                else{
                    
                    //if card is clicked
                    if (cardElementClickStatus[cardIndex] === true){
                        if (yOffSet == 0){
                            positionElement(cardElements[cardIndex], CANVA, 450, 350);
                            positionElement(cardTitleElements[cardIndex], CANVA, 460, 344);
                            positionElement(cardCostElements[cardIndex], CANVA, 450, 362-cardTitleElements[cardIndex].offsetHeight/2);
                            positionElement(cardDescriptionElements[cardIndex], CANVA, 450, 449-cardDescriptionElements[cardIndex].offsetHeight/2);
                        }
                        else{
                            positionElement(cardElements[cardIndex], CANVA, 450+75*xOffSet, 340+15*yOffSet);
                            positionElement(cardTitleElements[cardIndex], CANVA, 460+82.5*xOffSet, 334+15.8*yOffSet);
                            positionElement(cardCostElements[cardIndex], CANVA, 450+81.25*xOffSet, 345+15.8*yOffSet);
                            positionElement(cardDescriptionElements[cardIndex], CANVA, 455+69*xOffSet, 427+15.3*yOffSet);
                        }
                    }
                    else{ // if card is not click 
                        if (yOffSet == 0){
                            positionElement(cardElements[cardIndex], CANVA, 450, 380);
                            positionElement(cardTitleElements[cardIndex], CANVA, 460, 374);
                            positionElement(cardCostElements[cardIndex], CANVA, 450, 384.5);
                            positionElement(cardDescriptionElements[cardIndex], CANVA, 455, 467);
                        }
                        else{
                            positionElement(cardElements[cardIndex], CANVA, 450+75*xOffSet, 370+15*yOffSet);
                            positionElement(cardTitleElements[cardIndex], CANVA, 460+82.5*xOffSet, 364+15.8*yOffSet);
                            positionElement(cardCostElements[cardIndex], CANVA, 450+81.25*xOffSet, 375+15.8*yOffSet);
                            positionElement(cardDescriptionElements[cardIndex], CANVA, 455+69*xOffSet, 457+15.3*yOffSet);
                        }
                    }
                    // rotate cards
                    cardElements[cardIndex].style.transform = 'rotate(' + String(rotation) + 'deg)';
                    cardTitleElements[cardIndex].style.transform = 'rotate(' + String(rotation) + 'deg)';
                    cardCostElements[cardIndex].style.transform = 'rotate(' + String(rotation) + 'deg)';
                    cardDescriptionElements[cardIndex].style.transform = 'rotate(' + String(rotation) + 'deg)';
                }
            }

            // check if on player turn
            if (playerTurn){
                // get the number of energy the player has
                let numEnergy = party[0].energy;
                
                // loop through all energys
                for (let i = 0; i < party[0].maxEnergy; i++){
                    
                    // draw the number of energy the player has
                    if (numEnergy > 0 ){
                        CTX.drawImage(FILLED_ENERGY, 0, 0, FILLED_ENERGY.width, FILLED_ENERGY.height, 9+(20*(1+i)), 415, FILLED_ENERGY.width, FILLED_ENERGY.height)
                        numEnergy -= 1
                    }
                    else{
                        CTX.drawImage(EMPTY_ENERGY, 0, 0, EMPTY_ENERGY.width, EMPTY_ENERGY.height, 9+(20*(1+i)), 415, EMPTY_ENERGY.width, EMPTY_ENERGY.height)
                    }
                
                
                }
                // change text to YOUR TURN
                TURN_TXT.innerText = "YOUR TURN";
            }
            else if(!playerTurn) {
                // change text to OPPONENT TURN
                TURN_TXT.innerText = "OPPONENT TURN";
            }

            // position end turn button 
            positionElement(END_TURN_BUTTON, CANVA, 800, 480); 
        }
        // check if the game state is the shop
        else if( gamestate === gameStates[2]){

            //bring to the front of the screen 
            COINS_TXT.style.zIndex = 2;
            COIN_DISPLAY.style.zIndex = 2;

            // Position all needed elements for the shop
            // not all elements will be visible 
            CTX.drawImage(SHOP_BACKGROUND, 0, 0, SHOP_BACKGROUND.width, SHOP_BACKGROUND.height, 0, 0, CANVA_WIDTH, CANVA_HEIGHT)
            positionElement(MERCHANT, CANVA, (CANVA_WIDTH/2-MERCHANT.width)+75, (CANVA_HEIGHT/2+MERCHANT.height/2)-100);
            positionElement(SHOP_IMG, CANVA, 0, 230); 
            positionElement(MERCHANT_TEXT, CANVA, 200, 100);
            positionElement(ANVIL, CANVA, CANVA_WIDTH - 300, 270);
            positionElement(SHOP_BG, CANVA, CANVA_WIDTH/2 - SHOP_BG.width/2, 0); 
            positionElement(SHOP_OVERLAY, CANVA, 0, 0);

            //Position Button Elements 
            positionElement(EXIT_BUTTON, CANVA, 750, 25);  
            positionElement(LEAVE_BUTTON, CANVA, 440, 525);        
            positionElement(BUY_BUTTON, CANVA, 650, 400);  
            positionElement(ANVIL_LEFT_BUTTON, CANVA, 200, CANVA_HEIGHT/2-ANVIL_LEFT_BUTTON.height/2);
            positionElement(ANVIL_RIGHT_BUTTON, CANVA, CANVA_WIDTH-230, CANVA_HEIGHT/2-ANVIL_LEFT_BUTTON.height/2);
  

            positionElement(COST_TXT, CANVA, 570, 395);
            positionElement(SHOP_TXT, CANVA, CANVA_WIDTH/2- 50, -20);
            positionElement(COINS_TXT, CANVA, 180, 505);

            positionElement(COIN_DISPLAY,CANVA, 150,510);

            // position in the middle of card 
            //if the text is not enough money
            if (moveBuyTxt == true){
                positionElement(BUY_TXT, CANVA, 635, 360);
                setTimeout(() => { // run inside code after 1 sec 
                    // set false so it doesn't run again
                    moveBuyTxt = false;
                }, 500); 

            }else{ // set back to reg position
                positionElement(BUY_TXT, CANVA, 655, 360);
            }
            
            if (BUY_TXT.innerText == "NOT IN STOCK"){
                positionElement(BUY_TXT, CANVA, 648, 360);
            }

            // position all cards in the shop
            for (let cardIndex in shopCards){
                
                // position the first 3 cards in the first row
                if (cardIndex <= 2){
                    positionElement(cardElements[cardIndex], CANVA, 200+ 120*cardIndex, 100);
                    positionElement(cardTitleElements[cardIndex], CANVA, 210+ 120*cardIndex, 95);
                    positionElement(cardCostElements[cardIndex], CANVA, 200+ 120*cardIndex, 118-cardCostElements[cardIndex].offsetHeight);
                    positionElement(cardDescriptionElements[cardIndex], CANVA, 205+ 120*cardIndex, 200-cardDescriptionElements[cardIndex].offsetHeight/2);
    
                }
                // position the last 3 cards in the second row
                else if (cardIndex > 2){
                    positionElement(cardElements[cardIndex], CANVA, 200+ 120*(cardIndex - 3), 100+190);
                    positionElement(cardTitleElements[cardIndex], CANVA, 210+ 120*(cardIndex - 3), 95+190);
                    positionElement(cardCostElements[cardIndex], CANVA, 200+ 120*(cardIndex - 3), 308-cardCostElements[cardIndex].offsetHeight);
                    positionElement(cardDescriptionElements[cardIndex], CANVA, 205+ 120*(cardIndex - 3), 390-cardDescriptionElements[cardIndex].offsetHeight/2);
    
                }
                
            }

            // position each selection button for each card on sale
            for (let selectionbtn = 0; selectionbtn < 6; selectionbtn++){
                if (selectionbtn <= 2){
                    positionElement(SELECTION_BUTTONS[selectionbtn], CANVA, 210+ 120*selectionbtn, 235);
                }else if (selectionbtn > 2){
                    positionElement(SELECTION_BUTTONS[selectionbtn], CANVA, 210+ 120*(selectionbtn - 3), 425);

                }
            }

            // check if the bigger store button is used and reposition
            if (BUTTON_PRESSED_IMAGES[20] == 'Images/Others/Larger_Store_Pressed.png'){
                positionElement(SHOP_BUTTON, CANVA, 240, 20);

            }
            else{
                positionElement(SHOP_BUTTON, CANVA, 250, 25); 
            }

            // check if the bigger anvil button is used and reposition
            if (BUTTON_PRESSED_IMAGES[19] == 'Images/Others/Larger_Anvil_Pressed.png'){
                positionElement(ANVIL_BUTTON, CANVA, 120, 20); 

            }
            else{
                positionElement(ANVIL_BUTTON, CANVA, 130, 25); 
            }

            // make the text write out on the screen
            if(changeMerchantTxt == true){
                setInterval(() => {
                    merchantSpeech = "Hello Fellow Adventurer. You Can Buy New Cards Or Buy Upgraded Version Of Your Cards Here";
                    typeWriter();
                }, 3000);
                changeMerchantTxt = false;    
            }

            // check which card is selected in the shop and position it
            if (cardSelected){
                positionElement(shopCardElement, CANVA,645,170);
                positionElement(shopCardTitleElement, CANVA, 615, 95);
                positionElement(shopCardCostElement, CANVA, 595, 115);
                positionElement(shopCardDescriptionElement, CANVA, 605, 280);

                // show the buy button of the card
                BUY_BUTTON.style.display = 'block';
                for (let shopCardIndex in shopCards){
                    if (shopCards[shopCardIndex].name == shopCardTitleElement.innerText){
                        COST_TXT.innerText = "Cost: "+ shopCards[shopCardIndex].buyCost;
                    }
                }

            }

            // check if on the anvil menu
            if (anvilMenu){

                // position the unupgraded card and upgraded card
                CARD_INDEX_TXT.innerText = "CARD:"+ (upgradedIndex + 1)
                positionElement(CARD_INDEX_TXT,CANVA,600,435)
                positionElement(anvilCardElements, CANVA,285,220);
                positionElement(anvilCardTitleElements, CANVA, 255, 145);
                positionElement(anvilCardCostElements, CANVA, 235, 165);
                positionElement(anvilCardDescrpitionElements, CANVA, 245, 330);

                positionElement(upgradeAnvilCardElements, CANVA,625,220);
                positionElement(upgradeAnvilCardTitleElements, CANVA, 595, 145);
                positionElement(upgradeAnvilCardCostElements, CANVA, 575, 165);
                positionElement(upgradeAnvilCardDescrpitionElements, CANVA, 585, 330);
                positionElement(ARROW_IMG,CANVA,455,250)
                positionElement(UPGRADE_BUTTON,CANVA,440,440)

                // display the cost and whether the player has enough coins
                if (BUY_TXT.innerText == "NOT ENOUGH COINS"){
                    positionElement(BUY_TXT, CANVA, 445, 390);
                }else{
                    positionElement(BUY_TXT, CANVA, 470, 390);
                }

                // get the cost of the card from the deck
                for (let i in playerDeck){
                    if (playerDeck[i].name == upgradeAnvilCardTitleElements.innerText){
                        COST_TXT.innerText = "Cost: "+ playerDeck[i].upgradeCost;
                        break;
                    }
                    
                }
                positionElement(COST_TXT,CANVA,370,435)
            }

            
        }
        // check if the player is at the rest event
        else if(gamestate == gameStates[3]){

            // position Elements
            positionElement(COIN_DISPLAY,CANVA, 150,510);
            positionElement(COINS_TXT, CANVA, 180, 505);
            positionElement(REST_BG, CANVA, 0, 0);
            positionElement(REST_IMG, CANVA, 100, 100);
            positionElement(UPGRADE_BUTTON, CANVA, 700,100);
            positionElement(LEAVE_BUTTON, CANVA, 400, 0);
            positionElement(REST_TXT,CANVA,380,470)
            positionElement(REST_OVERLAY, CANVA, 0, 0);

            // check if the player is on the upgrading stats menu
            if(upgradingStats){

                // checks if the user is done with distributing their stats
                if (printButtons){
                    positionElement(CONFIRM_BUTTON, CANVA, 550, 370);
                    positionElement(X_BUTTON, CANVA, 460, 370); 
                }

                // positon the stats
                positionElement(CHARACTER_STATS_UPGRADABLE, CANVA, 455, 150); 
                
                //Updating stats and stat points 
                if (characters[character]){
                    CHARACTER_STATS_UPGRADABLE.innerText = "STATS POINTS:"+ statPoints +"\n\n HITPOINT:" + health +"(+"+ amountOfHpPoints +")" + "\n\nATTACK:"+attack +"(+"+ amountOfAtkPoints +")" +  "\n\nDEFENSE:" + defense+ "(+"+ amountOfDefPoints +")" +  "\n\nCRIT MULTIPLIER:"+Math.round(critMultiplier*100)/100 +"x"+"(+"+ Math.round(amountOfCritMultiPoints*10)/10 +")" + "\n\nCRIT RATE:"+ critRate+"%"+"(+"+ amountOfCritRatePoints +")" ;
                }

                // call function to check which character has been chosen
                characterCheck()
                
                // printing buttons to interact with to change character stats
                SELECTION_TITLE.innerText= "UPGRADE YOUR STATS";
                positionElement(SELECTION_TITLE, CANVA, CANVA.width/2 - SELECTION_TITLE.offsetWidth/2, 0);

                // drawing the elements to change the stats
                positionElement(CHARACTER_CYCLE_LEFT, CANVA, 410, 190);
                positionElement(CHARACTER_CYCLE_RIGHT, CANVA, 615, 190);

                positionElement(CHARACTER_ATK_LEFT, CANVA, 410, 220);
                positionElement(CHARACTER_ATK_RIGHT, CANVA, 615, 220);

                positionElement(CHARACTER_DEF_LEFT, CANVA, 410, 250);
                positionElement(CHARACTER_DEF_RIGHT, CANVA, 615, 250);

                positionElement(CHARACTER_CRIT_DMG_LEFT, CANVA, 410, 280);
                positionElement(CHARACTER_CRIT_DMG_RIGHT, CANVA, 615, 280);

                positionElement(CHARACTER_CRIT_CHANCE_LEFT, CANVA, 410, 310);
                positionElement(CHARACTER_CRIT_CHANCE_RIGHT, CANVA, 615, 310);
                
                // drawing the back button to go back to last page
                positionElement(BACK_BUTTON, CANVA, 100, 120);
            }
            
        }
        
        // Check For Screen Transition
        if (transition == 'Start'){
            startTransition();
        }
        else if (transition == 'End'){
            endTransition();
        }
        else if (transition == 'none'){
            for (let state = 0; state < gameStates.length; state++){
                if (gamestate != gameStates[state]){
                    GAME_SCREENS[state].style.display = 'none';
                }
                else{
                    GAME_SCREENS[state].style.display = 'block';
                }
            }
        }
    }
}


// animation for writing the txt out
function typeWriter() {

    // check if the first half of text is already written
    if (textCounter < merchantSpeech.length) {
        MERCHANT_TXT.innerHTML += merchantSpeech.charAt(textCounter);
        textCounter++;
        setTimeout(typeWriter, 50);
    }
}



// insertElement into an array
function insertElement(array, item, index){
    // increase the array length by 1
    let newArray = new Array(array.length + 1);
    // add all items in the previous array
    for (let i = 0; i < newArray.length; i++){
        // add all items before the inserted item index
        if (i == index){
            newArray[i] = item;
        }
        // add new item
        else if (i > index){
            newArray[i] = array[i-1];
        }
        // add all items after the inserted item index
        else{
            newArray[i] = array[i];
        }
    }
    // return the new array
    return newArray;
}

// remove an item from an array
function indexRemover(array, startIndex, numItems){

    // get end index of the items being removed
    let endIndex = startIndex + numItems;

    // create a new array for the length of array with the removed items
    let newArray = new Array(array.length - numItems);

    // add all elements into the new array
    for (let i = 0; i < newArray.length;i++){
        // add elements thats are not being removed
        if (startIndex <= i && i < endIndex){
            newArray[i] = array[i + numItems];
        }
        else if ( i >= endIndex){
            newArray[i] = array[i + numItems];
        }
        else{
            newArray[i] = array[i];
        }
        
    }
    return newArray;

}

// enemy turn
function enemyTurn(timeDifference){
    
    // remove all card elements
    for (let card = 0; card < hand.length; card++){
        cardElements[card].remove();
        cardTitleElements[card].remove();
        cardCostElements[card].remove();
        cardDescriptionElements[card].remove();
    }

    // reset all card elements
    if (hand != ''){
        cardElements = [];
        cardElementClickStatus = [];
        hand = [];
        cardElementsHoveringStatus = [];
        cardTitleElements = [];
        cardDescriptionElements = [];
        cardCostElements = [];   
    }

    // check if the player is not in a death or hurt state
    if (playerState != 'Death' && playerState != 'Hurt'){
        
        // check if the enemy is not in a death or hurt state
        for (let animation in enemyAnimations){
            if (enemyAnimations[animation] == 'Death' || enemyAnimations[animation] == 'Hurt'){
                return;
            }
        }

        // time difference between each enemy turn
        if (timeDifference >= 0.25){
            // look for the last enemy
            let lastEnemy;
            for (let enemy = 0; enemy < enemies.length; enemy++){
                if (enemies[enemy] != null){
                    lastEnemy = enemy;
                    break;
                }
            }

            // loop through all enemies
            for (let enemy = enemies.length-1; enemy >= 0; enemy--){
                // check if the enemy is alive
                if (enemies[enemy] != null){

                    // check if the enemy has not ended their turn
                    if (!enemies[enemy].endTurn){

                        // apply burn damage to the enemy
                        if (enemyBurn){
                            enemyAnimations[enemy] = enemies[enemy].burnDamage();
                            enemyGameFrames[enemy] = 0;
                            enemyTurnInitialTiming = performance.now();
                            enemyBurn = false;

                            // check if enemy died
                            if (enemies[enemy].health <= 0){
                                enemies[enemy].giveCurrency()
                                
                                // check if enemy is the last enemy
                                if (enemy == lastEnemy){
                                    enemyBurn = false;
                                    enemyMove = false;
                                    enemyPoison = false;
                                    playerTurn = true;
                                    startOfPlayerTurn();
                                }
                            }
                            break;
                        }

                        // make the enemy use it's move
                        else if(enemyMove){

                            enemies[enemy].useMove();
                            enemies[enemy].updateEffects();
                            party[0].updateEffects();
                            enemyTurnInitialTiming = performance.now();
                            enemyMove = false;
                            break;
                        }

                        // apply poison damage to enemies
                        else if(enemyPoison){
                            enemyAnimations[enemy] = enemies[enemy].poisonDamage();
                            enemyGameFrames[enemy] = 0;
                            enemyTurnInitialTiming = performance.now();
                            enemyPoison = false;
                            if (enemies[enemy].health <= 0){
                                enemies[enemy].giveCurrency()
                                if (enemy == lastEnemy){
                                    enemyBurn = true;
                                    enemyMove = true;
                                    enemyPoison = true;
                                    playerTurn = true;
                                    startOfPlayerTurn();
                                    
                                }
                            }
                            break;
                        }

                        // once all actions are done end the enemy's turn
                        else{
                            // reset the timing
                            enemyTurnInitialTiming = performance.now();
                            enemyBurn = true;
                            enemyMove = true;
                            enemyPoison = true;
                            enemies[enemy].endTurn = true;

                            // remove their burn by 2 and poison by 2
                            enemies[enemy].burn -= 2;
                            enemies[enemy].poison -= 2;
                            if (enemies[enemy].burn < 0){
                                enemies[enemy].burn = 0;
                            }

                            if (enemies[enemy].poison < 0){
                                enemies[enemy].poison = 0;
                            }
                            enemies[enemy].updateEffects();
                            if (enemy == lastEnemy){
                                playerTurn = true;
                                startOfPlayerTurn();

                            }
                            break;                
                        }
                    }
                }
            }
        }
        else{
            // reset the timing
            enemyTurnEndTiming = performance.now()
        }
    }
    
    
}

// start of the player turn
function startOfPlayerTurn(){
    // get the enemies next attack
    generateEnemyAttacks(enemies);
    
    // slide text in
    slideInTurnText();

    // reset all the enemies turns
    for (let enemy in enemies){
        if (enemies[enemy] != null){
            enemies[enemy].endTurn = false;
        }
    }
    // reset party block
    party[0].block = 0;
    party[0].updateEffects();

    // draw a new hand
    [hand, drawDeck, discardPile] = draw(drawDeck, discardPile, 5);
    createCardElement(hand);
    END_TURN_BUTTON.style.display = 'block';
    DECK.style.display = 'block';
    
}

// transition for the text
function slideInTurnText(){
    
    // Reset the animation by removing it
    textElement.style.animation = 'none';
    // Trigger reflow to restart animation
    void textElement.offsetWidth;
    // Reapply the animation
    textElement.style.animation = 'slide-in-anim 5s ease-out forwards';

}

// if the user presses the x button after selecting stats
// reset all stats to base stats and stat points to 20
function resetStatPoints(){
    if (gamestate != "rest"){
        statPoints = 20;// stat points back to 20
        critMultiplier = minCritMultiplier; //making crit muliplier back to base stat 
        health = minHealth;//making health back to base stat 
        attack = minAttack;//making attack back to base stat 
        defense = minDefense;//making defense back to base stat 
        critRate = minCritRate;//making crit rate back to base stat 
        checkStatPoint(); // check amount of stat points    
    }else if(gamestate == "rest"){
        statPoints = minStatPoints;// stat points back to 20
        critMultiplier = minCritMultiplier; //making crit muliplier back to base stat 
        health = minHealth;//making health back to base stat 
        attack = minAttack;//making attack back to base stat 
        defense = minDefense;//making defense back to base stat 
        critRate = minCritRate;//making crit rate back to base stat 
        checkStatPoint(); // check amount of stat points    

    }
}

// making sure that the user can only use 20 stat points
function checkStatPoint(){

    // show how many stat point have been put into a certain stat
    // formula is (current - mincurrent)/ increments
    amountOfHpPoints = (health - minHealth)/5;
    amountOfAtkPoints = (attack- minAttack)/1.5;
    amountOfDefPoints = (defense - minDefense)/1.5;
    amountOfCritMultiPoints = (critMultiplier-minCritMultiplier)/0.05;
    amountOfCritRatePoints = (critRate-minCritRate)/0.5;

    // displaying the confirmation and reset buttons when stat points = 0
    if (statPoints == 0){
        statPoints = 0;
        CONFIRM_BUTTON.style.display = "block";
        X_BUTTON.style.display = "block";
        printButtons = true;
    }
    // not displaying the confirmation and reset buttons when stat points is greater or equal than 1
    if(statPoints >= 1){
        CONFIRM_BUTTON.style.display = "none";
        X_BUTTON.style.display = "none";
    }


}

// button animation
function buttonDownAnimation(event){

    const {target} = event;

    // loop through all buttons
    for (let button = 0; button < BUTTONS.length; button++){

        // check if the button is the clicked element
        if (BUTTONS[button] == target){
            // change image to pressed down image of the button
            BUTTONS[button].src = BUTTON_PRESSED_IMAGES[button];
        }
    }
}

// button up animation
function buttonUpAnimation(){
    // loop through all buttons
    for (let button = 0; button < BUTTONS.length; button++){
        // set them all to their unpressed button image
        BUTTONS[button].src = BUTTON_UNPRESSED_IMAGES[button];
    }
}



// hover over element functionality
function hoverElement(element){
    const {target} = element;

    if (gamestate === gameStates[1]){
        
        for (let handElement in cardElements){
            if (target == cardElements[handElement] ||  target == cardTitleElements[handElement] || target == cardCostElements[handElement] || target == cardDescriptionElements[handElement]){
                if (!HOVERED_CARDS.contains(cardElements[handElement])){
                    HOVERED_CARDS.appendChild(cardElements[handElement]);
                    HOVERED_CARDS.appendChild(cardTitleElements[handElement]);
                    HOVERED_CARDS.appendChild(cardCostElements[handElement]);
                    HOVERED_CARDS.appendChild(cardDescriptionElements[handElement]);
                    cardElementsHoveringStatus[handElement] = true;
                }
            }
            else{
                CARDS_ELEMENT_DIV.appendChild(cardElements[handElement]);
                CARDS_ELEMENT_DIV.appendChild(cardTitleElements[handElement]);
                CARDS_ELEMENT_DIV.appendChild(cardCostElements[handElement]);
                CARDS_ELEMENT_DIV.appendChild(cardDescriptionElements[handElement]);
                cardElementsHoveringStatus[handElement] = false; 
            }
        }
    }
    
    
}
// disable right click
function disableRightClick(event){
    event.preventDefault();
}

// button click functionality
function buttonClick(clickedElement){
    const { target } = clickedElement; // let target = clicked element

        // Check if the target element is the 'Next' button and the info page is active, while pageOneInfo and pageTwoInfo are false
        if (target === INFO_NEXT_BUTTON && infoPage && !pageOneInfo && !pageTwoInfo) {
            pageOneInfo = true; // Mark that the user is on the first page of info
            // Update the display of images for the first page
            INFO_IMG1.style.display = 'none';
            INFO_IMG4.style.display = 'block';
            INFO_IMG2.style.display = 'block';
        } else if (target === INFO_NEXT_BUTTON && pageOneInfo) {
            pageTwoInfo = true; // Mark that the user is on the second page of info
            // Update the display of images for the second page
            INFO_IMG1.style.display = 'block';
            INFO_IMG2.style.display = 'none';
            INFO_IMG3.style.display = 'block';
            INFO_IMG4.style.display = 'none';
            pageOneInfo = false; // Reset the first page flag
        } else if (target === INFO_NEXT_BUTTON && pageTwoInfo) {
            pageThreeInfo = true; // Mark that the user is on the third page of info
            // Update the display of images for the third page
            INFO_IMG.style.display = 'block';
            INFO_IMG1.style.display = 'none';
            INFO_IMG2.style.display = 'none';
            INFO_IMG3.style.display = 'none';
            INFO_IMG4.style.display = 'none';
            pageTwoInfo = false; // Reset the second page flag
        }

        // Check if the target element is the 'Back' button, the user is on page one, and the info page is active
        if (target === INFO_BACK_BUTTON && pageOneInfo && infoPage) {
            pageOneInfo = false; // Reset the first page flag
            // Hide all images related to the first page
            INFO_IMG1.style.display = 'none';
            INFO_IMG4.style.display = 'none';
            INFO_IMG2.style.display = 'none';
        } else if (target === INFO_BACK_BUTTON && pageTwoInfo && infoPage) {
            pageTwoInfo = false; // Reset the second page flag
            pageOneInfo = true; // Mark the user as back on the first page
            // Update the display of images for the first page
            INFO_IMG1.style.display = 'none';
            INFO_IMG4.style.display = 'block';
            INFO_IMG3.style.display = 'none';
            INFO_IMG2.style.display = 'block';
        } else if (target === INFO_BACK_BUTTON && pageThreeInfo && infoPage) {
            pageTwoInfo = true; // Mark the user as back on the second page
            pageThreeInfo = false; // Reset the third page flag
            // Update the display of images for the second page
            INFO_IMG1.style.display = 'block';
            INFO_IMG4.style.display = 'none';
            INFO_IMG3.style.display = 'block';
            INFO_IMG2.style.display = 'none';
        }

        // Check if the target element is the 'Exit' button and the info page is active
        if (target === INFO_EXIT_BUTTON && infoPage) {
            // Hide all related elements to close the info page
            OVERLAY.style.display = 'none';
            INFO_IMG.style.display = 'none';
            INFO_IMG1.style.display = 'none';
            INFO_IMG2.style.display = 'none';
            INFO_IMG3.style.display = 'none';
            INFO_IMG4.style.display = 'none';
            INFO_TXT.style.display = 'none';
            INFO_EXIT_BUTTON.style.display = 'none';
            INFO_BACK_BUTTON.style.display = 'none';
            INFO_NEXT_BUTTON.style.display = 'none';

            // Reset all flags
            pageOneInfo = false;
            infoPage = false;
            pageTwoInfo = false;
        }

        // Check if the target element is the 'Info' button to activate the info page
        if (target === INFO_BUTTON) {
            infoPage = true; // Activate the info page
        }

    if (characterSelectionPage == 1) {// check if page is 1
        if (target === PLAY_BUTTON) {// clicked the play button 
            transition = "Start"; // fade in and out to character selection page 
            CHARACTER_SELECTION_PAGE1.style.display = "block"; // display the character selection page
        }
        else if (target === CHARACTER_CYCLE_LEFT) {// if clicked left then character -1 

            // character is the index to select a character
            if (character == 0) { // if character is 0 then set it as 2
                character = 2;
            } else {
                character--;
            }
        } 
        else if (target === CHARACTER_CYCLE_RIGHT) {// if clicked right then character  +1 
            if (character == 2) {// if character is 2 then set it as 0
                character = 0;
            } else {
                character++;
            }
        }

        // next button clicked then
        else if (target === NEXT_BUTTON) {
                characterSelectionPage++; // add 1 to page
                CHARACTER_STATS_UPGRADABLE.style.display = "block";// display text for stats
                CHARACTER_BASE_STATS.style.display = "none"; // stop displaying the base stats from page 1
                CHARACTER_INFO.style.display = "none";// stop displaying the ability description
                CHARACTER_STAT_PAGE2.style.display = "block";// display all button need to change stats
                BACK_BUTTON.style.display = "block";// display back button
                NEXT_BUTTON.style.display = "none";// stop displaying next button
                moveLeft = true; // move the character and the background to left for stats page
                

                // by default base stats are set to fire wizard's
                if (characters[character] === "Knight") {// check if character is Knight 
                    // setting stats to the base stats of knight
                    health = 150;
                    attack = 20;
                    defense = 50;
                    critMultiplier = 1.5;
                    critRate = 10;

                    if (findMinStats) {// this it to find the minimum of each stat
                        minCritMultiplier = critMultiplier;
                        minHealth = health;
                        minAttack = attack;
                        minDefense = defense;
                        minCritRate = critRate;
                        findMinStats = false;// doesn't run again
                    }
                    playerDeck = knightDeck;
                } 
                else if (characters[character] === "Ninja") {// check if character is Ninja 
                    // setting stats to the base stats of Ninja
                    health = 110;
                    attack = 35;
                    defense = 30;
                    critMultiplier = 1.75;
                    critRate = 22.5;

                    if (findMinStats) {// this it to find the minimum of each stat
                        minCritMultiplier = critMultiplier;
                        minHealth = health;
                        minAttack = attack;
                        minDefense = defense;
                        minCritRate = critRate;
                        findMinStats = false;// doesn't run again
                    }
                    playerDeck = ninjaDeck;
                }
                else {
                    playerDeck = fireWizardDeck;
                }
                
        }
      
    }
    if (characterSelectionPage == 2) {// check if page is 2 (stats page)
        // this is all used for changing stats 
        if (target === CHARACTER_CYCLE_RIGHT) {// increase health
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                health += 5;
                checkStatPoint();
            }
        } else if (target === CHARACTER_CYCLE_LEFT) {// decrease health
            if (health > minHealth) {// making sure that health doesnt go below the base stat
                statPoints++;
                health -= 5;
                checkStatPoint();
            }
        }
        else if (target === CHARACTER_ATK_RIGHT) {// increase attack
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                attack += 1.5;
                checkStatPoint();
            }
        } else if (target === CHARACTER_ATK_LEFT) {// decrease attack
            if (attack > minAttack) {// making sure that attack doesnt go below the base stat
                statPoints++;
                attack -= 1.5;
                checkStatPoint();
            }
        }
        else if (target === CHARACTER_DEF_RIGHT) {// increase defense
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                defense += 1.5;
                checkStatPoint();
            }
        } else if (target === CHARACTER_DEF_LEFT) {// decrease defense
            if (defense > minDefense) {// making sure that defense doesnt go below the base stat
                statPoints++;
                defense -= 1.5;
                checkStatPoint();
            }
        }
        else if (target === CHARACTER_CRIT_DMG_RIGHT) {// increase crit multiplier
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                critMultiplier += 0.05;
                checkStatPoint();
            }
        } else if (target === CHARACTER_CRIT_DMG_LEFT) {// decrease crit multiplier
            if (critMultiplier > minCritMultiplier) {// making sure that crit multiplier doesnt go below the base stat
                statPoints++;
                critMultiplier -= 0.05;
                checkStatPoint();
            }
        }
        else if (target === CHARACTER_CRIT_CHANCE_RIGHT) {//increase crit chance
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                critRate += 0.5;
                checkStatPoint();
            }
        } else if (target === CHARACTER_CRIT_CHANCE_LEFT) {// decrease crit chance
            if (critRate > minCritRate) {// making sure that crit chance doesnt go below the base stat
                statPoints++;
                critRate -= 0.5;
                checkStatPoint();
            }
        }

        else if (target == X_BUTTON) { // if clicked the x button that shows up when all the stats have been choosen
            resetStatPoints();// reset all stats to base and stat points to 20
            }
        else if (target == CONFIRM_BUTTON) {// if clicked check mark button shows up when all the stats have been choosen
            characterSelectionPage++; //  add 1 to page , so page = 3

            //remove all page 2 elements 
            X_BUTTON.style.display = "none";
            CHARACTER_STAT_PAGE2.style.display = "none";
            CONFIRM_BUTTON.style.display = "none";
            CHARACTER_STATS_UPGRADABLE.style.display = "none";
            supportSelection = true; // change to true since the user will be selecting the support character next 
            party[0] = new Character(characters[character], health, attack, defense, critRate, critMultiplier, exp , currency);
        }
        else if (target == BACK_BUTTON) { // check if clicked the back button
            characterSelectionPage--; // page - 1, so page equals 1
            
            // display the needed thing for page one 
            // remove the things that are for page 2
            CHARACTER_BASE_STATS.style.display = "block";
            CHARACTER_INFO.style.display = "block";
            BACK_BUTTON.style.display = "none";
            CHARACTER_STAT_PAGE2.style.display = "none";
            CHARACTER_STATS_UPGRADABLE.style.display = "none";
            NEXT_BUTTON.style.display = "block";
            moveRight = true;// undo move left from page 1 to page 2 
            resetStatPoints();// reset all stats to base and stat points to 20
        }
    }
    // runs only if page is 3
    if (characterSelectionPage == 3) {
        // displaying the support info, next button, and the stats
        CHARACTER_INFO.style.display = "block";
        NEXT_BUTTON.style.display = "block";
        CHARACTER_BASE_STATS.style.display = "block";
        MENU_CHARACTERX[0] = CANVA_WIDTH/2-100;// reset the character if the user presses the back button
        MENU_CHARACTERX[1] = CANVA_WIDTH/2-119 ;// reset the character if the user presses the back button
        MENU_CHARACTERX[2] = CANVA_WIDTH/2-205 ;// reset the character if the user presses the back button

        // if back button clicked then diplay eveything that was on page 2
        // same as going from page 1 to 2 but instead for 3 to 2
        if (target == BACK_BUTTON) {
            characterSelectionPage--;// minus 1 from characterSelectionPage

            //displaying all elements needed for page 2 and remove page 3 elements  
            CHARACTER_STATS_UPGRADABLE.style.display = "block"; 
            CHARACTER_BASE_STATS.style.display = "none";
            CHARACTER_INFO.style.display = "none";
            CHARACTER_STAT_PAGE2.style.display = "block";
            BACK_BUTTON.style.display = "block";
            NEXT_BUTTON.style.display = "none";  

            moveLeft = true;// doing the same thing as we did for page 1 to 2
            characterBgStatX = 475; // reset the stat background 
            checkStatPoint() //  make sure the button are still displaying
        }
        
        // if the right button is clicked then switch the characters
        if (target === CHARACTER_CYCLE_RIGHT) {
            //since the support character only has 2 people, max index is 1
            if (supportCharacter == 1) {// fairy
            supportCharacter = 0;
            } else {
            supportCharacter++;
            }
        } else if (target === CHARACTER_CYCLE_LEFT) { // if the left button is clicked then switch the characters
            //since the support character only has 2 people, max index is 1
            if (supportCharacter == 0) {// tank
            supportCharacter = 1;
            } else {
            supportCharacter--;
            }
        }
        else if (target === NEXT_BUTTON) {// when the next button is click the party array will add the support character that is selected
            party[1] = new SupportCharacter(supportCharacters[supportCharacter], SUPPORT_HEALTHS[supportCharacter], SUPPORT_DEFENSE[supportCharacter], SUPPORT_SPECIAL[supportCharacter]); // adding the selected support character to the party 
            transition = 'Start';
            
            
            
        }
    }
  
    // check if the user is on the map screen
   
                    
                
            
        
    
    // if user is in battle 
    else if (gamestate === gameStates[1]){
        
        // If the user clicks the exit button for the inventory
        if (target == EXIT_INV_BUTTON) {
            // Hide all inventory-related elements
            INV_OVERLAY.style.display = 'none';
            INV_BG.style.display = "none";
            EXIT_INV_BUTTON.style.display = 'none';
            DOWN_BTN.style.display = 'none';
            UP_BTN.style.display = 'none';
            SORT_BTN.style.display = 'none';
            SORT_TXT.style.display = 'none';
            INV_TXT.style.display = 'none';
            showInv = false;
            // Remove all card elements from the player's deck
            for (let card in playerDeck) {
                deckCardElements[card].remove();
                deckCardCostElements[card].remove();
                deckCardTitleElements[card].remove();
                deckCardDescrpitionElements[card].remove();
            }
        } 
        // If the user clicks the 'Up' button to navigate the inventory
        else if (target == UP_BTN) {
            row -= 1; // Decrease the row index
            if (row == 0) {
                // Hide the 'Up' button if at the top
                UP_BTN.style.display = 'none';
                DOWN_BTN.style.display = 'block';
            } else {
                DOWN_BTN.style.display = 'block';
            }
            // Display or hide cards based on the current row
            for (let card in deckCardElements) {
                if (card >= row * 5 && card < (row * 5) + 10) {
                    deckCardElements[card].style.display = 'block';
                    deckCardTitleElements[card].style.display = 'block';
                    deckCardCostElements[card].style.display = 'block';
                    deckCardDescrpitionElements[card].style.display = 'block';
                } else {
                    deckCardElements[card].style.display = 'none';
                    deckCardTitleElements[card].style.display = 'none';
                    deckCardCostElements[card].style.display = 'none';
                    deckCardDescrpitionElements[card].style.display = 'none';
                }
            }
        } 
        // If the user clicks the 'Down' button to navigate the inventory
        else if (target == DOWN_BTN) {
            row += 1; // Increase the row index
            if ((5 + row * 5) >= playerDeck.length - 1) {
                // Hide the 'Down' button if at the bottom
                DOWN_BTN.style.display = 'none';
                UP_BTN.style.display = 'block';
            } else {
                UP_BTN.style.display = 'block';
            }
            // Display or hide cards based on the current row
            for (let card in deckCardElements) {
                if (card >= row * 5 && card < (row * 5) + 10) {
                    deckCardElements[card].style.display = 'block';
                    deckCardTitleElements[card].style.display = 'block';
                    deckCardCostElements[card].style.display = 'block';
                    deckCardDescrpitionElements[card].style.display = 'block';
                } else {
                    deckCardElements[card].style.display = 'none';
                    deckCardTitleElements[card].style.display = 'none';
                    deckCardCostElements[card].style.display = 'none';
                    deckCardDescrpitionElements[card].style.display = 'none';
                }
            }
        } 
        // If the user clicks the 'Sort' button to change the sorting order
        else if (target == SORT_BTN) {
            // Cycle through the sorting types
            if (sortType < sortingTypes.length - 1) {
                sortType += 1;
            } else {
                sortType = 0;
            }
            // Update the sort text display
            SORT_TXT.innerText = sortingTypesNames[sortType];
            // Remove all card elements to prepare for re-sorting
            for (let card in playerDeck) {
                deckCardElements[card].remove();
                deckCardCostElements[card].remove();
                deckCardTitleElements[card].remove();
                deckCardDescrpitionElements[card].remove();
            }
            // Create and display sorted card elements
            createSortedCardElements();
        } 
        // If the user clicks the deck to open the inventory
        else if (target == DECK) {
            // Display all inventory-related elements
            INV_OVERLAY.style.display = 'block';
            INV_BG.style.display = "block";
            EXIT_INV_BUTTON.style.display = 'block';
            DOWN_BTN.style.display = 'block';
            SORT_BTN.style.display = 'block';
            SORT_TXT.style.display = 'block';
            INV_TXT.style.display = 'block';
            showInv = true;
            // Create and display sorted card elements
            createSortedCardElements();
        }


        // check if player turn
        else if (playerTurn){
            // check if end turn button is clicked
            if (target == END_TURN_BUTTON){
                if (transition != 'Start'){
                    // generate a random number
                    let rand = Math.random();

                    // check if fairy is support
                    if (party[1].name == supportCharacters[0]){

                        // check to trigger fairy's heal passive
                        if (rand < 0.25){
                            party[0].health += party[0].maxHealth*SUPPORT_SPECIAL[0];
                            if (party[0].health > party[0].maxHealth){
                                party[0].health = party[0].maxHealth
                            };
                        };
                    };
                    // Check if the character is a ninja
                    if (party[0].name == characters[2]) {
                        // Check for a 5% chance to trigger a special ninja action
                        if (rand < 0.05) {
                            // Remove all existing card elements from the hand
                            for (let card = 0; card < hand.length; card++) {
                                cardElements[card].remove();
                                cardTitleElements[card].remove();
                                cardCostElements[card].remove();
                                cardDescriptionElements[card].remove();
                            };

                            // Reset all card-related arrays
                            cardElements = [];
                            cardElementClickStatus = [];
                            hand = [];
                            cardElementsHoveringStatus = [];
                            cardTitleElements = [];
                            cardDescriptionElements = [];
                            cardCostElements = [];   

                            // Draw a new hand of cards
                            [hand, drawDeck, discardPile] = draw(drawDeck, discardPile, 5);
                            createCardElement(hand);
                        } 
                        else {
                            // End the player's turn and hide UI elements
                            playerTurn = false;
                            enemyTurnInitialTiming = performance.now();
                            enemyTurnEndTiming = performance.now();
                            END_TURN_BUTTON.style.display = 'none';
                            DECK.style.display = 'none';
                        }
                    }
                    else {
                        // End the player's turn for non-ninja characters
                        playerTurn = false;
                        enemyTurnInitialTiming = performance.now();
                        enemyTurnEndTiming = performance.now();
                        END_TURN_BUTTON.style.display = 'none';
                        DECK.style.display = 'none';
                    };

                    // Increment the player's energy and make sure it doesn't exceed the limit
                    party[0].energy += 3;
                    if (party[0].energy >= party[0].maxEnergy) {
                        party[0].energy = party[0].maxEnergy;
                    };

                    // Slide in the turn text animation
                    slideInTurnText();

                    // Move all cards from the hand to the discard pile
                    for (let card in hand) {
                        discardPile.length += 1;
                        discardPile[discardPile.length - 1] = hand[card];
                    };

                    // Reset the block and update effects for all enemies
                    for (let enemy in enemies) {
                        if (enemies[enemy] != null) {
                            enemies[enemy].block = 0;
                            enemies[enemy].updateEffects();
                        };
                    };
                };
            };

            // Loop through each card element to check its click status
            for (let handElement in cardElementClickStatus) {
                // Check if the card has been clicked
                if (cardElementClickStatus[handElement] == true) {
                    // Check if the card targets the player (self)
                    if (hand[handElement].targeting == 'self') {
                        let hitbox = characterHitBox;
                        // Check if the target is the player's hitbox
                        if (target == hitbox) {
                            for (let card in CARDS) {
                                // Match the clicked card with the card in the CARDS array
                                if (hand[handElement].name == CARDS[card].name && hand[handElement].upgradeStatus == CARDS[card].upgradeStatus) {
                                    // Check if the player has enough energy to play the card
                                    if (party[0].energy >= CARDS[card].energyCost) {
                                        CARDS[card].playCard();
                                        party[0].updateEffects();
                                        // Move the card to the discard pile
                                        discardPile.length += 1;
                                        discardPile[discardPile.length - 1] = hand[handElement];

                                        // Remove card elements from the hand and update arrays
                                        cardElements[handElement].remove();
                                        cardTitleElements[handElement].remove();
                                        cardCostElements[handElement].remove();
                                        cardDescriptionElements[handElement].remove();
                                        
                                        cardElements = indexRemover(cardElements, handElement, 1);
                                        cardElementsHoveringStatus = indexRemover(cardElementsHoveringStatus, handElement, 1);
                                        cardCostElements = indexRemover(cardCostElements, handElement, 1);
                                        cardTitleElements = indexRemover(cardTitleElements, handElement, 1);
                                        cardDescriptionElements = indexRemover(cardDescriptionElements, handElement, 1);
                                        cardElementClickStatus = indexRemover(cardElementClickStatus, handElement, 1);
                                        hand = indexRemover(hand, handElement, 1);
                                        party[0].energy -= CARDS[card].energyCost;
                                        break;
                                    }
                                }
                            }
                        }
                    } 
                    else {
                        // Handle cards targeting enemies
                        for (let enemy in enemies) {
                            let hitbox = enemyHitBoxes[enemy];
                            // Check if the target is an enemy's hitbox
                            if (target == hitbox) {
                                for (let card in CARDS) {
                                    if (hand[handElement].name == CARDS[card].name && hand[handElement].upgradeStatus == CARDS[card].upgradeStatus) {
                                        // Check if the player has enough energy to play the card
                                        if (party[0].energy >= CARDS[card].energyCost) {
                                            CARDS[card].playCard(enemies[enemy]);
                                            party[0].updateEffects();
                                            // Move the card to the discard pile
                                            discardPile.length += 1;
                                            discardPile[discardPile.length - 1] = hand[handElement];

                                            // Remove card elements from the hand and update arrays
                                            cardElements[handElement].remove();
                                            cardTitleElements[handElement].remove();
                                            cardCostElements[handElement].remove();
                                            cardDescriptionElements[handElement].remove();
                                            
                                            cardElements = indexRemover(cardElements, handElement, 1);
                                            cardElementsHoveringStatus = indexRemover(cardElementsHoveringStatus, handElement, 1);
                                            cardCostElements = indexRemover(cardCostElements, handElement, 1);
                                            cardTitleElements = indexRemover(cardTitleElements, handElement, 1);
                                            cardDescriptionElements = indexRemover(cardDescriptionElements, handElement, 1);
                                            cardElementClickStatus = indexRemover(cardElementClickStatus, handElement, 1);
                                            hand = indexRemover(hand, handElement, 1);
                                            party[0].energy -= CARDS[card].energyCost;
                                            break;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };

        // Update click status based on target matching any card element
        for (let card in hand) { 
            if (target == cardElements[card] || target == cardTitleElements[card] || target == cardCostElements[card] || target == cardDescriptionElements[card]) {
                cardElementClickStatus[card] = true;
            } else {
                cardElementClickStatus[card] = false;
            }
        };

    }
    // Handles user interaction with the shop
    else if (gamestate === gameStates[2]){
        // if the user clicks the shop tab in the shop 
        if (target == SHOP_BUTTON){

            //remove anvil elements 
            anvilCardCostElements.remove();
            anvilCardDescrpitionElements.remove();
            anvilCardElements.remove();
            anvilCardTitleElements.remove();
            upgradeAnvilCardCostElements.remove();
            upgradeAnvilCardDescrpitionElements.remove();
            upgradeAnvilCardElements.remove();
            upgradeAnvilCardTitleElements.remove();

            // change the menu 
            shopMenu = true;
            anvilMenu = false;

            // change the button image to look bigger 
            //to show which tab your are on
            BUTTON_PRESSED_IMAGES[20] = 'Images/Others/Larger_Store_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[20] = 'Images/Others/Larger_Store_Button.png';
            BUTTON_PRESSED_IMAGES[19] = 'Images/Others/Anvil_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[19] = 'Images/Others/Anvil_Button.png';
            
            //change the button src 
            SHOP_BUTTON.src = BUTTON_UNPRESSED_IMAGES[20];
            BUTTONS[19].src = BUTTON_UNPRESSED_IMAGES[19];

            //display the elements needed and hide the rest
            SHOP_CARDS.style.display = 'block';
            SELECT_BUTTONS.style.display = 'block';
            ANVIL_BUTTONS.style.display = "none";
            ANVIL_CARDS.style.display = "none";
            ARROW_IMG.style.display = "block";
            UPGRADE_BUTTON.style.display = 'none';
            COST_TXT.style.display = 'none';


        }else if (target == ANVIL_BUTTON){ // if the user clicks the anvil tab in the shop 
            // change the menu 
            anvilMenu = true;
            shopMenu = false;

            // change the button image to look bigger 
            //to show which tab your are on
            BUTTON_PRESSED_IMAGES[19] = 'Images/Others/Larger_Anvil_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[19] = 'Images/Others/Larger_Anvil_Button.png';
            BUTTON_PRESSED_IMAGES[20] = 'Images/Others/Store_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[20] = 'Images/Others/Store_Button.png';

            //change the button src 
            BUTTONS[20].src = BUTTON_UNPRESSED_IMAGES[20];
            BUTTONS[19].src = BUTTON_UNPRESSED_IMAGES[19];
            
            //create the cards for the anvil page 
            createAnvilCardElement(upgradedIndex)

            //display the elements needed and hide the rest
            SELECT_BUTTONS.style.display = 'none';
            ANVIL_BUTTONS.style.display = "block"
            ANVIL_CARDS.style.display = "block";
            ARROW_IMG.style.display = "block";
            SHOP_CARDS.style.display = 'none';
            UPGRADE_BUTTON.style.display = 'block';
            COST_TXT.style.display = 'block';


        }
        
        
        // if the user clicks the anvil image
        if (target == ANVIL){
            // make anvilMenu true 
            anvilMenu = true;

            // chnage the image of the button
            BUTTON_PRESSED_IMAGES[19] = 'Images/Others/Larger_Anvil_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[19] = 'Images/Others/Larger_Anvil_Button.png';
            BUTTON_PRESSED_IMAGES[20] = 'Images/Others/Store_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[20] = 'Images/Others/Store_Button.png';
            
            //change the src of the button
            BUTTONS[19].src = BUTTON_UNPRESSED_IMAGES[19];
            
            //display the elements needed and hide the rest
            COIN_DISPLAY.style.display = 'block';
            SHOP_OVERLAY.style.display = 'block';
            SHOP_BUTTON.style.display = 'block';
            ANVIL_BUTTON.style.display = 'block';
            SHOP_BG.style.display = 'block';
            EXIT_BUTTON.style.display = 'block';
            SHOP_CARDS.style.display = 'none'; 
            SHOP_TXT.style.display = 'block';
            SELECT_BUTTONS.style.display = 'none';
            COINS_TXT.style.display = 'block';
            ANVIL_BUTTONS.style.display = "block";
            ANVIL_CARDS.style.display = "block";
            ARROW_IMG.style.display = "block";
            UPGRADE_BUTTON.style.display = 'block';
            COST_TXT.style.display = 'block';

            //create the elements needed for the anvil 
            createAnvilCardElement(upgradedIndex)


                  
        }
        // if the user clicks the shop image
        if (target == SHOP_IMG){
            //make shopMenu true
            shopMenu = true;

            //change the button 
            BUTTON_PRESSED_IMAGES[20] = 'Images/Others/Larger_Store_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[20] = 'Images/Others/Larger_Store_Button.png';
            BUTTON_PRESSED_IMAGES[19] = 'Images/Others/Anvil_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[19] = 'Images/Others/Anvil_Button.png';
            
            //change the button src
            SHOP_BUTTON.src = BUTTON_UNPRESSED_IMAGES[20];

            //display the elements needed and hide the rest
            COIN_DISPLAY.style.display = 'block';
            SHOP_OVERLAY.style.display = 'block';
            SHOP_BUTTON.style.display = 'block';
            ANVIL_BUTTON.style.display = 'block';
            SHOP_BG.style.display = 'block';
            EXIT_BUTTON.style.display = 'block';
            SHOP_CARDS.style.display = 'block'; 
            SHOP_TXT.style.display = 'block';
            SELECT_BUTTONS.style.display = 'block';
            COINS_TXT.style.display = 'block';
            ANVIL_CARDS.style.display = "none";
            ARROW_IMG.style.display = "none";
            UPGRADE_BUTTON.style.display = 'none';

        }
        // if the user clicks the exit button in the shop
        if (target == EXIT_BUTTON){
            // remove the elements from the shop 
            // removes the big card from the shop tab
            if (shopCardElement != undefined){// removes the big card from the shop tab
                shopCardElement.remove();
                shopCardTitleElement.remove();
                shopCardCostElement.remove();
                shopCardDescriptionElement.remove();
            }
            // remove the elements from the anvil tab 
            if (anvilCardElements != undefined){
                anvilCardCostElements.remove();
                anvilCardDescrpitionElements.remove();
                anvilCardElements.remove();
                anvilCardTitleElements.remove();
                upgradeAnvilCardCostElements.remove();
                upgradeAnvilCardDescrpitionElements.remove();
                upgradeAnvilCardElements.remove();
                upgradeAnvilCardTitleElements.remove();
            }
            // make the button image regular 
            BUTTON_PRESSED_IMAGES[19] = 'Images/Others/Anvil_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[19] = 'Images/Others/Anvil_Button.png';
            BUTTON_PRESSED_IMAGES[20] = 'Images/Others/Store_Pressed.png';
            BUTTON_UNPRESSED_IMAGES[20] = 'Images/Others/Store_Button.png';

            // hide all elements
            COIN_DISPLAY.style.display = 'none';
            SHOP_OVERLAY.style.display = 'none';
            SHOP_BUTTON.style.display = 'none';
            ANVIL_BUTTON.style.display = 'none';
            SHOP_BG.style.display = 'none';
            BUY_BUTTON.style.display = 'none';
            EXIT_BUTTON.style.display = 'none';
            SHOP_CARDS.style.display = 'none'; 
            SHOP_TXT.style.display = 'none';
            COST_TXT.style.display = 'none';
            SELECT_BUTTONS.style.display = 'none';
            ANVIL_BUTTONS.style.display = "none";
            COINS_TXT.style.display = 'none';
            ANVIL_CARDS.style.display = "none";

            //make all menus false 
            anvilMenu = false;
            cardSelected = false;
            shopMenu = false; 


        }

        //if user press the buy button in shop
        if(target == BUY_BUTTON){
            //display text box 
            BUY_TXT.style.display = 'block';
            
            //get the cost of the selected card
            costCard = shopCards[selectedCard].buyCost;
                
            //first check if the user has already bought the card
            if (boughtCards[selectedCard] == true){
                
                // Update the BUY_TXT element 
                // Change the text to 'NOT IN STOCK' and set the text color to red 
                BUY_TXT.innerText = 'NOT IN STOCK';
                BUY_TXT.style.color = "red";

                setTimeout(() => {//run code after 0.5sec 
                    // clear buy text
                    BUY_TXT.innerText = '';

                    // stop displaying cost and buy button
                    COST_TXT.style.display = 'none';
                    BUY_BUTTON.style.display = 'none';

                    //remove the card that was on the right side 
                    shopCardElement.remove();
                    shopCardTitleElement.remove();
                    shopCardCostElement.remove();
                    shopCardDescriptionElement.remove();
                    
                    // make cardSelected false
                    cardSelected = false;

                }, 500);

            }
            else if (0 > (currency - costCard)){// check if the user has enought coins to buy the card
                
                // Update the BUY_TXT element 
                // Change the text to 'NOT ENOUGH COINS' and set the text color to red 

                BUY_TXT.innerText = 'NOT ENOUGH COINS';
                BUY_TXT.style.color = "red";

                setTimeout(() => {

                    // Update the BUY_TXT element 
                    BUY_TXT.innerText = '';
                }, 500);
                
                // make the text centered
                moveBuyTxt = true;
            }else if(0 <= (currency - costCard)){

                // Update the BUY_TXT element 
                // Change the text to 'PURCHASED' and set the text color to green
                BUY_TXT.innerText = 'PURCHASED';
                BUY_TXT.style.color = "green";
                
                // Deduct the cost of the card from the player's current currency balance.
                currency -= costCard;

                //make that card bought true
                boughtCards[selectedCard] = true;

                // put bought card into player deck
                playerDeck = insertElement(playerDeck,shopCards[selectedCard],playerDeck.length);
                
                setTimeout(() => {//run after 0.5sec
                    //update BUY_TXT
                    BUY_TXT.innerText = '';

                    //stop displaying COST_TXT and BUY_BUTTON
                    COST_TXT.style.display = 'none';
                    BUY_BUTTON.style.display = 'none';

                    //remove card that was on the right side 
                    shopCardElement.remove();
                    shopCardTitleElement.remove();
                    shopCardCostElement.remove();
                    shopCardDescriptionElement.remove();
                    cardSelected = false;

                }, 500);
            }
            
        }
        // Iterate through all the selection buttons (assumed to represent the 6 buyable cards).
        for (let i in SELECTION_BUTTONS) { // Runs 6 times, once for each card.

            // Check if the clicked button matches the current selection button.
            if (target == SELECTION_BUTTONS[i]) { 
                selectedCard = i; // Store the index of the selected card.

                // If there is already a card displayed in the shop, remove the previous card's elements.
                if (shopCardElement != undefined) { 
                    shopCardElement.remove(); // Remove the card image.
                    shopCardTitleElement.remove(); // Remove the card title.
                    shopCardCostElement.remove(); // Remove the card cost.
                    shopCardDescriptionElement.remove(); // Remove the card description.
                }

                // Create and configure the card image element.
                shopCardElement = document.createElement('img');
                shopCardElement.src = cardElements[i].src; // Set the image source to the selected card's source.
                shopCardElement.style.transform = 'scale(2,2)'; // Scale the image for emphasis.
                shopCardElement.setAttribute('draggable', 'false'); // Prevent the card image from being dragged.

                // Create and configure the card title element.
                shopCardTitleElement = document.createElement('h1');
                shopCardTitleElement.innerText = cardTitleElements[i].innerText; // Set the title text from the card data.
                shopCardTitleElement.style.width = '160px';
                shopCardTitleElement.style.fontSize = '30px';
                shopCardTitleElement.style.color = 'white';
                shopCardTitleElement.style.fontFamily = 'MyCustomFont'; 
                shopCardTitleElement.style.display = 'block';
                shopCardTitleElement.style.textAlign = 'center'; 

                // Create and configure the card cost element.
                shopCardCostElement = document.createElement('p');
                shopCardCostElement.innerText = cardCostElements[i].innerText; // Set the cost text from the card data.
                shopCardCostElement.style.width = '200px';
                shopCardCostElement.style.fontSize = '26px';
                shopCardCostElement.style.color = 'white';
                shopCardCostElement.style.textAlign = 'center'; 
                shopCardCostElement.style.fontFamily = 'MyCustomFont'; 

                // Create and configure the card description element.
                shopCardDescriptionElement = document.createElement('p');
                shopCardDescriptionElement.innerText = cardDescriptionElements[i].innerText; // Set the description text from the card data.
                shopCardDescriptionElement.style.width = '180px';
                shopCardDescriptionElement.style.fontSize = '22px';
                shopCardDescriptionElement.style.color = 'white';
                shopCardDescriptionElement.style.textAlign = 'center'; 
                shopCardDescriptionElement.style.fontFamily = 'MyCustomFont'; 

                // Add the newly created elements to the SHOP_CARDS container.
                SHOP_CARDS.appendChild(shopCardElement); // Add the card image.
                SHOP_CARDS.appendChild(shopCardTitleElement); // Add the card title.
                SHOP_CARDS.appendChild(shopCardCostElement); // Add the card cost.
                SHOP_CARDS.appendChild(shopCardDescriptionElement); // Add the card description.

                // Ensure the cost display is visible if it's currently hidden.
                if (COST_TXT.style.display != 'block') {
                    COST_TXT.style.display = 'block'; // Make the cost display visible.
                }

                cardSelected = true; // Indicate that a card has been selected.
            }
        }
        if (target == LEAVE_BUTTON){// if leave is pressed 
            transition = 'Start';
            startTransition();
        }

        //anvil menu 
        // Check if the user clicked the right button to cycle through cards in the anvil upgrade system.
        if (target == ANVIL_RIGHT_BUTTON) { 

            // Check if the upgraded index is less than the last card in the player's deck.
            if (upgradedIndex < playerDeck.length - 1) { 
                upgradedIndex++; // Move to the next card in the deck.

                // Remove all existing elements for the current card and its upgrade preview.
                anvilCardCostElements.remove(); // Remove the current card's cost display.
                anvilCardDescrpitionElements.remove(); // Remove the current card's description display.
                anvilCardElements.remove(); // Remove the current card's image.
                anvilCardTitleElements.remove(); // Remove the current card's title.
                upgradeAnvilCardCostElements.remove(); // Remove the upgraded card's cost display.
                upgradeAnvilCardDescrpitionElements.remove(); // Remove the upgraded card's description display.
                upgradeAnvilCardElements.remove(); // Remove the upgraded card's image.
                upgradeAnvilCardTitleElements.remove(); // Remove the upgraded card's title.

                // Create and display elements for the new card based on the updated index.
                createAnvilCardElement(upgradedIndex);

            } else { 
                // If the upgraded index exceeds the deck's length, reset to the first card.
                upgradedIndex = 0; // Reset to the first card in the deck.

                // Remove all existing elements for the current card and its upgrade preview.
                anvilCardCostElements.remove(); // Remove the current card's cost display.
                anvilCardDescrpitionElements.remove(); // Remove the current card's description display.
                anvilCardElements.remove(); // Remove the current card's image.
                anvilCardTitleElements.remove(); // Remove the current card's title.
                upgradeAnvilCardCostElements.remove(); // Remove the upgraded card's cost display.
                upgradeAnvilCardDescrpitionElements.remove(); // Remove the upgraded card's description display.
                upgradeAnvilCardElements.remove(); // Remove the upgraded card's image.
                upgradeAnvilCardTitleElements.remove(); // Remove the upgraded card's title.

                // Create and display elements for the first card based on the reset index.
                createAnvilCardElement(upgradedIndex);
            }
        }
        // Check if the user clicked the left button to cycle backward through cards in the anvil upgrade system.
        if (target == ANVIL_LEFT_BUTTON) { 

            // Check if the upgraded index is greater than or equal to 1 (not the first card in the deck).
            if (upgradedIndex >= 1) { 
                upgradedIndex--; // Move to the previous card in the deck.

                // Remove all existing elements for the current card and its upgrade preview.
                anvilCardCostElements.remove(); // Remove the current card's cost display.
                anvilCardDescrpitionElements.remove(); // Remove the current card's description display.
                anvilCardElements.remove(); // Remove the current card's image.
                anvilCardTitleElements.remove(); // Remove the current card's title.
                upgradeAnvilCardCostElements.remove(); // Remove the upgraded card's cost display.
                upgradeAnvilCardDescrpitionElements.remove(); // Remove the upgraded card's description display.
                upgradeAnvilCardElements.remove(); // Remove the upgraded card's image.
                upgradeAnvilCardTitleElements.remove(); // Remove the upgraded card's title.

                // Create and display elements for the new card based on the updated index.
                createAnvilCardElement(upgradedIndex);

            } else { 
                // If the upgraded index is less than 1 (at the first card), wrap around to the last card in the deck.
                upgradedIndex = playerDeck.length - 1; // Set to the last card index.

                // Remove all existing elements for the current card and its upgrade preview.
                anvilCardCostElements.remove(); // Remove the current card's cost display.
                anvilCardDescrpitionElements.remove(); // Remove the current card's description display.
                anvilCardElements.remove(); // Remove the current card's image.
                anvilCardTitleElements.remove(); // Remove the current card's title.
                upgradeAnvilCardCostElements.remove(); // Remove the upgraded card's cost display.
                upgradeAnvilCardDescrpitionElements.remove(); // Remove the upgraded card's description display.
                upgradeAnvilCardElements.remove(); // Remove the upgraded card's image.
                upgradeAnvilCardTitleElements.remove(); // Remove the upgraded card's title.

                // Create and display elements for the last card based on the updated index.
                createAnvilCardElement(upgradedIndex);
            }
        }
        // Check if the user clicked the upgrade button.
        if (target == UPGRADE_BUTTON) { 
            BUY_TXT.style.display = "block"; // Ensure the text display element is visible.

            // Check if the selected card is already upgraded.
            if (playerDeck[upgradedIndex].upgradeStatus == true) { 
                BUY_TXT.innerText = 'UPGRADED'; // Notify the user that the card is already upgraded.
                BUY_TXT.style.color = "red"; // Set the text color to red for emphasis.
                
                // Clear the message after 0.5 seconds.
                setTimeout(() => {
                    BUY_TXT.innerText = '';
                }, 500);
            
            // Check if the user does not have enough currency to upgrade the card.
            } else if (currency < playerDeck[upgradedIndex].upgradeCost) { 
                BUY_TXT.innerText = 'NOT ENOUGH COINS'; // Notify the user of insufficient funds.
                BUY_TXT.style.color = "red"; // Set the text color to red for emphasis.
                
                // Clear the message after 0.5 seconds.
                setTimeout(() => {
                    BUY_TXT.innerText = '';
                }, 500);
            
            // If the user has enough currency to purchase the upgrade.
            } else if (currency >= playerDeck[upgradedIndex].upgradeCost) { 
                BUY_TXT.innerText = 'PURCHASED'; // Notify the user of a successful purchase.
                BUY_TXT.style.color = "green"; // Set the text color to green for confirmation.
                currency -= playerDeck[upgradedIndex].upgradeCost; // Deduct the upgrade cost from the user's currency.
                boughtCards[selectedCard] = true; // Mark the selected card as bought.

                // Update the upgraded card in the player's deck.
                for (let card in CARDS) { 
                    // Check if the card in CARDS is upgraded and matches the selected card's name.
                    if (CARDS[card].upgradeStatus == true) { 
                        if (CARDS[card].name == playerDeck[upgradedIndex].name) { 
                            playerDeck[upgradedIndex] = CARDS[card]; // Replace the card in the player's deck with the upgraded version.
                        }
                    }
                }
                
                // After a delay of 500 milliseconds, refresh the displayed card elements.
                setTimeout(() => {
                    anvilCardCostElements.remove(); // Remove the current card's cost display.
                    anvilCardDescrpitionElements.remove(); // Remove the current card's description display.
                    anvilCardElements.remove(); // Remove the current card's image.
                    anvilCardTitleElements.remove(); // Remove the current card's title.
                    upgradeAnvilCardCostElements.remove(); // Remove the upgraded card's cost display.
                    upgradeAnvilCardDescrpitionElements.remove(); // Remove the upgraded card's description display.
                    upgradeAnvilCardElements.remove(); // Remove the upgraded card's image.
                    upgradeAnvilCardTitleElements.remove(); // Remove the upgraded card's title.

                    // Recreate and display the updated card elements based on the current index.
                    createAnvilCardElement(upgradedIndex);

                    // Clear the BUY_TXT message.
                    BUY_TXT.innerText = '';
                }, 500);
            }
        }
    }
    // check if player is on rest game screen
    else if(gamestate == gameStates[3]){
        // Check if the user clicked on the "rest" image element.
        if (target == REST_IMG) { 
            transition = 'Start'; // Set the transition state to "Start".
            
            // Display the "rest-txt" element, indicating the start of the resting phase.
            REST_TXT.style.display = "block";

            // Restore the health of the first and second party members to their maximum health.
            party[0].health = party[0].maxHealth; // Fully heal the first party member.
            party[1].health = party[1].maxHealth; // Fully heal the second party member.

            resting = true; // Set the resting state to true.

            // After a delay of 3 seconds (3000 milliseconds), update the "rest-txt" element.
            setTimeout(() => {
                REST_TXT.innerText = "Health Regained"; // Notify the player that health has been restored.
                REST_TXT.style.color = "red"; // Set the text color to red for emphasis.

                // After an additional delay of 1 second (1000 milliseconds), clear the message and hide the text element.
                setTimeout(() => {
                    REST_TXT.innerText = ""; // Clear the text content.
                    REST_TXT.style.display = "none"; // Hide the text element.
                }, 1000);    
            }, 3000);

            startTransition(); // Call a function to handle the start of the transition phase.
        }else if(target == LEAVE_BUTTON){ // if click the leave image 
            transition = 'Start';
        }else if(target == UPGRADE_BUTTON){ // if click the upgrade image 
            

            // display everything 
            CHARACTER_SELECTION_MENU.style.display = "block"
            REST_OVERLAY.style.display = 'block';
            CHARACTER_SELECTION_PAGE1.style.display = 'block';
            CHARACTER_STAT_PAGE2.style.display = 'block'
            SELECTION_TITLE.style.color = 'white';
            CHARACTER_STATS_UPGRADABLE.style.display = "block";
            CHARACTER_NAME.style.display = "none";
            NEXT_BUTTON.style.display = "none";
            CHARACTER_BASE_STATS.style.display = "none";
            CHARACTER_INFO.style.display = "none";

            //increase z-index to bring forward
            CHARACTER_STATS_UPGRADABLE.style.zIndex = 2;
            SELECTION_TITLE.style.zIndex = 2;
            CHARACTER_SELECTION_MENU.style.zIndex = 2;
            CHARACTER_STAT_PAGE2.style.zIndex = 2;
            CHARACTER_CYCLE_RIGHT.style.zIndex = 2;
            CHARACTER_CYCLE_LEFT.style.zIndex = 2;
            CHARACTER_CRIT_CHANCE_RIGHT.style.zIndex = 2;
            CHARACTER_CRIT_CHANCE_LEFT.style.zIndex = 2;
            CHARACTER_CRIT_DMG_LEFT.style.zIndex = 2;
            CHARACTER_CRIT_DMG_RIGHT.style.zIndex = 2;
            CHARACTER_ATK_LEFT.style.zIndex = 2;
            CHARACTER_ATK_RIGHT.style.zIndex = 2;
            CHARACTER_DEF_LEFT.style.zIndex = 2;
            CHARACTER_DEF_RIGHT.style.zIndex = 2;
            X_BUTTON.style.zIndex = 2;
            CONFIRM_BUTTON.style.zIndex = 2;



        }
        // this is all used for changing stats 
        if (target === CHARACTER_CYCLE_RIGHT) {// increase health
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                health += 5;
                checkStatPoint();//check amount of statpoints
            }
        } else if (target === CHARACTER_CYCLE_LEFT) {// decrease health
            if (health > minHealth) {// making sure that health doesnt go below the base stat
                statPoints++;
                health -= 5;
                checkStatPoint();//check amount of statpoints
            }
        }
        else if (target === CHARACTER_ATK_RIGHT) {// increase attack
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                attack += 1.5;
                checkStatPoint();//check amount of statpoints
            }
        } else if (target === CHARACTER_ATK_LEFT) {// decrease attack
            if (attack > minAttack) {// making sure that attack doesnt go below the base stat
                statPoints++;
                attack -= 1.5;
                checkStatPoint();//check amount of statpoints
            }
        }
        else if (target === CHARACTER_DEF_RIGHT) {// increase defense
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                defense += 1.5;
                checkStatPoint();//check amount of statpoints
            }
        } else if (target === CHARACTER_DEF_LEFT) {// decrease defense
            if (defense > minDefense) {// making sure that defense doesnt go below the base stat
                statPoints++;
                defense -= 1.5;
                checkStatPoint();//check amount of statpoints
            }
        }
        else if (target === CHARACTER_CRIT_DMG_RIGHT) {// increase crit multiplier
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                critMultiplier += 0.05;
                checkStatPoint();//check amount of statpoints
            }
        } else if (target === CHARACTER_CRIT_DMG_LEFT) {// decrease crit multiplier
            if (critMultiplier > minCritMultiplier) {// making sure that crit multiplier doesnt go below the base stat
                statPoints++;
                critMultiplier -= 0.05;
                checkStatPoint();//check amount of statpoints
            }
        }
        else if (target === CHARACTER_CRIT_CHANCE_RIGHT) {//increase crit chance
            if (statPoints != 0) {// only increase if stats is not 0
                statPoints--;
                critRate += 0.5;
                checkStatPoint();//check amount of statpoints
            }
        } else if (target === CHARACTER_CRIT_CHANCE_LEFT) {// decrease crit chance
            if (critRate > minCritRate) {// making sure that crit chance doesnt go below the base stat
                statPoints++;
                critRate -= 0.5;
                checkStatPoint();//check amount of statpoints
            }
        }

        else if (target == X_BUTTON) { // if clicked the x button that shows up when all the stats have been choosen
            resetStatPoints();// reset all stats to base and stat points to 20
        }
        else if (target == CONFIRM_BUTTON) {// if clicked check mark button shows up when all the stats have been choosen
            REST_OVERLAY.style.display = "none";
            CHARACTER_SELECTION_MENU.style.display = "none"
            REST_OVERLAY.style.display = 'none';
            CHARACTER_SELECTION_PAGE1.style.display = 'none';
            CHARACTER_STAT_PAGE2.style.display = 'none'
            CHARACTER_STATS_UPGRADABLE.style.display = "none";
        }

    }
    if(target == RESTART_BTN){//once they died and press restart
        // remove save
        window.location.reload(); // force reload

    }

}

//used to overlay an HTML element on top of a canvas element at a specific location
function positionElement(element, canvas, x, y) {

    // get the position of the canvas
    const rect = canvas.getBoundingClientRect();

    // set the position style of the element to absolute
    element.style.position = 'absolute';

    // position the element on the canvas
    element.style.left = String(rect.left + x) + 'px';
    element.style.top = String(rect.top + y) + 'px';
    
}


// draw the transition
function DrawTransition(){
    // increase the width and height of the elements until they reach the center
    TRANSITION_RECT1.style.width = String(progress) + 'px';
    TRANSITION_RECT1.style.height = String(CANVA_HEIGHT) + 'px';
    TRANSITION_RECT2.style.width = String(progress) + 'px';
    TRANSITION_RECT2.style.height = String(CANVA_HEIGHT) + 'px';
    TRANSITION_RECT3.style.width = String(CANVA_WIDTH) + 'px';
    TRANSITION_RECT3.style.height = String(progress/1.75) + 'px';
    TRANSITION_RECT4.style.width = String(CANVA_WIDTH) + 'px';
    TRANSITION_RECT4.style.height = String(progress/1.75) + 'px';

    // position the elemnts to the canvas
    positionElement(TRANSITION_RECT1,CANVA,0,0)
    positionElement(TRANSITION_RECT2,CANVA,CANVA_WIDTH-progress,0)
    positionElement(TRANSITION_RECT3,CANVA,0,0)
    positionElement(TRANSITION_RECT4,CANVA,0,CANVA_HEIGHT-progress/1.75)
    
}

// start the transition between screens
function startTransition() {
    // draws the black screen
    DrawTransition();

    // increase progress until it reaches the center
    if (progress < 575) {
        TRANSITION.style.display = 'block';
        progress += 7 * deltaTimeMultiplier; 
       
    } 
    else{
        
        // check which screen is being transitioned to
        if (menu){
            MENU_SCREEN.style.display = 'none';
            CHARACTER_SELECTION_MENU.style.display = 'block';
            menu = false;
            characterSelection = true;
        }
        else if (characterSelection){
            CHARACTER_SELECTION_MENU.style.display = 'none';
            GAME_PAGE.style.display = "block";
            characterSelection = false;
            game = true;
            gamestate = gameStates[0];    
            minHealth = health;
            minAttack = attack;
            minCritMultiplier = critMultiplier;
            minDefense = defense;
            minCritRate = critRate; 
            
        }
        // check if the player is in the game
        else if (game){
            
            // check if the player is in the map
            if (gamestate == gameStates[0]){
                // check which event the player is going to and change the game state
                if (playerEvent.type == 'combat'){

                    gamestate = gameStates[1];

                    // load in players health
                    MAIN_HEALTHBAR.max = party[0].maxHealth;
                    MAIN_HEALTHBAR.value = party[0].health;
                    SUPPORT_HEALTHBAR.max = party[1].maxHealth;
                    SUPPORT_HEALTHBAR.value = party[1].health;
                    // reset all players energy and cards
                    party[0].energy = 4;

                    // get the deck
                    drawDeck = shuffleDeck(playerDeck);
                    

                    // generate the enemies
                    enemies = generateEnemies(playerEvent.id.substring(0,1), world);
                    setupEnemies(enemies);
                    createCharacterHitBox()
                    createSupportHitBox()
                    
                    // save the game
                   

                    // get the cards
                    [hand, drawDeck, discardPile] = draw(drawDeck,discardPile, 5);
                    createCardElement(hand);

                }
                // check if the player is going to shop
                else if (playerEvent.type == 'shop'){

                    // change gamestate
                    gamestate = gameStates[2];
                    GAME_SCREENS[2].style.display = 'none'; // Hide the shop screen
                    GAME_SCREENS[0].style.display = 'block'; // Show the menu screen
                    COINS_TXT.style.display = "none";
                    COIN_DISPLAY.style.display = "none";
                    
                    // get the cards that will sold in the store
                    let randomizedCards = shuffleDeck(CARDS);
                    shopCards = new Array(6);
                    for (let i = 0; i < 6; i++){
                        shopCards[i] = randomizedCards[i];

                    }
                    // create the elements
                    createCardElement(shopCards);
                    boughtCards = new Array(shopCards.length)
                    for (let i in shopCards){
                        boughtCards[i] = false;
                        SHOP_CARDS.appendChild(cardElements[i])
                        SHOP_CARDS.appendChild(cardTitleElements[i])
                        SHOP_CARDS.appendChild(cardDescriptionElements[i])
                        SHOP_CARDS.appendChild(cardCostElements[i])
                    }

                    // save game
                    
                }
                else if (playerEvent.type == 'rest'){
                    gamestate = gameStates[3];
                    
                    health = party[0].maxHealth;
                    checkStatPoint()
                    minStatPoints = statPoints;

                    
                }   
                
            }
            // check if the player is resting
            else if (resting){
                resting = false;
            }
            else{
                // check if the player is at the end of the map
                if (playerEvent.id.substring(0,1) == eventMap.length-1){

                    // enter next world
                    world += 1;
                    NEXT_WORLD_TXT.innerText = 'ENTERING NEXT WORLD: \n WORLD ' + (world+1);
                    NEXT_WORLD_TXT.style.display = 'block';

                    // change to map
                    gamestate = gameStates[0];
                    // check which screen the player is transitioning to
                    for (let state = 0; state < gameStates.length; state++){
                        if (gamestate != gameStates[state]){
                            GAME_SCREENS[state].style.display = 'none';
                        }
                        else{
                            GAME_SCREENS[state].style.display = 'block';
                            CHARACTER_STAT_PAGE2.style.display = 'block';
                            upgradingStats = true;
                        }
                    }

                    // have the next world text stay on screen for a bit
                    setTimeout(() => {
                        // remove all map elements
                        for (let stage in mapElements){
                            for (let eventElement in mapElements[stage]){
                                mapElements[stage][eventElement].remove();
                            }
                        }
                        
                        
                        // reset player event
                      
                        // generate a new map
                        

                        // hide text
                        NEXT_WORLD_TXT.style.display = 'none';

                        // exit transition
                        transition = 'End';
                        
                       
                       
                        
                    }, 2500)
                    transition = 'none';
                    return;

                }
                else{
                    gamestate = gameStates[0];
                }
               
                
            }
            // check which screen the player is transitioning to
            for (let state = 0; state < gameStates.length; state++){
                if (gamestate != gameStates[state]){
                    GAME_SCREENS[state].style.display = 'none';
                }
                else{
                    GAME_SCREENS[state].style.display = 'block';
                    CHARACTER_STAT_PAGE2.style.display = 'block';
                    upgradingStats = true;
                }
            }
        }
        if(!playerDead){
            transition = 'End';

        }
        else{
            transition = 'none';

            DEATH_TXT.style.display = "block";
            RESTART_BTN.style.display = "block"
            
        }
        // save the game state
        
        
    } 
    
    
}


// exit transition
function endTransition() {
     
    // draws the black screen
    DrawTransition()
    
    // decrease the progression to descrease the size of the black screen
    if (progress > 0) {
        progress -= 7*deltaTimeMultiplier;
    }
    // stop the transition 
    else{
        TRANSITION.style.display = 'none';
        transition = 'none';
        if (gamestate === gameStates[1]){
            slideInTurnText();
        }
        if(gamestate === gameStates[2]){
            COINS_TXT.style.display = 'none';
            COIN_DISPLAY.style.display = 'none';
            typeWriter();
            
        }
    }
    
}

// Game Loop
function gameLoop(currentTime) {

    // adjust the characters to move to the left to show the stat page
    if (moveLeft){
        characterBgX=characterBgX/3 - 75;

       
        
        
    }
    
    // adjust the characters to move to the right if they press the back button
    //reset the move left
    if (moveRight){
        characterBgX=300;
        //checking the selected character
       
        
    }

    
    // get difference in time between last frame
    deltaTime = currentTime - previousTime;

    // adjust game elements according to the missing time between each frame
    deltaTimeMultiplier = deltaTime / FRAME_INTERVAL
    previousTime = currentTime;

    // Scale animation and movement by deltaTime
    if (!playerDead){
        animationGameFrame += deltaTimeMultiplier; 
    }

    for (let enemyFrame in enemyGameFrames){
        enemyGameFrames[enemyFrame] += deltaTimeMultiplier;
    }
    
    // moving background 
    menu1x -= 1 * deltaTimeMultiplier;
    menu2x -= 1 * deltaTimeMultiplier;
    
    // reset background
    if (menu1x < -CANVA_WIDTH) {
        menu1x = menu2x + CANVA_WIDTH;
    } 
    if (menu2x < -CANVA_WIDTH) {
        menu2x = menu1x + CANVA_WIDTH;
    }

    let timeDifference = (enemyTurnEndTiming - enemyTurnInitialTiming)/1000;
    if (!playerTurn){
        enemyTurn(timeDifference);
    }
    
    // redraw everything on canva
    animate()
    
    requestAnimationFrame(gameLoop);
}


// randomize enemy
function randomEnemy(difficultyScale){

    // enemy types
    const ENEMIES_TYPES = [Demon, Goblin, Mushroom, Slime];
    
    // probability of each enemy
    const PROBABILITIES = [0.05, 0.1, 0.4, 1];

    // generate a random number
    let rand = Math.random();

    // loop through each enemy in the array
    for (let enemy_type = 0; enemy_type < ENEMIES_TYPES.length; enemy_type++){
        
        // check which enemy to return
        if (rand < PROBABILITIES[enemy_type]){

            // create a new enemy
            return new ENEMIES_TYPES[enemy_type](difficultyScale);
        }
    }
}

// Generate moves for each enemy
function generateEnemyAttacks(enemies) {
    for (let enemy in enemies) {
        if (enemies[enemy] != null) {
            enemies[enemy].getMoves();
        }
    }
}

// Create a set of enemies based on stage and world difficulty
function generateEnemies(stage, world) {
    // Calculate difficulty scale based on stage and world
    let difficultyScale = (1.1**stage) * (1 + world * 0.2);


        // Randomly determine the number of enemies (2, 3, or 4)
        let rand = Math.random();
        let numEnemies;
        if (rand < 0.33) {
            numEnemies = 2;
        } 
        else if (rand < 0.66) {
            numEnemies = 3;
        } 
        else {
            numEnemies = 4;
        }

        // Create an array of enemies and assign each a random enemy based on difficulty
        const ENEMIES = new Array(numEnemies);
        for (let enemy = 0; enemy < ENEMIES.length; enemy++) {
            ENEMIES[enemy] = randomEnemy(stage, difficultyScale);
        }

        // Generate attacks for each enemy and return the array of enemies
        generateEnemyAttacks(ENEMIES);
        return ENEMIES;

}


// set up enemies
function setupEnemies(enemies){

    // create all the animations
    enemyAnimations = new Array(enemies.length);
    for (let animation = 0; animation < enemyAnimations.length; animation++){
        enemyAnimations[animation] = 'Idle';
    }
    enemyHitBoxes = new Array(enemies.length)
    
    
    
    // create all the health bars
    enemiesHPBar = new Array(enemies.length);
    enemiesHPText = new Array(enemies.length);
    for (let enemyHP in enemies){
        let newProgressElement = document.createElement('progress');
        let newTextElement = document.createElement('p'); 
        newProgressElement.setAttribute('id', 'Enemy-HP-Bar-' + (Number(enemyHP)+1));
        newTextElement.setAttribute('id', 'Enemy-HP-Text-' + (Number(enemyHP)+1));
        newTextElement.style.width = '55px';
        newTextElement.style.textAlign = 'center';
        newProgressElement.max = enemies[enemyHP].maxHealth;
        newProgressElement.value = enemies[enemyHP].maxHealth;

        // set the sizes of the health bars
        newProgressElement.style.width = '60px';
        newProgressElement.style.height = '7px';

        newTextElement.innerText = enemies[enemyHP].health+"/"+enemies[enemyHP].maxHealth;

        // set the style of the text
        newTextElement.style.color = 'white';
        newTextElement.style.fontFamily = 'MyCustomFont';

        ENEMIES_DIV.appendChild(newProgressElement);
        ENEMIES_DIV.appendChild(newTextElement);
        enemiesHPBar[enemyHP] = newProgressElement;
        enemiesHPText[enemyHP] = newTextElement;
    }


    // create all the hitboxes
    for (let enemy in enemies){
        let hitbox = document.createElement('div');
        hitbox.setAttribute('id', 'Enemy'+ (Number(enemy)+1) +'-HitBox');
        ENEMIES_DIV.appendChild(hitbox)
        for (let name in ENEMY_NAMES){
            if (enemies[enemy].name == ENEMY_NAMES[name]){
                // hitbox.style.border = '5px solid white';
                hitbox.style.width = String(ENEMY_HITBOX_WIDTHS[name]) +'px';
                hitbox.style.height = String(ENEMY_HITBOX_HEIGHTS[name]) +'px';
            }
        }
        enemyHitBoxes[enemy] = hitbox;
    }

    // setup all their animations
    enemyGameFrames = new Array(enemies.length)
    for (let enemy in enemies){
        enemyGameFrames[enemy] = 0;
    }
}
// create character hitbox
function createCharacterHitBox(){

    // create hitbox element
    let hitbox = document.createElement('div');
    hitbox.setAttribute('id', 'Character-HitBox');
    PARTY_HITBOXS.appendChild(hitbox)

    // assign its width and height
    for (let name in characters){
        if (party[0].name == characters[name]){
            hitbox.style.width = String(CHARACTER_HITBOX_WIDTH[name]) +'px';
            hitbox.style.height = String(CHARACTER_HITBOX_HEIGHT[name]) +'px';
        }
    }
    characterHitBox = hitbox;
    
}
// create support hitbox
function createSupportHitBox(){

    // create hitbox element
    let hitbox = document.createElement('div');
    hitbox.setAttribute('id', 'Support-HitBox');
    PARTY_HITBOXS.appendChild(hitbox)

    // assign its width and height
    for (let name in supportCharacters){
        if (party[1].name == supportCharacters[name]){
            hitbox.style.width = String(SUPPORT_HITBOX_WIDTH[name]) +'px';
            hitbox.style.height = String(SUPPORT_HITBOX_HEIGHT[name]) +'px';
        }
    }
    supportHitBox = hitbox;
    
}



// shuffles the deck
function shuffleDeck(deck) {

    // copy the array
    let newDeck = new Array(deck.length);
    for (let card in deck){
        newDeck[card] = deck[card];
    }

    // shuffle the cards
    for (let i = newDeck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1)); // Random index from 0 to i
        [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]]; // Swap element
    }

    // return the shuffled cards
    return newDeck;
}

// draw cards
function draw(drawDeck, discardPile, numCards){
    // Create hand array
    let hand = new Array(numCards);

    // Draw cards from drawDeck into hand
    for (let card = 0; card < hand.length; card++) {
        // Refill drawDeck from discardPile if empty
        if (drawDeck[0] == undefined) {
            drawDeck = shuffleDeck(discardPile);
            discardPile = [];
            hand[card] = drawDeck[0];
            drawDeck = indexRemover(drawDeck, 0, 1);
        } else {
            hand[card] = drawDeck[0];
            drawDeck = indexRemover(drawDeck, 0, 1);
        }
    }

    // Return hand, drawDeck, and discardPile
    return [hand, drawDeck, discardPile];

}

// create card element
function createCardElement(cards){
    // create different array to store the elements of the cards
    cardElements = new Array(cards.length);
    cardTitleElements = new Array(cards.length);
    cardDescriptionElements = new Array(cards.length);
    cardCostElements = new Array(cards.length);
    cardElementsHoveringStatus = new Array(cards.length);
    cardElementClickStatus = new Array(cards.length);
    // loop through each card in the hand
    for (let card in cards){
        

        // create new image element for the card
        let newImgElement = document.createElement('img');
        newImgElement.setAttribute('id', 'card' + (Number(card)+1))
        newImgElement.setAttribute('draggable', 'false');
        cardElements[card] = newImgElement;

        // create new title element for the title of the card
        let newTitleElement = document.createElement('h1');
        newTitleElement.setAttribute('id', 'card' + (Number(card)+1) +'-Title');
        newTitleElement.innerText = cards[card].name;
        newTitleElement.style.width = '80px';
        newTitleElement.style.fontSize = '15px';
        newTitleElement.style.color = 'white';
        newTitleElement.style.fontFamily = 'MyCustomFont';
        newTitleElement.style.display = 'block';
        newTitleElement.style.textAlign = 'center';
        cardTitleElements[card] = newTitleElement;

        // create new description element for the description of the card
        let newDescriptionElement = document.createElement('p');
        newDescriptionElement.setAttribute('id', 'card' + (Number(card)+1) +'-Description');
        newDescriptionElement.innerText = cards[card].description;
        newDescriptionElement.style.width = '90px';
        newDescriptionElement.style.fontSize = '11px'
        newDescriptionElement.style.color = 'white';
        newDescriptionElement.style.textAlign = 'center';
        newDescriptionElement.style.fontFamily = 'MyCustomFont';
        cardDescriptionElements[card] = newDescriptionElement;

        // create new cost element for the cost of the card
       

        // position the elements within the canvas
        CARDS_ELEMENT_DIV.appendChild(newImgElement);
        CARDS_ELEMENT_DIV.appendChild(newTitleElement);
        CARDS_ELEMENT_DIV.appendChild(newDescriptionElement);
    }
    // position the elements within the canvas
    for (let cardIndex in cards){
        for (let card in CARDS){
            // check if the card in the hand is the same as the card in the deck
            if (cards[cardIndex].name == CARDS[card].name && cards[cardIndex].upgradeStatus == CARDS[card].upgradeStatus){
                cardElements[cardIndex].src = CARD_IMAGES[card];
                cardElementsHoveringStatus[cardIndex] = false;
                cardElementClickStatus[cardIndex] = false;
                
                
            }
        }
    }
   
}



// create Card Elements for the anvil
function createAnvilCardElement(index){
    // check which card to draw
    for (let card in CARDS){
        if (playerDeck[index].name == CARDS[card].name && CARDS[card].upgradeStatus ==playerDeck[index].upgradeStatus){
            
            // create a new image element for the card
            let newImgElement = document.createElement('img');
            newImgElement.src = CARD_IMAGES[card];
            newImgElement.setAttribute('draggable', 'false');
            newImgElement.style.zIndex = '2';
            newImgElement.style.transform = 'scale(2,2)';

            // create new title element for the title of the card
            let newTitleElement = document.createElement('h1');
            newTitleElement.innerText = CARDS[card].name;
            newTitleElement.style.width = '160px';
            newTitleElement.style.fontSize = '30px';
            newTitleElement.style.color = 'white';

            newTitleElement.style.fontFamily = 'MyCustomFont';
            newTitleElement.style.display = 'block';
            newTitleElement.style.textAlign = 'center';
            newTitleElement.style.zIndex = '2';

            // create new description element for the description of the card
            let newDescriptionElement = document.createElement('p');
            newDescriptionElement.innerText = CARDS[card].description;
            newDescriptionElement.style.width = '180px';
            newDescriptionElement.style.fontSize = '22px'
            newDescriptionElement.style.color = 'white';
            newDescriptionElement.style.textAlign = 'center';
            newDescriptionElement.style.fontFamily = 'MyCustomFont';
            newDescriptionElement.style.zIndex = '2';

            // create new cost element for the cost of the card
            let newCostElement = document.createElement('p');
            newCostElement.innerText = CARDS[card].energyCost;
            newCostElement.style.width = '200px';
            newCostElement.style.fontSize = '26px'
            newCostElement.style.color = 'white';
            newCostElement.style.textAlign = 'center';
            newCostElement.style.fontFamily = 'MyCustomFont';
            newCostElement.style.zIndex = '2';

            anvilCardElements = newImgElement;
            anvilCardCostElements = newCostElement;
            anvilCardTitleElements = newTitleElement
            anvilCardDescrpitionElements = newDescriptionElement;
            
            // add the cards to the card elements
            ANVIL_CARDS.appendChild(newImgElement);
            ANVIL_CARDS.appendChild(newTitleElement);
            ANVIL_CARDS.appendChild(newCostElement);
            ANVIL_CARDS.appendChild(newDescriptionElement);
        }
        
    }

    // check for the upgradeded verion of the card
    for (let card in CARDS){

        // check which card to create
        if(CARDS[card].upgradeStatus == true){
            if (playerDeck[index].name == CARDS[card].name){
            
                // create a new image element for the card
                let newImgElement = document.createElement('img');
                newImgElement.src = CARD_IMAGES[card];
                newImgElement.setAttribute('draggable', 'false');
                newImgElement.style.zIndex = '2';
                newImgElement.style.transform = 'scale(2,2)';
    
                // create new title element for the title of the card
                let newTitleElement = document.createElement('h1');
                newTitleElement.innerText = CARDS[card].name;
                newTitleElement.style.width = '160px';
                newTitleElement.style.fontSize = '30px';
                newTitleElement.style.color = 'white';
    
                newTitleElement.style.fontFamily = 'MyCustomFont';
                newTitleElement.style.display = 'block';
                newTitleElement.style.textAlign = 'center';
                newTitleElement.style.zIndex = '2';
    
                // create new description element for the description of the card
                let newDescriptionElement = document.createElement('p');
                newDescriptionElement.innerText = CARDS[card].description;
                newDescriptionElement.style.width = '180px';
                newDescriptionElement.style.fontSize = '22px'
                newDescriptionElement.style.color = 'white';
                newDescriptionElement.style.textAlign = 'center';
                newDescriptionElement.style.fontFamily = 'MyCustomFont';
                newDescriptionElement.style.zIndex = '2';
    
                // create new cost element for the cost of the card
                let newCostElement = document.createElement('p');
                newCostElement.innerText = CARDS[card].energyCost;
                newCostElement.style.width = '200px';
                newCostElement.style.fontSize = '26px'
                newCostElement.style.color = 'white';
                newCostElement.style.textAlign = 'center';
                newCostElement.style.fontFamily = 'MyCustomFont';
                newCostElement.style.zIndex = '2';
    
                upgradeAnvilCardElements = newImgElement;
                upgradeAnvilCardCostElements = newCostElement;
                upgradeAnvilCardTitleElements = newTitleElement
                upgradeAnvilCardDescrpitionElements = newDescriptionElement;
                

                // add the elements to anvil cards
                ANVIL_CARDS.appendChild(newImgElement);
                ANVIL_CARDS.appendChild(newTitleElement);
                ANVIL_CARDS.appendChild(newCostElement);
                ANVIL_CARDS.appendChild(newDescriptionElement);
            }
        }
        
    }
   
}

// create the elements for the sorted cards
function createSortedCardElements(){

    // sort the cards
    sortedCards =  sortingTypes[sortType](playerDeck);

    // make a new array for the number of sorted cards
    deckCardElements = new Array(playerDeck.length);
    deckCardCostElements = new Array(playerDeck.length);
    deckCardTitleElements = new Array(playerDeck.length);
    deckCardDescrpitionElements = new Array(playerDeck.length);
    // loop through all card needed to be created
    for (let sortedCard in sortedCards){
        
        for (let card in CARDS){

            // check which card to create
            if (sortedCards[sortedCard].name == CARDS[card].name && sortedCards[sortedCard].upgradeStatus == CARDS[card].upgradeStatus){

                // create new image element for the card
                let newImgElement = document.createElement('img');
                newImgElement.src = CARD_IMAGES[card];
                newImgElement.setAttribute('draggable', 'false');
                newImgElement.style.zIndex = '2';
                // create new title element for the title of the card
                let newTitleElement = document.createElement('h1');
                newTitleElement.innerText = CARDS[card].name;
                newTitleElement.style.width = '80px';
                newTitleElement.style.fontSize = '15px';
                newTitleElement.style.color = 'white';
                newTitleElement.style.fontFamily = 'MyCustomFont';
                newTitleElement.style.textAlign = 'center';
                newTitleElement.style.zIndex = '2';

                // create new description element for the description of the card
                let newDescriptionElement = document.createElement('p');
                newDescriptionElement.innerText = CARDS[card].description;
                newDescriptionElement.style.width = '90px';
                newDescriptionElement.style.fontSize = '11px'
                newDescriptionElement.style.color = 'white';
                newDescriptionElement.style.textAlign = 'center';
                newDescriptionElement.style.fontFamily = 'MyCustomFont';
                newDescriptionElement.style.zIndex = '2';

                // create new cost element for the cost of the card
                let newCostElement = document.createElement('p');
                newCostElement.innerText = CARDS[card].energyCost;
                newCostElement.style.width = '100px';
                newCostElement.style.fontSize = '13px'
                newCostElement.style.color = 'white';
                newCostElement.style.textAlign = 'center';
                newCostElement.style.fontFamily = 'MyCustomFont';
                newCostElement.style.zIndex = '2';

                // make only the first 10 cards show
                if (sortedCard > 9+row*5 || sortedCard < row*5){
                    newImgElement.style.display = 'none';
                    newTitleElement.style.display = 'none';
                    newCostElement.style.display = 'none';
                    newDescriptionElement.style.display = 'none';
                }
                

                // add all the elements to arrays
                deckCardElements[sortedCard] = newImgElement;
                deckCardCostElements[sortedCard] = newCostElement;
                deckCardTitleElements[sortedCard] = newTitleElement
                deckCardDescrpitionElements[sortedCard] = newDescriptionElement;

                // add the elements to the DECK div
                DECKS.appendChild(newImgElement);
                DECKS.appendChild(newTitleElement);
                DECKS.appendChild(newCostElement);
                DECKS.appendChild(newDescriptionElement);
            }
        }
    }
    // check if what row the player is on
    if (row == 0) {
        // Hide the 'Up' button if at the top
        UP_BTN.style.display = 'none';
        DOWN_BTN.style.display = 'block';
    }
    else if ((5 + row * 5) >= playerDeck.length - 1) {
        // Hide the 'Down' button if at the bottom
        DOWN_BTN.style.display = 'none';
        UP_BTN.style.display = 'block';
    } else {
        UP_BTN.style.display = 'block';
        DOWN_BTN.style.display = 'block';
    }
}

// sorts cards
function sortCardsByName(cards) {
    // Create an array to hold unsorted cards
    let unSortedCards = new Array(cards.length);

    // Create an array to hold sorted cards, initially empty
    let sortedCards = new Array(0);

    // Flag to check if no card matched the last matched card
    let noCardMatched = false;

    // Copy all cards to unSortedCards array
    for (let card in cards) {
        unSortedCards[card] = cards[card];
    } 

    // Initialize lastMatchedCard with the first card from unSortedCards
    let lastMatchedCard = unSortedCards[0];

    // Insert the first card into sortedCards
    sortedCards = insertElement(sortedCards, unSortedCards[0], 0);

    // Remove the first card from unSortedCards
    unSortedCards = indexRemover(unSortedCards, 0, 1);

    // Loop until all cards are sorted
    while (sortedCards.length != cards.length) {
        
        if (noCardMatched == false) {
            // Store the current length of sortedCards
            let previousArrayLength = sortedCards.length;

            // Loop through unSortedCards to find matching cards
            for (let matchingCardCheck in unSortedCards) {
                if (unSortedCards[matchingCardCheck] == lastMatchedCard) {
                    // Insert the matching card into sortedCards
                    sortedCards = insertElement(sortedCards, unSortedCards[matchingCardCheck], sortedCards.length);
                    
                    // Remove the matching card from unSortedCards
                    unSortedCards = indexRemover(unSortedCards, matchingCardCheck, 1);

                    // Reset the noCardMatched flag
                    noCardMatched = false;
                    break;
                }
            }

            // If no card was matched, set noCardMatched to true
            if (previousArrayLength == sortedCards.length) {
                noCardMatched = true;
            }
        } else {
            // If no card was matched, add the next card from unSortedCards
            sortedCards = insertElement(sortedCards, unSortedCards[0], sortedCards.length);
            
            // Remove the added card from unSortedCards
            unSortedCards = indexRemover(unSortedCards, 0, 1);

            // Reset the noCardMatched flag
            noCardMatched = false;

            // Update lastMatchedCard to the last added card
            lastMatchedCard = sortedCards[sortedCards.length - 1];
        }
    }

    // Return the fully sorted cards array
    return sortedCards;
}

// sorts cards by energy cost in descending order
function sortCardsByCost(cards) {
    // Create an array to hold unsorted cards, 
    let unSortedCards = new Array(cards.length);

    // Create an array to hold sorted cards
    let sortedCards = new Array(0);

    // Flag to check if no card matched the last matched cost
    let noCostMatched = false;

    // energy cost of the first card in the cards array
    let lastMatchedCost = cards[0].energyCost;

    // Copy all cards to unSortedCards array and determine the initial highest cost
    for (let card in cards) {
        unSortedCards[card] = cards[card];
        if (lastMatchedCost < cards[card].energyCost) {
            lastMatchedCost = cards[card].energyCost; // Update lastMatchedCost to the highest found cost
        }
    }

    // Loop until all cards are sorted into the sortedCards array
    while (sortedCards.length != cards.length) {
        
        if (noCostMatched == false) {
            // Store the current length of sortedCards to check if a new card is added in this iteration
            let previousArrayLength = sortedCards.length;
            
            // Loop through unSortedCards to find cards that match the lastMatchedCost
            for (let matchingCostCheck in unSortedCards) {
                if (unSortedCards[matchingCostCheck].energyCost == lastMatchedCost) {
                    
                    // Insert the matching card into sortedCards
                    sortedCards = insertElement(sortedCards, unSortedCards[matchingCostCheck], sortedCards.length);
                    
                    // Remove the matching card from unSortedCards
                    unSortedCards = indexRemover(unSortedCards, matchingCostCheck, 1);

                    // Reset the noCostMatched flag since a matching card was found
                    noCostMatched = false;
                    
                    break; // Exit the loop once a match is found
                }
            }

            // If no card was matched, set noCostMatched to true
            if (previousArrayLength == sortedCards.length) {
                noCostMatched = true;
            }
        } 
        else {
            // If no match was found, find the next highest cost in unSortedCards
            lastMatchedCost = unSortedCards[0].energyCost;
            for (let card in unSortedCards) {
                if (lastMatchedCost < unSortedCards[card].energyCost) {
                    lastMatchedCost = unSortedCards[card].energyCost; // Update to the highest found cost
                }
            }

            // Reset the noCostMatched flag to retry matching with the new cost
            noCostMatched = false;
        }
    }

    // Return the fully sorted array of cards
    return sortedCards;
}


// sorts cards by type
function sortCardsByType(cards) {

    // Create an array to hold unsorted cards, initialized with the same length as the input cards array
    let unSortedCards = new Array(cards.length);

    // Create an array to hold sorted cards, initially empty
    let sortedCards = new Array(0);

    // Flag to check if no card matched the last matched type
    let noTypeMatched = false;
    // Initialize the lastMatchedType with 'attack' as the default type to match initially
    let lastMatchedType = 'attack';

    // Copy all cards from the input array to unSortedCards array
    for (let card in cards) {
        unSortedCards[card] = cards[card];
    } 
    
    // Loop until all cards are sorted
    while (sortedCards.length != cards.length) {
        
        if (noTypeMatched == false) {
            // Store the current length of sortedCards to check if a new card is added in this iteration
            let previousArrayLength = sortedCards.length;
            
            // Loop through unSortedCards to find cards that match the lastMatchedType
            outerLoop: // Label for the outer loop to break out when a match is found
            for (let matchingTypeCheck in unSortedCards) {
                for (let type in unSortedCards[matchingTypeCheck].type) {
                    if (unSortedCards[matchingTypeCheck].type[type] == lastMatchedType) {
                        
                        // Insert the matching card into sortedCards
                        sortedCards = insertElement(sortedCards, unSortedCards[matchingTypeCheck], sortedCards.length);
                        
                        // Remove the matching card from unSortedCards
                        unSortedCards = indexRemover(unSortedCards, matchingTypeCheck, 1);

                        // Reset the noTypeMatched flag since a matching card was found
                        noTypeMatched = false;
                        
                        // Break out of both loops once a match is found
                        break outerLoop;
                    }
                }
            }

            // If no new card was added, set noTypeMatched to true
            if (previousArrayLength == sortedCards.length) {
                noTypeMatched = true;
            }
        } 
        else {
            // If no match was found in the previous iteration, update lastMatchedType to the type of the first unsorted card
            lastMatchedType = unSortedCards[0].type[0];

            // Reset the noTypeMatched flag to retry matching with the new type
            noTypeMatched = false;
        }
    }

    // Return the fully sorted array of cards
    return sortedCards;
}