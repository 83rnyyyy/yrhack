'use strict'
let island1 = document.getElementById('island1');
let island2 = document.getElementById('island2');
let island3 = document.getElementById('island3');
let island4 = document.getElementById('island4');
let island5 = document.getElementById('island5');
let island6 = document.getElementById('island6');
let island7 = document.getElementById('island7');
let island8 = document.getElementById('island8');
let island9 = document.getElementById('island9');
let back = document.getElementById('back');

let pointer1 = document.getElementById('pointer1');
let pointer2 = document.getElementById('pointer2');
let pointer3 = document.getElementById('pointer3');
const BATTLE_IMG = document.getElementById('battle_img');

const eButton = document.getElementById("e_button");
const eButton1 = document.getElementById("e_button1");
const eButton2 = document.getElementById("e_button2");

// Original variables (keep these)
let lesson1 = "";
let lesson2 = "";
let lesson3 = "";

// New quiz variables (add these)
let quizQuestion1 = '';
let quizQuestion2 = '';
let question1Choices = [];
let question2Choices = [];
let correctAnswer1 = 0;
let correctAnswer2 = 0;


async function startQuest() {
    const skill = document.getElementById('skill').value.trim();
    const gameDiv = document.getElementById('game');
    const beginGameButton = document.getElementById('beginGameButton');
    document.documentElement.style.overflow = 'auto';
    document.body.style.overflow = 'auto';

    if (!skill) {
        gameDiv.style.display = 'block';
        gameDiv.innerHTML = "<p>Please enter a skill!</p>";
        return;
    }

    gameDiv.style.display = 'block';
    gameDiv.innerHTML = "<p>Loading your quest...</p>";

    try {
        const response = await fetch("https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 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"
            },
            body: JSON.stringify({
                inputs: `Explain what ${skill} is in a fun and engaging way for a beginner. Include why someone might want to learn it.`,
                parameters: {
                    return_full_text: false,
                    max_new_tokens: 250,
                    temperature: 0.8
                }
            })
        });

        

        const data = await response.json();

        await generateLessons(skill);
        console.log("Lesson 1 content:", lesson1);
        await generateQuizQuestions(skill);

        if (data.error) {
            console.error(data);
            gameDiv.innerHTML = "<p>Error: " + data.error + "</p>";
            return;
        }

        const output = data[0]?.generated_text || JSON.stringify(data, null, 2);
        gameDiv.innerHTML = `<div>${escapeHtml(output)}</div>`;

        // Show the Begin Game button after quest starts
        beginGameButton.style.display = 'block';

    } catch (error) {
        console.error("API error:", error);
        gameDiv.innerHTML = "<p>Failed to load quest. See console for error.</p>";
    }
}

// This runs in the background to generate and store lessons

// Call this to generate all 3 lessons
// Add this at the top with your other variables (if not already there)
let lessonsGenerated = false;

// Replace the entire generateLessons function and remove fetchContent helper
async function generateLessons(skill) {
    try {
        console.log("Starting to generate lessons for:", skill);

        // Use consistent API key
        const headers = {
            "Content-Type": "application/json",
            "Authorization": "Bearer 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" // Use your preferred key
        };

        // Fetch all lessons in parallel
        const lessonPromises = [
            fetch("https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2", {
                method: "POST",
                headers: headers,
                body: JSON.stringify({
                    inputs: `Create a beginner lesson about ${skill}. Focus on a first practical lesson with a hands-on example.`,
                    parameters: { max_new_tokens: 300, temperature: 0.8 }
                })
            }),
            fetch("https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2", {
                method: "POST",
                headers: headers,
                body: JSON.stringify({
                    inputs: `Create a beginner lesson about ${skill}. Focus on common mistakes beginners make and how to avoid them.`,
                    parameters: { max_new_tokens: 300, temperature: 0.8 }
                })
            }),
            fetch("https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2", {
                method: "POST",
                headers: headers,
                body: JSON.stringify({
                    inputs: `Create a beginner lesson about ${skill}. Introduce one advanced concept in a simple way.`,
                    parameters: { max_new_tokens: 300, temperature: 0.8 }
                })
            })
        ];

        // Await all responses
        const responses = await Promise.all(lessonPromises);
        const data = await Promise.all(responses.map(r => r.json()));

        // Extract text safely
        lesson1 = data[0][0]?.generated_text || "Practical introduction to " + skill;
        lesson2 = data[1][0]?.generated_text || "Common mistakes in " + skill;
        lesson3 = data[2][0]?.generated_text || "Advanced concepts in " + skill;

        console.log("Lessons generated successfully");
        console.log("Lesson 1 sample:", lesson1.substring(0, 50) + "...");
        lessonsGenerated = true;
        
        return true;
    } catch (error) {
        console.error("Error generating lessons:", error);
        // Fallback content
        lesson1 = "Practical introduction to " + skill;
        lesson2 = "Common mistakes in " + skill;
        lesson3 = "Advanced concepts in " + skill;
        lessonsGenerated = true;
        return false;
    }

    
}


// Prevent injection
function escapeHtml(text) {
    const div = document.createElement("div");
    div.innerText = text;
    return div.innerHTML;
}

// NEW: Generates just 2 general quiz questions
async function generateQuizQuestions(skill) {
    try {
        const prompt = `Create 2 general quiz questions about learning ${skill} with 4 multiple choice answers each. ` +
                      `Format as JSON example: {
                          "questions": [
                              {
                                  "question": "What is...",
                                  "choices": ["a", "b", "c", "d"],
                                  "correct": 0
                              }
                          ]
                      }`;
        
        const response = await fetch("https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 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"
            },
            body: JSON.stringify({
                inputs: prompt,
                parameters: {
                    return_full_text: false,
                    max_new_tokens: 500,
                    temperature: 0.7
                }
            })
        });

        const data = await response.json();
        const result = data[0]?.generated_text || "";
        
        try {
            const parsed = JSON.parse(result.replace(/```json|```/g, ''));
            if (parsed.questions?.length >= 2) {
                // Store questions
                quizQuestion1 = parsed.questions[0].question;
                question1Choices = parsed.questions[0].choices;
                correctAnswer1 = parsed.questions[0].correct;
                
                quizQuestion2 = parsed.questions[1].question;
                question2Choices = parsed.questions[1].choices;
                correctAnswer2 = parsed.questions[1].correct;
            }
        } catch {
            createFallbackQuestions();
        }
    } catch {
        createFallbackQuestions();
    }
}

function createFallbackQuestions() {
    quizQuestion1 = "What's the most important practice when learning this skill?";
    question1Choices = ["Daily repetition", "Watching tutorials", "Reading books", "Advanced techniques"];
    correctAnswer1 = 0;
    
    quizQuestion2 = "How often should you review fundamentals?";
    question2Choices = ["Never", "Monthly", "Weekly", "Every session"];
    correctAnswer2 = 3;
}


function startGame() {
    window.location.href = "map.html";
    // Your game start logic goes here.
}

function escapeHtml(text) {
    var div = document.createElement('div');
    div.innerText = text
    return div.innerHTML;
}
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = 1024;
canvas.height = 576;

let scroll_imgs = [];
let currentFrame = 0;
let frameCount = 0;
const frameDelay = 7; // Delay to slow animation

// Preload images
for (let i = 0; i <= 10; i++) {
    const img = new Image();
    img.src = `scrolls/${i}.png`;
    scroll_imgs.push(img);
}


function drawScroll() {
    // ctx.fillStyle = "red";
    //ctx.fillRect(50, 50, 100, 100);
    // ctx.drawImage(island1, -200, -200, canvas.width + 400, canvas.height + 400);
    if (scroll_imgs[currentFrame].complete) {
        ctx.drawImage(scroll_imgs[currentFrame], -250, -265, canvas.width + 500, canvas.height + 475);
    }
}

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawScroll();

    if (currentFrame < scroll_imgs.length - 1) {
        frameCount++;
        if (frameCount >= frameDelay) {
            frameCount = 0;
            currentFrame++;
        }
        requestAnimationFrame(animate); // Keep going only if not at the end
    } else {
        drawScroll(); // Final frame stays on screen
        console.log("Animation finished.");
        drawIslands();
    }
}

let islandImagesLoaded = 0;




function drawIslands(){
    
    island1.hidden = false;
    island2.hidden = false;
    island3.hidden = false;
    island4.hidden = false;
    island5.hidden = false;
    island6.hidden = false;
    island7.hidden = false;
    island8.hidden = false;
    island9.hidden = false;

    ctx.drawImage(island1, 150, 115, 160, 160);
    ctx.drawImage(island2, 330, 115, 165, 165);
    ctx.drawImage(island3, 510, 103, 165, 165);
    ctx.drawImage(island4, 700, 75, 200, 195);
    ctx.drawImage(island5, 150, 300, 155, 155);
    ctx.drawImage(island7, 320, 300, 155, 155);
    ctx.drawImage(island8, 520, 300, 155, 155);
    ctx.drawImage(island9, 700, 300, 155, 155);

    canvas.addEventListener('click', selectIsland1);
    
}

let islandsUnlocked = 1;
let hub = false;


function enterIsland(){
    
}


function selectIsland1(event){
    
    // creates constant to store the position of the canvas on the webpage
    const RECT = canvas.getBoundingClientRect();
    // creates constants to store the positions of the mouse
    const MOUSEX = event.clientX - RECT.left;
    const MOUSEY = event.clientY - RECT.top;
    console.log(`Clicked at: (${MOUSEX}, ${MOUSEY})`); // Debug log
    if (MOUSEX >= 150 && MOUSEX < 310 && MOUSEY >= 115 && MOUSEY < 275 && islandsUnlocked >= 1) {
        console.log("You clicked on the island!");
        drawHub();
        canvas.removeEventListener('click', selectIsland1); // Remove the event listener after clicking
        

    }
}


let towncenter = document.getElementById('town-center'); 
let map = document.getElementById('map');
function drawHub(){
    hub = true;
    animateCharacter()


}


let spriteSheet = new Image();
spriteSheet.src = "player.png"; 

const frameWidth = 96;
const frameHeight = 96;
let x = 100;
let y = 100;
let gameFrame = 0;
let playerState = "Idle";

// Define animation states and their frames
const spriteAnimations = {
    Idle: {
    frames: 6,
    y: 0,
    stagger: 20,
    },
    Right_Move: {
    frames: 6,
    y: 4,
    stagger: 20,
    },
    Down_Move: {
    frames: 6,
    y: 3,
    stagger: 20,
    },
    Up_Move: {
    frames: 6,
    y: 5,
    stagger: 20,
    },
    Left_Move: {
    frames: 6,
    y: 1,
    stagger: 20,
    },
    Attack_Right: {
    frames: 4,
    y: 7,
    stagger: 22, // Slower attack
    },
};

let characterIsReady = false; 

const keysPressed = {};



window.addEventListener("keyup", (e) => {
    keysPressed[e.key] = false;
});

let isAttacking = false; // Flag to track if the player is attacking
let isTouchingWall = false;
let isTouchBossWall = false;
let isTouchingWall1 = false;
let isTouchingWall2 = false;


function getPlayerCollisionBox() {
    return {
      x: x + 18, // offset from sprite's left
      y: y + 8,  // offset from sprite's top
      width: 60,
      height: 80,
    };
  }

// Function to check if two rectangles are colliding
function isColliding(rect1, rect2) {
    return (
        rect1.x < rect2.x + rect2.width &&
        rect1.x + rect1.width > rect2.x &&
        rect1.y < rect2.y + rect2.height &&
        rect1.y + rect1.height > rect2.y
    );
}

// Wall definition
const wall = {
    x: 75,
    y: 130,
    width: 120,
    height: 100,
};
const wall1 = {
    x: 37,
    y: 325,
    width: 120,
    height: 100,
};
const wall2 = {
    x: 740,
    y: 95,
    width: 120,
    height: 100,
};
const goToBoss = {
    x: canvas.width/2-50,
    y: 0,
    width: 100,
    height: 120,
};



function animateCharacter() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (!isAttacking) {
      if (keysPressed["d"] && x + frameWidth / 1.5 < canvas.width) {
        playerState = "Right_Move";
        x += 2;
      } else if (keysPressed["a"] && x > -48) {
        playerState = "Left_Move";
        x -= 2;
      } else if (keysPressed["s"] && y + frameHeight / 1.4 < canvas.height) {
        playerState = "Down_Move";
        y += 2;
      } else if (keysPressed["w"] && y > -48) {
        playerState = "Up_Move";
        y -= 2;
      } else {
        playerState = "Idle";
      }
    }
    if(isTouchBossWall){
        characterIsReady = true;
    }

    if (characterIsReady){
        miniBossBattle();
    }
    if (hub){
        ctx.drawImage(towncenter, 0, 0, canvas.width, canvas.height);
        ctx.drawImage(map, 0, 0, 50,50);
        ctx.drawImage(pointer1, 75, 130, 50, 60);
        ctx.drawImage(pointer2, 37, 325, 50, 60);
        ctx.drawImage(pointer3, 740, 95, 50, 60);
        eButton.style.display = "block"; 
        eButton.style.position = "absolute";   
        eButton1.style.display = "block"; 
        eButton1.style.position = "absolute";   
        eButton2.style.display = "block"; 
        eButton2.style.position = "absolute";   
    }else{
        eButton.style.display = "none"; 
        eButton1.style.display = "none"; 
        eButton2.style.display = "none"; 

    }

    const anim = spriteAnimations[playerState];
    const frame = Math.floor(gameFrame / anim.stagger) % anim.frames;
    const frameX = frame * frameWidth;
    const frameY = anim.y * frameHeight;

    ctx.drawImage(spriteSheet, frameX, frameY, frameWidth, frameHeight, x, y, frameWidth, frameHeight);
    ctx.fillStyle = "transparent";  // Set the fill style to transparent
    ctx.fillRect(wall.x, wall.y, wall.width, wall.height); // Draw the wall
    ctx.fillRect(wall1.x, wall1.y, wall1.width, wall1.height); // Draw the wall
    ctx.fillRect(wall2.x, wall2.y, wall2.width, wall2.height); // Draw the wall
    ctx.fillRect(goToBoss.x, goToBoss.y, goToBoss.width, goToBoss.height); // Draw the wall



    const playerBox = getPlayerCollisionBox();
    isTouchingWall = isColliding(playerBox, wall);  // Check if touching the wall
    isTouchingWall1 = isColliding(playerBox, wall1);  // Check if touching the wall
    isTouchingWall2 = isColliding(playerBox, wall2);  // Check if touching the wall
    isTouchBossWall = isColliding(playerBox, goToBoss);  // Check if touching the wall

    if (pointer1interacted){
        eButton.style.display = "none"; 
        eButton1.style.display = "none"; 
        eButton2.style.display = "none"; 
        ctx.drawImage(lesson_background, 300, 10, 500, 550);
        ctx.fillStyle = "#000000";
        ctx.font = "bold 30px Arial";
        ctx.fillText("Lesson 1: Introduction", 400, 90);
        ctx.font = "12px Arial";
        
        
        
        const text1 = `Python is a beginner-friendly programming language. 
        In this lesson, we'll write your first program: a "Hello, World!" message.

Steps
Set up your environment: Download and install Python from python.org. Open an IDE or text editor (like IDLE or Visual Studio Code).

Write the code:

python
Copy
Edit
print("Hello, World!")
Run the program: Save the file as hello_world.py and run it. In IDLE, press F5, or use the command line:

bash
Copy
Edit
python hello_world.py
Output:

Copy Edit Hello, World! Conclusion
You’ve just written your first Python program! In the next lesson, we’ll learn about variables and data types.`;

    // Split the text into words
    const words = text1.split(' ');
    let line = '';
    let lines = [];

    // Loop through the words and break them into lines of 4 words (or whatever number you choose)
    for (let i = 0; i < words.length; i++) {
        line += words[i] + ' ';
        
        // Every 4 words, start a new line (you can change this number for more/less words per line)
        if ((i + 1) % 4 === 0 || i === words.length - 1) {
            lines.push(line.trim());
            line = '';
        }
    }

    // Now draw the text line by line
    let yPosition = 130; // Starting Y position for the text
    let xPosition = 375; // Move text to the right (increase this number to move it further right)

    lines.forEach((lineText) => {
        ctx.fillText(lineText, xPosition, yPosition); // Draw text with adjusted x position
        yPosition += 18; // Move down for the next line (change 18 for more or less spacing)
    });

    console.log(lines); // For debugging

    ctx.drawImage(back, 20, 20, 75,75);

    ctx.addEventListener('click',backtohub);




    }

    if (pointer2interacted){
        eButton.style.display = "none"; 
        eButton1.style.display = "none"; 
        eButton2.style.display = "none"; 
        ctx.drawImage(lesson_background, 300, 10, 500, 550);
        ctx.fillStyle = "#000000";
        ctx.font = "bold 30px Arial";
        ctx.fillText("Lesson 2: Introduction", 400, 90);
        ctx.font = "18px Arial";
        const lesson2Text = `In this lesson, we’ll explore common mistakes beginners make when 
starting with Python and how to avoid them.

1. Forgetting to indent: Python uses indentation to define blocks of code. 
Make sure to properly indent your code, or you’ll get an error. 

2. Misspelling keywords: Python is case-sensitive. Make sure to spell 
keywords like "print" and "def" correctly.

3. Using the wrong data type: Make sure the variable type matches 
the operation you want to perform. For example, don't try to add a 
string to an integer.

4. Not testing code incrementally: It’s a good habit to test your 
code frequently as you write it. This way, you can catch errors early.

By avoiding these mistakes, you’ll be well on your way to becoming 
a proficient Python programmer. Let’s move on to the next lesson.`;


        ctx.fillText(lesson2Text, 400, 200);
        ctx.drawImage()
        
    }

    if (pointer3interacted){
        eButton.style.display = "none"; 
        eButton1.style.display = "none"; 
        eButton2.style.display = "none"; 
        ctx.drawImage(lesson_background, 300, 10, 500, 550);
        ctx.fillStyle = "#000000";
        ctx.font = "bold 30px Arial";
        ctx.fillText("Lesson 3: Introduction", 400, 90);
        ctx.font = "18px Arial";
        const lesson3Text = `In this lesson, we\’ll introduce a more advanced concept:\nfunctions in Python.\n\nA function is a block of code that runs when called. You can\ndefine functions to reuse code and make your programs more\norganized.\n\nTo define a function, use the 'def' keyword followed by the function\nname and parentheses. Here’s an example of a simple function:\n\n\ndef greet(name):\n    print(f"Hello, {name}!")\n\ngreet("Alice")\n\nWhen you run the program, it will print "Hello, Alice!" to the console.\nFunctions can also accept multiple parameters and return values.\n\nFor example, here’s a function that adds two numbers:\n\n\ndef add_numbers(a, b):\n    return a + b\n\nresult = add_numbers(3, 4)\nprint(result)\n\nThis function takes two parameters (a and b) and returns their sum.\nUnderstanding functions is an essential part of becoming proficient in\nPython.`;
        ctx.fillText(lesson3Text, 400, 200);
    }

   

    if (playerState === "Attack_Right") {
      if (frame === anim.frames - 1) {
        isAttacking = false;
        setTimeout(() => {
          playerState = "Idle";
        }, 100);
      }
    }

    gameFrame++;
    
    requestAnimationFrame(animateCharacter);
}

let pointer1interacted = false;
let pointer2interacted = false;
let pointer3interacted = false;
function simulateButtonClick(button) {
    pointer1interacted = true;
    // Add active class for visual feedback
    button.classList.add("active");
  
    // Trigger the actual click handler
    button.click();
  
    // Remove the active class after a short delay
    setTimeout(() => {
      button.classList.remove("active");
    }, 150); // duration should match your transition time
}

window.addEventListener("keydown", (e) => {
    keysPressed[e.key] = true;
    switch (e.key) {
        case "d": // Move right
        if (x + frameWidth / 1.5 < canvas.width) {
            playerState = "Right_Move";
            x += 2;
        }
        break;
        case "a": // Move left
        if (x > -48) {
            playerState = "Left_Move";
            x -= 2;
        }
        break;
        case "s": // Move down
        if (y + frameHeight / 1.4 < canvas.height) {
            playerState = "Down_Move";
            y += 2;
        }
        break;
        case "w": // Move up
        if (y > -48) {
            playerState = "Up_Move";
            y -= 2;
        }
        break;
        case "n": // Start attack
        if (!isAttacking) {
            playerState = "Attack_Right";
            isAttacking = true; // Set the attack flag to true
        }
        break;
        case "e":
        if(isTouchingWall){
            simulateButtonClick(eButton);
            interactPointer1();

        }else if(isTouchingWall1){
            simulateButtonClick(eButton2);
        }else if(isTouchingWall2){
            simulateButtonClick(eButton1);
        }
        break;
    }
});

animate();

// E Button click handler
eButton.addEventListener("click", () => {
    if (isTouchingWall) {
      console.log("E key pressed while touching wall!");
      // Place your interaction logic here (open a door, etc.)
    } else {
      console.log("You must be near the wall to press E!");
    }
});

const box = getPlayerCollisionBox();
ctx.strokeRect(box.x, box.y, box.width, box.height);

function interactPointer1(){
    
   ctx.drawImage(lesson_background, 150, 150, 500, 600);


}



function miniBossBattle(){
    hub = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(BATTLE_IMG, 0, 0, canvas.width, canvas.height);
}


let lesson_background = document.getElementById('lesson');

function wrapText(context, text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    
    for(let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = context.measureText(testLine);
        const testWidth = metrics.width;
        
        if (testWidth > maxWidth && n > 0) {
            context.fillText(line, x, y);
            line = words[n] + ' ';
            y += lineHeight;
        } else {
            line = testLine;
        }
    }
    context.fillText(line, x, y);
}

function backtohub(event){
    hub = true;
    // creates constant to store the position of the canvas on the webpage
    const RECT = canvas.getBoundingClientRect();
    // creates constants to store the positions of the mouse
    const MOUSEX = event.clientX - RECT.left;
    const MOUSEY = event.clientY - RECT.top;

    if (MOUSEX >= 20 && MOUSEX < 95 && MOUSEY >= 20 && MOUSEY < 95) {
        console.log("You clicked on the back button!");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawHub();
        canvas.removeEventListener('click', backtohub) // Re-add the event listener
    }
    
}